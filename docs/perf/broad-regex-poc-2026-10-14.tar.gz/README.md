# Archived synthetic POCs

Extract this archive into `.poc-stress-test/` at the repository root.
Follow `postgres/README.md` to regenerate the shared corpus and run isolated SQL experiments.
Run Zoekt from its directory using `zoekt/README.md`.
Run `python3 .poc-stress-test/continuation/model.py` for the protocol model.
Stop the dedicated PostgreSQL cluster before deleting `.poc-stress-test/`.

`manifest.json` records source/result hashes and the corpus checksum.
Earlier small Zoekt correctness logs were superseded by the archived exclusion fixtures; only the final fixture set is included.
Measurements are exploratory. No production traces, credentials, binaries, generated indexes, corpus or database files are included.
