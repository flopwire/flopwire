# Continuation model: final evidence

Twenty executable Python tests pass; nine target the proposed GenerationScan architecture directly. Run `python3 .poc-stress-test/continuation/model.py`. This is a protocol model, not a PostgreSQL implementation, benchmark, indexing engine or security validation.

## Recommendation and precise contract

Use one tool with fast useful evidence plus explicit continuation over a pinned immutable indexed generation. A generation contains sealed segments plus a frozen versioned overlay. Initial evidence and continuation use that same generation. Completion means the eligible evidence in that indexed generation was examined, not that all live data has been searched. Return the indexed cutoff, coverage, scan progress, complete flag, opaque continuation and expiry. An empty incomplete page means that page emitted no hits and more coverage remains. An empty terminal page only means that page emitted no hits and coverage is exhausted; it does not establish scan-level absence. Earlier pages may contain matches. Cached terminal replay may be empty after revocation while an already-scanned permitted duplicate remains suppressed. Scan-level zero-result claims require aggregate verification semantics, and exact final permitted distinct results require reselecting retained matching groups.

The server-managed scan state binds tenant, principal, canonical pattern/flags/filters/sort/engine version, generation, scan frontier, dedup representatives, response sequence and TTL. Each page uses a short transaction. Concurrent requests atomically compare/advance sequence; retrying a committed page reconstructs it by stored IDs and exact versions. Terminal page retry state persists through TTL. Cancellation before commit does not advance position or dedup. Expiry is explicit restart-required, never a silent reset.

Receiving server credentials and current policy govern each page and every replay. A current authority/version fence suppresses redacted, deleted, hidden, no-longer-permitted and superseded versions. Redaction overrides historical versions. Initial eligible scope/visibility is frozen with the generation. Current authority may only narrow that scope. Later grants, unhides and replacement versions after cutoff belong to another search/generation, and the response must disclose that boundary. The model now checks both the snapshot row.visible and current authority. Production policy-scope snapshot publication remains unimplemented. This proposed contract therefore returns historical indexed evidence only while its exact version still meets current policy; it never claims current-live completeness. No local fallback.

Dedup state tracks emitted representative IDs/versions, not only hashes. A redacted representative no longer suppresses a later permitted copy. Cached replay stores IDs and metadata, never blindly replays sensitive text. A page may shrink after policy changes; this is intentional current-policy behavior rather than a promise of identical bytes across retries. Cached replay does not rescan new replacements or replenish removed hits. Reauthorization after revocation must fail even for the terminal page.

## Explicit state trace

published generation = {A:(ts=10,id=1,version=1,text=copy), B:(ts=9,id=2,version=1,text=copy)}
scan = {position=0,sequence=0,emitted={}}
authority = {reader:allowed,A:v1 allowed,B:v1 allowed}
page0 examines A; atomic commit stores {position=1,sequence=1,emitted={hash(copy):{A}},page0 IDs=[A]}.
redaction changes authority[A] to denied.
page0 retry reauthorizes reader, filters A; returns IDs=[] with the same examined coverage.
page1 examines B; A fails the authority fence, so hash(copy) has no valid representative. B is emitted.
reader credential is revoked. Any further page or replay, including terminal, fails unauthorized.

Two simultaneous page0 callers: model lock admits caller1; it commits position=1/sequence=1/page0. Caller2 then sees cached page0 and reauthorizes/reconstructs it; it does not move to position=2. Cancelled precommit caller leaves position=0/sequence=0/emitted={}.

## Proof table

| Claim | Impact if false | Strongest evidence | Missing/contradictory evidence | Status | Next action |
|---|---|---|---|---|---|
| Timestamp-only frontier handles ties | Silent missed rows | Naive timestamp tie counterexample | None | contradicted | Use total order, explicit NULL timestamp bucket |
| Sequence/first_seen_at freezes membership | Late-commit missed rows | Executable commit inversion; PG sequence docs | None | contradicted | Publish actual immutable generation; do not use allocated sequence watermark |
| Hit offset resumes checked coverage | Prefix repetition/no progress | Executable empty-prefix offset counterexample | None | contradicted | Separate scan position from hit offset |
| Independent text chunks preserve arbitrary regex | Cross-boundary missed match | Literal substring counterexample, a regex subset | Streaming regex state unimplemented | contradicted | Whole-message atomic verification or resumable engine |
| Published generation input is immutable in scan | Later appends/edits change coverage | GenerationScan copies input; append/edit test | Durable publication is supplied as assumption | POC-confirmed | PostgreSQL/index generation publication test |
| Current version suppression excludes stale evidence | Disallowed old versions leak | GenerationScan update/visibility tests | Real read-policy/default-state integration absent | POC-confirmed | Connect authoritative exact-version fence |
| Replay reauthorizes including terminal | Revoked credential/text replay | GenerationScan revoke/terminal tests | Authentication integration and concurrent revocation boundary absent | POC-confirmed | Integration test actual credential policy |
| Redacted representative does not suppress later copy | Missing permitted copy | GenerationScan representative-ID test | Already-scanned suppressed copies are not reconsidered | POC-confirmed | Decide frozen/current dedup semantics for earlier copies |
| Competing page calls advance once | Duplicate/missed scan progress | Two threads same sequence, lock-protected state | Database CAS, process crash/durable transaction absent | POC-confirmed | PostgreSQL multi-process CAS/retry POC |
| Cancellation does not advance | Lost evidence on retry | GenerationScan staged local state then cancellation test | Cancellation after DB commit/before reply needs actual retry test | POC-confirmed | Durable response-sequence integration test |
| Empty page is not scan-level absence | False no-match claim | Empty terminal replay with permitted suppressed duplicate; blocked empty prefix | Aggregate/reselected matching-set state unimplemented | POC-confirmed | Label coverage completion; never infer none from terminal page |
| Current authority only narrows frozen scope | Timing-dependent expansion | Later-unhide test excludes initially invisible row | Production initial policy snapshot absent | POC-confirmed | Freeze initial policy scope during publication |
| Generation publication/retention guarantees complete finite membership | Invalid snapshot/cutoff | Architectural requirement | Not implemented or measured | unresolved | Publication + pin/expiry + recovery POC |
| Current authority fence is secure | Sensitive evidence exposure | In-memory permitted-ID filter only | No production security proof | unresolved | Audit exact-server auth, rehydration and consistency point |
| Active hosted team completes without restarts | Restart starvation | Immutable model ignores new generation input | Real segment refresh and writer load untested | unresolved | Measure concurrent ingest/publication/retention |
| Fixed work budget always progresses | Infinite continuation at large body | Oversized row explicitly blocks | Body sizes/runtime and resumable matcher untested | unresolved | Explicit oversized state + whole-row budget/worker policy |

## Material limits

Publication is explicitly an assumption. Python deep-copy is not a deployable index-generation mechanism and proves no database watermark. A sequence allocated before commit or first_seen_at set at transaction start cannot establish a committed snapshot. PostgreSQL repeatable-read snapshots last for one transaction; independent page transactions need immutable versioned data, not a timestamp token.

Current authority operations and page computation are serialized by an in-memory lock. This demonstrates a logical consistency point only. It does not prove race-free production delivery, immediate revocation or policy enforcement across separate services. The real implementation must reauthorize receiving-server identity and current exact version and define the instant at which authorization is judged.

Dedup-after-redaction test covers a later unexamined permitted copy. If the permitted copy was already scanned and suppressed before the original was redacted, this minimal scan does not revisit it. To promise complete current-policy representatives at terminal time, retain every matching member or candidate grouping and reselect authorized representatives at replay/completion; that increases state and revalidation. Otherwise label dedup as emission-time suppression and completeness as searched generation coverage, not an exact final distinct live-result set. This is an open product/implementation decision, not proven completeness.

Arbitrary regex verification must not advance past an unverified body. Independent chunks are unsafe. Atomic whole-message verification with an explicit oversized/blocked result is honest but does not guarantee eventual progress under an unchanged cap. Exact resumable within-message matching and cancellation are not implemented. NULL timestamps and PostgreSQL tuple predicates are not exercised by this integer-timestamp model.

All snapshot evidence, including initial preview hits, must be from the pinned generation or explicitly marked outside its coverage. Exact copy counts evolve across pages and must be provisional. Dedup/retry storage grows with results; production limits, eviction, crash recovery and durable expiry are untested. Broad mutation-epoch restart is included only as a counterexample safety baseline and is not recommended for an active team.

Primary PostgreSQL sources: https://www.postgresql.org/docs/current/transaction-iso.html and https://www.postgresql.org/docs/current/functions-sequence.html .
