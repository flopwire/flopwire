"""Protocol model: immutable intake boundary, mutation epoch, server scan state."""
from dataclasses import dataclass
import copy, hashlib, unittest

@dataclass
class Row:
    id: int
    ts: int
    body: str
    intake: int
    visible: bool = True

class Archive:
    def __init__(self, rows):
        self.rows = {r.id:r for r in rows}; self.epoch = 0
        self.committed_intake = max((r.intake for r in rows), default=0)
    def append(self, row):
        assert row.intake > self.committed_intake
        self.rows[row.id] = row; self.committed_intake = row.intake
    def mutate(self, id, **changes):
        for k,v in changes.items(): setattr(self.rows[id],k,v)
        self.epoch += 1
    def delete(self,id): del self.rows[id]; self.epoch += 1

class Scan:
    def __init__(self, archive, tenant='team', principal='reader', query='needle', now=0):
        self.archive=archive; self.tenant=tenant; self.principal=principal; self.query=query
        self.cutoff=archive.committed_intake; self.epoch=archive.epoch; self.expires=now+60
        self.after=None; self.seen=set(); self.sequence=0; self.cache={}
    def page(self, sequence, budget, tenant='team', principal='reader', query='needle', now=0, cancel=False):
        if (tenant,principal,query)!=(self.tenant,self.principal,self.query): raise ValueError('binding')
        if now >= self.expires: raise ValueError('expired')
        if self.archive.epoch != self.epoch: raise ValueError('corpus_changed_restart_required')
        if sequence in self.cache: return copy.deepcopy(self.cache[sequence])
        if sequence != self.sequence: raise ValueError('sequence')
        # State only advances with committed response. Cancellation before commit changes nothing.
        after=self.after; seen=set(self.seen); hits=[]; scanned=0
        rows=sorted((r for r in self.archive.rows.values() if r.intake<=self.cutoff),key=lambda r:(r.ts,r.id),reverse=True)
        rows=[r for r in rows if after is None or (r.ts,r.id)<after]
        for r in rows:
            if len(r.body)>budget: break # Atomic message, never advance past unverified text.
            budget-=len(r.body); scanned+=1; after=(r.ts,r.id)
            sha=hashlib.sha256(r.body.encode()).digest()
            if r.visible and self.query in r.body and sha not in seen: hits.append(r.id); seen.add(sha)
        if cancel: raise ValueError('cancelled')
        remaining=[r for r in rows if after is None or (r.ts,r.id)<after]
        out={'hits':hits,'scanned':scanned,'complete':not remaining,'blocked_message':remaining[0].id if remaining and scanned==0 else None}
        self.after=after; self.seen=seen; self.sequence+=1; self.cache[sequence]=out
        return copy.deepcopy(out)

class ProtocolTests(unittest.TestCase):
    def archive(self): return Archive([Row(1,10,'needle-a',1),Row(2,10,'needle-b',2),Row(3,9,'needle-a',3)])
    def test_naive_timestamp_cursor_loses_tie(self):
        a=self.archive(); first=max(a.rows.values(),key=lambda r:r.ts)
        rest=[r.id for r in a.rows.values() if r.ts<first.ts]
        self.assertNotIn(2,rest) # Demonstrates broken naive cursor.
    def test_correct_ties_dedup_and_completion(self):
        s=Scan(self.archive()); self.assertEqual(s.page(0,8)['hits'],[2]); self.assertEqual(s.page(1,8)['hits'],[1])
        p=s.page(2,8); self.assertEqual(p['hits'],[]); self.assertTrue(p['complete'])
    def test_late_ingestion_frozen_boundary(self):
        a=self.archive(); s=Scan(a); s.page(0,8)
        a.append(Row(4,100,'needle-late',4)); a.append(Row(5,1,'needle-late-old',5))
        self.assertEqual(s.page(1,100)['hits'],[1]); self.assertEqual(Scan(a).page(0,100)['hits'],[4,2,1,5])
    def test_every_mutation_requires_restart_even_on_retry(self):
        for mutation in ('body','ts','visible','delete'):
            a=self.archive(); s=Scan(a); s.page(0,8)
            if mutation=='delete': a.delete(1)
            else: a.mutate(1,**{mutation:{'body':'needle-new','ts':100,'visible':False}[mutation]})
            with self.assertRaisesRegex(ValueError,'corpus_changed'): s.page(1,100)
            with self.assertRaisesRegex(ValueError,'corpus_changed'): s.page(0,8) # Do not replay redacted result.
    def test_empty_incomplete_differs_from_empty_complete(self):
        a=Archive([Row(1,1,'nothing',1)]); s=Scan(a)
        p=s.page(0,1); self.assertEqual(p['hits'],[]); self.assertFalse(p['complete']); self.assertEqual(p['blocked_message'],1)
        self.assertTrue(s.page(1,100)['complete'])
    def test_cancellation_retry_and_binding_expiry(self):
        s=Scan(self.archive())
        with self.assertRaisesRegex(ValueError,'cancelled'):s.page(0,8,cancel=True)
        self.assertIsNone(s.after); p=s.page(0,8); self.assertEqual(p,s.page(0,1))
        for changes in ({'tenant':'other'},{'principal':'other'},{'query':'different'},{'now':60}):
            with self.assertRaises(ValueError):s.page(1,100,**changes)
    def test_naive_chunking_misses_cross_boundary(self):
        body='xxneedlexx'; chunks=[body[:5],body[5:]]
        self.assertTrue('needle' in body); self.assertFalse(any('needle' in c for c in chunks))
    def test_offset_is_not_resume(self):
        s=Scan(Archive([Row(1,10,'nohit',1),Row(2,9,'needle',2)]))
        self.assertEqual(s.page(0,5)['hits'],[]); self.assertEqual(s.page(1,100)['hits'],[2])
        self.assertEqual(Scan(s.archive).page(0,5)['hits'],[]) # Reissuing offset=0 repeats prefix.
    def test_sequence_allocation_is_not_commit_watermark(self):
        allocated=2; committed={2}; cutoff=allocated
        eligible_at_start={i for i in committed if i<=cutoff}; committed.add(1)
        self.assertNotEqual(eligible_at_start,{i for i in committed if i<=cutoff})

class GenerationTests(unittest.TestCase):
    def test_sealed_generation_snapshot_and_current_authority(self):
        a=Archive([Row(1,10,'needle-old',1),Row(2,9,'needle-two',2)])
        generation=copy.deepcopy(a.rows) # Model assumes an existing immutable generation, not live manifest construction.
        a.mutate(1,body='ordinary-update'); a.append(Row(3,20,'needle-future',3))
        hits=[r.id for r in generation.values() if 'needle' in r.body and r.id in a.rows and a.rows[r.id].visible]
        self.assertEqual(hits,[1,2]) # Valid only as explicitly historical indexed snapshot evidence.
        a.mutate(1,visible=False) # Redaction/policy overriding historical snapshot.
        filtered_replay=[id for id in hits if id in a.rows and a.rows[id].visible]
        self.assertEqual(filtered_replay,[2]); self.assertNotIn(3,generation)
    def test_terminal_page_retry_needs_cached_result(self):
        s=Scan(Archive([Row(1,1,'needle',1)])); terminal=s.page(0,100)
        self.assertTrue(terminal['complete']); self.assertEqual(s.page(0,100),terminal)
        s.archive.mutate(1,visible=False)
        with self.assertRaisesRegex(ValueError,'corpus_changed'):s.page(0,100)


# Recommended architecture model. Publication is an input assumption:
# caller supplies an already durable immutable indexed generation.
import threading
from collections import defaultdict

class Authority:
    def __init__(self, generation):
        self.lock=threading.RLock(); self.allowed={'reader'}
        self.current={r.id:(1,r.visible) for r in generation}
    def permit(self, principal, id, version):
        return principal in self.allowed and self.current.get(id)==(version,True)
    def revoke(self,id):
        with self.lock:self.current[id]=(self.current[id][0],False)
    def update(self,id):
        with self.lock:self.current[id]=(self.current[id][0]+1,True)

class GenerationScan:
    def __init__(self, generation, authority, tenant='team', principal='reader', now=0):
        self.rows=tuple(sorted(copy.deepcopy(generation),key=lambda r:(r.ts,r.id),reverse=True))
        self.authority=authority; self.tenant=tenant; self.principal=principal
        self.query='needle';self.expires=now+60;self.lock=threading.Lock()
        self.position=0;self.sequence=0;self.emitted=defaultdict(set);self.pages={}
    def page(self, sequence, budget, tenant='team', principal='reader', query='needle', now=0,cancel=False):
        # Serializes page state and the model authority fence. Production must
        # implement atomic CAS and define authorization consistency point.
        with self.lock,self.authority.lock:
            if (tenant,principal,query)!=(self.tenant,self.principal,self.query):raise ValueError('binding')
            if principal not in self.authority.allowed:raise ValueError('unauthorized')
            if now>=self.expires:raise ValueError('expired')
            if sequence in self.pages:return self.render(self.pages[sequence])
            if sequence!=self.sequence:raise ValueError('sequence')
            position=self.position; emitted=copy.deepcopy(self.emitted);ids=[];scanned=0
            while position<len(self.rows):
                row=self.rows[position]
                if len(row.body)>budget:break
                budget-=len(row.body);scanned+=1;position+=1
                if not row.visible or not self.authority.permit(principal,row.id,1) or self.query not in row.body:continue
                sha=hashlib.sha256(row.body.encode()).digest()
                # Suppression remains active only while an emitted representative
                # still passes the current authority/version fence.
                representatives={id for id in emitted[sha] if self.authority.permit(principal,id,1)}
                emitted[sha]=representatives
                if representatives:continue
                ids.append(row.id);emitted[sha].add(row.id)
            if cancel:raise ValueError('cancelled')
            page={'ids':tuple(ids),'complete':position==len(self.rows),'scanned':scanned,'position':position}
            self.position=position;self.emitted=emitted;self.pages[sequence]=page;self.sequence+=1
            return self.render(page)
    def render(self,page):
        # Stored page contains only IDs, not plaintext. In production hydration
        # must check exact permitted version; this returns IDs to model that fence.
        return {**page,'ids':[id for id in page['ids'] if self.authority.permit(self.principal,id,1)]}

class RecommendedGenerationTests(unittest.TestCase):
    def setup_scan(self):
        rows=[Row(1,10,'needle-copy',1),Row(2,9,'needle-copy',2),Row(3,8,'needle-other',3)]
        authority=Authority(rows);return GenerationScan(rows,authority),authority,rows
    def test_snapshot_published_membership_is_immutable(self):
        s,a,rows=self.setup_scan();rows.append(Row(4,20,'needle-later',4));rows[0].body='changed'
        self.assertEqual(s.page(0,100)['ids'],[1,3]);self.assertEqual(len(s.rows),3)
    def test_redacted_copy_does_not_suppress_permitted_later_copy(self):
        s,a,_=self.setup_scan();self.assertEqual(s.page(0,11)['ids'],[1]);a.revoke(1)
        self.assertEqual(s.page(0,11)['ids'],[]);self.assertEqual(s.page(1,11)['ids'],[2])
    def test_current_version_suppression_and_future_version_exclusion(self):
        s,a,_=self.setup_scan();a.update(1)
        self.assertEqual(s.page(0,100)['ids'],[2,3]) # Version 2 is outside indexed generation.
    def test_reauth_including_terminal_replay(self):
        s,a,_=self.setup_scan();p=s.page(0,100);self.assertTrue(p['complete']);a.revoke(3)
        self.assertEqual(s.page(0,100)['ids'],[1]);a.allowed.clear()
        with self.assertRaisesRegex(ValueError,'unauthorized'):s.page(0,100)
    def test_concurrent_same_sequence_is_idempotent_single_commit(self):
        s,a,_=self.setup_scan();barrier=threading.Barrier(3);results=[]
        def worker():
            barrier.wait();results.append(s.page(0,11))
        threads=[threading.Thread(target=worker) for _ in range(2)]
        for t in threads:t.start()
        barrier.wait()
        for t in threads:t.join()
        self.assertEqual(results[0],results[1]);self.assertEqual(s.position,1);self.assertEqual(s.sequence,1)
    def test_cancel_then_retry_does_not_advance(self):
        s,a,_=self.setup_scan()
        with self.assertRaisesRegex(ValueError,'cancelled'):s.page(0,11,cancel=True)
        self.assertEqual(s.position,0);self.assertEqual(s.sequence,0);self.assertEqual(dict(s.emitted),{})
        self.assertEqual(s.page(0,11)['ids'],[1])
    def test_binding_expiry_and_empty_completion(self):
        s,a,_=self.setup_scan()
        for changes in ({'tenant':'other'},{'principal':'other'},{'query':'other'},{'now':60}):
            with self.assertRaises(ValueError):s.page(0,100,**changes)
        p=s.page(0,1);self.assertEqual(p['ids'],[]);self.assertFalse(p['complete']);self.assertEqual(p['position'],0)
        for id in a.current:a.revoke(id)
        p=s.page(1,100);self.assertEqual(p['ids'],[]);self.assertTrue(p['complete'])

class FinalScopeTests(unittest.TestCase):
    def test_later_unhide_does_not_expand_initial_generation_scope(self):
        rows=[Row(1,10,'needle-hidden',1,False),Row(2,9,'needle-visible',2)]
        authority=Authority(rows);scan=GenerationScan(rows,authority)
        authority.current[1]=(1,True) # Later permission only applies to a new search.
        self.assertEqual(scan.page(0,100)['ids'],[2])
    def test_empty_terminal_replay_does_not_mean_scan_level_absence(self):
        rows=[Row(1,10,'needle-copy',1),Row(2,9,'needle-copy',2)]
        authority=Authority(rows);scan=GenerationScan(rows,authority)
        self.assertEqual(scan.page(0,11)['ids'],[1])
        terminal=scan.page(1,11);self.assertTrue(terminal['complete']);self.assertEqual(terminal['ids'],[])
        authority.revoke(1)
        self.assertEqual(scan.page(0,11)['ids'],[])
        self.assertEqual(scan.page(1,11)['ids'],[])
        self.assertTrue(authority.permit('reader',2,1)) # Permitted duplicate remains, but was already scanned/suppressed.
        self.assertEqual(GenerationScan(rows,authority).page(0,100)['ids'],[2])

if __name__=='__main__': unittest.main(verbosity=2)
