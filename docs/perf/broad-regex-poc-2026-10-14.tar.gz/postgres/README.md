# Isolated PostgreSQL broad-regex POC

PostgreSQL 16.15 Homebrew, Python 3.14, psycopg and psycopg-binary 3.3.6. Production measurements used PostgreSQL 17.6; these results do not qualify that environment.

Run from the POC worktree. Use only the dedicated cluster below.

```sh
python3 -m venv .poc-stress-test/postgres/venv
.poc-stress-test/postgres/venv/bin/pip install 'psycopg[binary]==3.3.6'
initdb -D .poc-stress-test/postgres/data -A trust --no-locale -E UTF8
pg_ctl -D .poc-stress-test/postgres/data -l .poc-stress-test/postgres/server.log -o '-p 55439 -k /tmp -c listen_addresses= -c max_connections=10' start
.poc-stress-test/postgres/venv/bin/python .poc-stress-test/postgres/generate_corpus.py
.poc-stress-test/postgres/venv/bin/python .poc-stress-test/postgres/bench.py --setup
.poc-stress-test/postgres/venv/bin/python .poc-stress-test/postgres/bench.py
pg_ctl -D .poc-stress-test/postgres/data stop -m fast
```

Results retain three sequential exploratory repetitions per query, rather than a randomized controlled comparison. Do not derive p95 or production promises. Candidate timings exclude hydration; end-to-end timing includes full candidate-body hydration and Python regex verification. That verifier shares the ASCII regex subset here, but is not the production Go RE2 implementation. Oracle reads the complete same-scope text and compares ordered verified message IDs exactly. No LIMIT removes rows in this 50,000-message corpus.

The scattered-gram diagnostic represents weak candidate planning. The baseline uses current whole-literal ILIKE predicates. SQL native regex is an ASCII-only alternative for these fixtures, not a generally safe replacement for Go RE2 semantics.

Corpus SHA256: `95433ec52159daa65a4dc760c407f08ece41081b3f16d98c26cc44cfd042c211`.

Archive source files and small JSON results. Exclude corpus, cluster data, logs with bodies, and venv. Stop the cluster before deleting the POC directory.
