import psycopg, time, json, re, random, pathlib
ROOT=pathlib.Path(__file__).parent
db=psycopg.connect('host=/tmp port=55439 dbname=postgres',autocommit=True)
db.execute("SET statement_timeout='30s'")
if '--setup' in __import__('sys').argv:
    db.execute('SET statement_timeout=0')
    setup_start=time.perf_counter()
    db.execute('CREATE EXTENSION pg_trgm')
    db.execute('CREATE TABLE messages(id bigint PRIMARY KEY, ts bigint, scope int, text text)')
    # Distinct repeated hashes avoid giant vocabulary while forcing whole-body work.
    with db.cursor().copy('COPY messages(id,ts,scope,text) FROM STDIN') as copy:
      for line in (ROOT/'corpus.jsonl').open():
        row=json.loads(line);copy.write_row((row['id'],row['ts'],row['scope'],row['text']))
    index_start=time.perf_counter()
    db.execute('CREATE INDEX text_gin ON messages USING gin(text gin_trgm_ops)')
    index_ms=(time.perf_counter()-index_start)*1000
    db.execute('CREATE INDEX scope_idx ON messages(scope)')
    db.execute('ANALYZE messages')
    info=db.execute('SELECT count(*),sum(octet_length(text)),pg_total_relation_size(\'messages\') FROM messages').fetchone()
    info={'setup':info,'setup_ms':(time.perf_counter()-setup_start)*1000,'gin_index_ms':index_ms}
    (ROOT/'setup.json').write_text(json.dumps(info,indent=2))
    print(json.dumps(info)); __import__('sys').exit()
fixtures=[('scattered','heron', "text ILIKE '%heron%'", "text ILIKE '%her%' AND text ILIKE '%ero%' AND text ILIKE '%ron%'"),
 ('broad_or','timeout|failure',"text ILIKE '%timeout%' OR text ILIKE '%failure%'",None),
 ('rare_old','ancientneedle',"text ILIKE '%ancientneedle%'",None)]
out=[]
for name,regex,baseline,whole in fixtures:
    for scope in ['', ' AND scope=0']:
        oracle=[row[0] for row in db.execute('SELECT id,text FROM messages WHERE true'+scope+' ORDER BY ts DESC,id') if re.search(regex,row[1],re.I)]
        variants=[('baseline',baseline),('native_regex','text ~* '+"'"+regex+"'")]
        if whole:variants.append(('gram_diagnostic',whole))
        for memory in ['4MB','32MB']:
            db.execute("SET work_mem='"+memory+"'")
            for variant,predicate in variants:
                sql='SELECT id FROM messages WHERE ('+predicate+')'+scope+' ORDER BY ts DESC,id LIMIT 200000'
                runs=[]
                for repetition in range(3):
                    start=time.perf_counter()
                    with db.transaction():
                        cursor=db.cursor(name='candidates')
                        cursor.execute(sql)
                        first=cursor.fetchmany(256); first_ms=(time.perf_counter()-start)*1000
                        ids=[r[0] for r in first]+[r[0] for r in cursor.fetchall()]
                    total_ms=(time.perf_counter()-start)*1000
                    # Verify full RE2-compatible subset against Python oracle; ASCII fixtures only.
                    bodies=dict(db.execute('SELECT id,text FROM messages WHERE id=ANY(%s)',(ids,)))
                    verified=[i for i in ids if re.search(regex,bodies[i],re.I)]
                    assert verified==oracle,(name,variant,len(verified),len(oracle))
                    runs.append({'candidate_first_ms':first_ms,'candidate_total_ms':total_ms,'hydrate_verify_ms':(time.perf_counter()-start)*1000-total_ms,'end_to_end_ms':(time.perf_counter()-start)*1000})
                plan=db.execute('EXPLAIN (ANALYZE,BUFFERS,SETTINGS,FORMAT JSON) '+sql).fetchone()[0][0]
                entry={'case':name,'scope':scope,'memory':memory,'variant':variant,'candidate_count':len(ids),'oracle_count':len(oracle),'runs':runs,'plan':plan}
                out.append(entry)
                (ROOT/'results.json').write_text(json.dumps(out,indent=2))
                print(json.dumps({k:v for k,v in entry.items() if k!='plan'}),flush=True)
