import hashlib,json,pathlib
p=pathlib.Path(__file__).parent/'corpus.jsonl'
with p.open('w') as f:
 for i in range(1,50001):
  text=' '.join(hashlib.md5(f'{i}:{j}'.encode()).hexdigest() for j in range(1,65))+' her xxx ero xxx ron '
  if i%100==0:text+=' heron protocol '
  if i%5==0:text+=' timeout '
  elif i%7==0:text+=' failure '
  if i<=50:text+=' ancientneedle '
  if i%500==0:text*=128
  f.write(json.dumps({'id':i,'ts':i,'scope':i%100,'text':text})+'\n')
print(p)
