# PostgreSQL exploratory results

50,000 messages; 134,144,076 logical text bytes (127.9 MiB), 304,316,416 total table/index/TOAST bytes. Each ordinary message has ~2 KiB; 100 messages have ~270 KiB. Full shared deterministic JSONL SHA256 is in README. GIN build observed at4m02s and completed before next poll (approximately <5min); exact initial setup/index timers were absent. The reproducible script now records exact setup/index durations.

All28 variant/scope/memory cases passed exact ordered result equality against a complete same-scope Python ASCII-regex oracle, with three measured sequential repetitions each. Results JSON holds all plans and samples. These are warm exploratory screening results, not a controlled comparison or production qualification. No p95 claim.

Median milliseconds at4MiB work_mem:

| Pattern/scope | Whole-literal ILIKE candidate first page | ILIKE full hydrate+verify | Native regex candidate first page | Native full hydrate+verify |
|---|---:|---:|---:|---:|
| heron/all |400|471|565|666|
| timeout or failure/all |245|1198|255|1235|
| ancientneedle/all |0.93|2.34|1.01|2.35|
| heron/scope0 |44|113|32|206|
| timeout or failure/scope0 |45|126|35|113|

The baseline uses the latest whole-literal prefilter. Native PostgreSQL regex did not produce a material broad-query improvement here. Native SQL regex is only semantically interchangeable within these ASCII fixtures; production keeps Go RE2 semantics.

The crucial confirmed mechanism: heron/all rejected49,500 rows during GIN heap recheck despite0 lossy blocks. Both ILIKE and native regex plans touched417 exact heap blocks. This proves exact tuple bitmap storage does not make the text predicate exact. The scattered-gram diagnostic returned50,000 candidates versus500 true matches and cost~3.76s end-to-end; this weak-planner diagnostic is not the current baseline.

Metadata scope0 reduced the baseline heron end-to-end median471→113ms and broad OR1198→126ms. This is scope reduction, not equivalent unscoped work. Most plans used BitmapAnd with the scope index. The scattered-gram scoped diagnostic instead chose text bitmap with a scope filter and remained slow.

Increasing work_mem4→32MiB did not remove any lossy blocks: every plan already had0. Broad OR full verification medians~1198→1044ms while heron medians471→593ms; sequential noise and workload mean no confident memory benefit. This small heap does not reproduce production66k lossy blocks. No chronological segmented index variant was tested. No limits truncate this50k corpus. Full hydration includes Python regex work, not the production Go collector, line hit formatting, session metadata, or HTTP response cost. Candidate startup is not first verified hit latency.

Dedicated cluster used port 55439, Unix socket /tmp, TCP disabled, and data directory .poc-stress-test/postgres/data. Stopped successfully using pg_ctl fast shutdown after benchmarks. Keep only sources/results for archiving; the parent coordinates deletion after the comparison finishes reading the shared corpus.
