# Results

Embedded search works without an external service. Default Zoekt indexing is not exhaustive for Flopwire-shaped messages.

Shared deterministic corpus: 50,000 documents, 134,144,076 content bytes. Unrestricted build7.09s; scope-run rebuild6.26s. Index409,506,103bytes,3.05x text. Go1.26.6/darwin arm64; sourcegraph/zoekt4abc8196181a. No cache flush, no hosted concurrency test. First/repeated query samples are observations, not p95/p99.

| Pattern | Unrestricted milliseconds (3 samples) | Matches | Final content bytes loaded |
|---|---|---|---|
| heron |1060.34,74.33,19.96|500|28,473,400|
| timeout or failure |350.95,52.66,37.14|15,714|61,077,242|
| ancientneedle |1.37,.156,.178|50|107,594|
| [A-Za-z]{30} |3479.18,2981.78,2760.74|0|134,144,076|

Scope0: heron322.44,23.75,19.06ms; common5.79,7.80,7.75ms; ancientneedle.164,.073,.052ms; literal-free632.74,660.09,623.62ms. Scope0 includes500messages and all100expanded large messages; literal-free scans28,472,400bytes. Final-repeat IDs equal Go regexp; no skips/crashes reported. Raw stats/equality describe finalrepeat only. Go oracle is complete in-memory regex scan, not SQL/network work.

Default semantic fixtures miss >2MiB messages, 2byte messages, NUL-containing messages and100KB high-diversity ASCII. LargeFiles glob restores large/high-diversity; short/NUL still miss. Larger SizeMax alone does not disable trigram diversity check. Skipped docs retain synthetic marker bodies, requiring eligibility tracking and authoritative fallback/exclusion. NUL cannot be stored in PG text; map to actual normalization before treating as production gap.

Multiline newline regex, Unicode Kelvin/sigma/accent folding and duplicated bodies returned under distinct filenames match Go regexp in fixtures. These checks compare document IDs, not match offsets. Multiline pattern spans lines within one message. No claim about Unicode beyond tested cases.

No built-in timestamp sorting or durable resumable cursor established. Search ordering uses relevance score and extension boost. A Search call captures shard references; subsequent calls can observe replacement. Progress is within-call shard priority bookkeeping. Append/redaction/ACL recovery is unimplemented. Production cap reportedly16MiB; fixture override8MiB is not sufficient production policy.

PG agent's candidate-only latency and this fullmatch/range formatting latency are different workloads. Production comparison needs same ordered/paginated output, exact completion, authorization and ingestion eligibility behavior. Dedicated search might be useful, but extra-service-free embedding still adds index files, update coordination, API maintenance and roughly3x storage in this synthetic test.
