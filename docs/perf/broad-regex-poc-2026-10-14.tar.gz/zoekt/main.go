package main

import (
	"bufio"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/sourcegraph/zoekt"
	"github.com/sourcegraph/zoekt/index"
	"github.com/sourcegraph/zoekt/query"
	"github.com/sourcegraph/zoekt/search"
	"math/rand"
	"os"
	"path/filepath"
	"regexp"
	"regexp/syntax"
	"sort"
	"strings"
	"time"
)

type doc struct{ Name, Body string }

func main() {
	mb := flag.Int("mb", 50, "approximate corpus MB")
	corpus := flag.String("corpus", "", "JSONL shared corpus id,text,ts")
	scope := flag.Int("scope", -1, "filter shared scope; -1 unrestricted")
	bypass := flag.Bool("bypass", false, "large-file glob bypass distinct-trigram check")
	large := flag.Bool("allow-large", false, "raise document cap to 8MB")
	flag.Parse()
	docs := []doc{}
	base := "User: investigate deployment configuration and compare implementation tradeoffs.\nAssistant: inspect session state, repository permissions, migration workflow and test results.\nTool: output compiled successfully; pending review.\n"
	body := strings.Repeat(base, 18)
	for i := 0; i < (*mb<<20)/len(body); i++ {
		s := body
		if i == 0 {
			s += "ancient_needle_7f93\n"
		}
		if i%31 == 0 {
			s += "authorization_token\n"
		}
		if i%47 == 0 {
			s += "migration_marker\n"
		}
		if i%19 == 0 {
			s += "sct ctt att tte ter ere red edg dgr gra ram ams\n"
		}
		docs = append(docs, doc{fmt.Sprintf("messages/%08d.txt", i), s})
	}
	docs = append(docs, doc{"special/multiline.txt", strings.Repeat(base, 400) + "boundary_alpha\ncontinued_beta\n"}, doc{"special/unicode.txt", "Kelvin K k K; sigma Σ σ ς; Straße STRASSE; École école\n"}, doc{"special/large.txt", strings.Repeat("large conversation output\n", 130000) + "large_tail_needle\n"}, doc{"special/duplicate-a.txt", "duplicate_exact_needle"}, doc{"special/duplicate-b.txt", "duplicate_exact_needle"})
	rng := rand.New(rand.NewSource(91))
	random := make([]byte, 100000)
	for i := range random {
		random[i] = byte(33 + rng.Intn(90))
	}
	docs = append(docs, doc{"special/short.txt", "xy"}, doc{"special/nul.txt", "prefix\x00nulneedle"}, doc{"special/diverse.txt", string(random) + "diverseneedle"})
	if *corpus != "" {
		docs = nil
		f, e := os.Open(*corpus)
		must(e)
		scanner := bufio.NewScanner(f)
		scanner.Buffer(make([]byte, 65536), 16<<20)
		for scanner.Scan() {
			var v struct {
				ID    json.RawMessage `json:"id"`
				Text  string          `json:"text"`
				Scope int             `json:"scope"`
			}
			must(json.Unmarshal(scanner.Bytes(), &v))
			docs = append(docs, doc{fmt.Sprintf("scope/%03d/messages/%s.txt", v.Scope, strings.Trim(string(v.ID), "\"")), v.Text})
		}
		must(scanner.Err())
		f.Close()
	}
	total := 0
	for _, d := range docs {
		total += len(d.Body)
	}
	dir := "index"
	if *large {
		dir = "index-large"
	}
	os.RemoveAll(dir)
	opts := index.Options{IndexDir: dir, RepositoryDescription: zoekt.Repository{Name: "conversations", ID: 1}, DisableCTags: true, Parallelism: 1}
	if *large {
		opts.SizeMax = 8 << 20
	}
	if *bypass {
		opts.LargeFiles = []string{"**"}
	}
	t := time.Now()
	b, e := index.NewBuilder(opts)
	must(e)
	for _, d := range docs {
		must(b.AddFile(d.Name, []byte(d.Body)))
	}
	must(b.Finish())
	build := time.Since(t)
	size := int64(0)
	filepath.Walk(dir, func(_ string, info os.FileInfo, e error) error {
		if e == nil && !info.IsDir() {
			size += info.Size()
		}
		return e
	})
	emit(map[string]any{"kind": "build", "corpus_bytes": total, "documents": len(docs), "index_bytes": size, "elapsed_ms": float64(build.Microseconds()) / 1000, "allow_large": *large})
	s, e := search.NewDirectorySearcher(dir)
	must(e)
	defer s.Close()
	patterns := []string{"ancient_needle_7f93", "authorization_token|migration_marker", "scatteredgrams", "boundary_alpha\ncontinued_beta", "(?i)k", "(?i)σ", "(?i)école", "[0-9]+", "[A-Za-z]{30}", "large_tail_needle", "duplicate_exact_needle", "^xy$", "nulneedle", "diverseneedle"}
	if *corpus != "" {
		patterns = []string{"(?i)heron", "(?i)timeout|failure", "(?i)ancientneedle", "[A-Za-z]{30}"}
	}
	for _, p := range patterns {
		oracleStart := time.Now()
		r := regexp.MustCompile(p)
		want := []string{}
		for _, d := range docs {
			if (*scope < 0 || strings.HasPrefix(d.Name, fmt.Sprintf("scope/%03d/", *scope))) && r.MatchString(d.Body) {
				want = append(want, d.Name)
			}
		}
		oracleMS := float64(time.Since(oracleStart).Microseconds()) / 1000
		sr, e := syntax.Parse(p, syntax.Perl)
		must(e)
		var q query.Q = &query.Regexp{Regexp: sr, Content: true, CaseSensitive: true}
		if *scope >= 0 {
			q = &query.And{Children: []query.Q{q, &query.Substring{Pattern: fmt.Sprintf("scope/%03d/", *scope), FileName: true, CaseSensitive: true}}}
		}
		lat := []float64{}
		var out *zoekt.SearchResult
		for j := 0; j < 3; j++ {
			t = time.Now()
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			out, e = s.Search(ctx, q, &zoekt.SearchOptions{ShardMaxMatchCount: 100000000, TotalMaxMatchCount: 100000000, MaxDocDisplayCount: 1000000})
			cancel()
			if e != nil {
				emit(map[string]any{"kind": "query_error", "pattern": p, "error": e.Error()})
				break
			}
			lat = append(lat, float64(time.Since(t).Microseconds())/1000)
		}
		if out == nil {
			continue
		}
		got := []string{}
		for _, f := range out.Files {
			got = append(got, f.FileName)
		}
		sort.Strings(got)
		sort.Strings(want)
		missing := diff(want, got)
		extra := diff(got, want)
		emit(map[string]any{"kind": "query", "pattern": p, "oracle_ms": oracleMS, "scope": *scope, "latency_ms": lat, "expected_docs": len(want), "actual_docs": len(got), "missing": missing, "extra": extra, "complete_by_stats": out.FilesSkipped == 0 && out.ShardsSkipped == 0 && out.Crashes == 0, "stats": out.Stats})
	}
}
func diff(a, b []string) []string {
	m := map[string]bool{}
	for _, v := range b {
		m[v] = true
	}
	o := []string{}
	for _, v := range a {
		if !m[v] {
			o = append(o, v)
		}
	}
	return o
}
func must(e error) {
	if e != nil {
		panic(e)
	}
}
func emit(v any) { b, e := json.Marshal(v); must(e); fmt.Println(string(b)) }
