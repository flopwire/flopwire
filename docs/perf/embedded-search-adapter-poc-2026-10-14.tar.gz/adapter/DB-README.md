# Isolated test database

Use cached `postgres:17.6-bookworm`. The dedicated container uses loopback port 55449. Its data stays under the approved POC directory. No production database is used.

Run `sh .poc-stress-test/adapter/db-start.sh` once.

Change directory to `.poc-stress-test/adapter`. Run tests with `FLOPWIRE_TEST_DATABASE_URL='postgres://postgres:synthetic-adapter-poc@127.0.0.1:55449/postgres?sslmode=disable' go test -race -count=1 -v ./...`.

Each test calls `pgtest.NewDatabase`. The test database receives real migrations and is dropped by cleanup. Tests use synthetic bodies and real authenticated httptest API handlers.

Run `sh .poc-stress-test/adapter/db-stop.sh` when tests finish. Archive small source and test evidence before deleting the POC directory. Exclude dbdata.
