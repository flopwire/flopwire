package adapter

import (
	"context"
	"fmt"
	"reflect"
	"strings"

	"github.com/flopwire/flopwire/internal/client"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// HTTPAuthority exercises production auth and retrieval handlers. No cached
// credential or snapshot can authorize a response by itself.
type HTTPAuthority struct{ HTTP client.HTTP }

func (a HTTPAuthority) Check(ctx context.Context) error {
	var ignored any
	return a.HTTP.JSON(ctx, "GET", "/v1/sessions?limit=1", nil, &ignored)
}

// SnapshotPG is privileged server-side snapshot construction. The caller must
// authenticate with Authority.Check before calling it; it is not an endpoint.
// It supports default visibility plus exact agent, kinds, and message time.
// Session prefixes and subagent expansion are unsupported and rejected.
func SnapshotPG(ctx context.Context, pool *pgxpool.Pool, f format.Filters) ([]Document, error) {
	for _, kind := range f.Kinds {
		if kind == "injected" {
			return nil, fmt.Errorf("injected messages are unsupported by the POC scan")
		}
	}
	rest := f
	rest.Agent = ""
	rest.Kinds = nil
	rest.Since = format.Filters{}.Since
	rest.Until = format.Filters{}.Until
	if !reflect.DeepEqual(rest, format.Filters{}) {
		return nil, fmt.Errorf("unsupported POC snapshot filter")
	}
	tx, err := pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.RepeatableRead, AccessMode: pgx.ReadOnly})
	if err != nil {
		return nil, err
	}
	defer tx.Rollback(context.Background())
	where := []string{"c.hidden_at IS NULL", "NOT m.superseded", "m.on_active_path IS NOT FALSE"}
	args := []any{}
	arg := func(v any) string { args = append(args, v); return fmt.Sprintf("$%d", len(args)) }
	if f.Agent != "" {
		where = append(where, "c.agent="+arg(f.Agent))
	}
	if len(f.Kinds) > 0 {
		where = append(where, "m.kind=ANY("+arg(f.Kinds)+"::text[])")
	} else {
		where = append(where, "m.kind<>'injected'")
	}
	if !f.Since.IsZero() {
		where = append(where, "m.ts>="+arg(f.Since))
	}
	if !f.Until.IsZero() {
		where = append(where, "m.ts<"+arg(f.Until))
	}
	rows, err := tx.Query(ctx, `SELECT m.id::text,m.text,m.version,c.id::text,c.agent,c.session_id,m.ordinal,m.kind,COALESCE(m.tool_name,''),COALESCE(m.is_error,false),m.ts,
 COALESCE(c.title,''),COALESCE(c.repo_root,c.cwd,''),d.name,u.email,c.branches,
 COALESCE(s.id::text,''),COALESCE(s.path,''),m.source_generation,COALESCE(m.line_no,0),m.byte_offset,COALESCE(m.byte_len,0),COALESCE(m.locator,'')
 FROM messages m JOIN conversations c ON c.id=m.conversation_id JOIN devices d ON d.id=c.device_id JOIN users u ON u.id=c.user_id LEFT JOIN sources s ON s.id=m.source_id WHERE `+strings.Join(where, " AND ")+` ORDER BY m.id`, args...)
	if err != nil {
		return nil, err
	}
	docs := []Document{}
	for rows.Next() {
		var d Document
		h := &d.Hit
		if err = rows.Scan(&d.UUID, &d.Text, &d.Version, &h.ConversationID, &h.Agent, &h.SessionID, &h.Ordinal, &h.Kind, &h.ToolName, &h.IsError, &h.TS, &h.Title, &h.Repo, &h.Device, &h.User, &h.Branches, &h.Provenance.SourceID, &h.Provenance.Path, &h.Provenance.Generation, &h.Provenance.LineNo, &h.Provenance.ByteOffset, &h.Provenance.ByteLen, &h.Provenance.Locator); err != nil {
			rows.Close()
			return nil, err
		}
		d.ID = int64(len(docs) + 1)
		h.MessageID = d.UUID
		h.Address = format.MessageAddress(h.SessionID, h.Ordinal)
		docs = append(docs, d)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return nil, err
	}
	if err = tx.Commit(ctx); err != nil {
		return nil, err
	}
	return docs, nil
}

func (a HTTPAuthority) Current(ctx context.Context, id string) (format.Message, error) {
	out, err := a.HTTP.Read(ctx, format.ReadQuery{Address: id, MaxChars: 16 << 20}, format.Filters{})
	if err != nil {
		return format.Message{}, err
	}
	for _, m := range out.Messages {
		if m.ID == id {
			if m.Clipped || m.StoredLen > 0 && m.StoredLen < m.TextLen {
				return format.Message{}, fmt.Errorf("authoritative body incomplete")
			}
			return m, nil
		}
	}
	return format.Message{}, fmt.Errorf("authoritative response omitted exact message %s", id)
}
