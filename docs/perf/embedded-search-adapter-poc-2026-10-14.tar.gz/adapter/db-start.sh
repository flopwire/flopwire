#!/bin/sh
set -eu
task_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$task_root/dbdata"
docker run --name flopwire-adapter-poc-pg-20261014 -d -e POSTGRES_PASSWORD=synthetic-adapter-poc -p 127.0.0.1:55449:5432 -v "$task_root/dbdata:/var/lib/postgresql/data" postgres:17.6-bookworm
until docker exec flopwire-adapter-poc-pg-20261014 pg_isready; do sleep 1; done
