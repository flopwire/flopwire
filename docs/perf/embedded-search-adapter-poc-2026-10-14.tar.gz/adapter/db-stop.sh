#!/bin/sh
set -eu
docker stop flopwire-adapter-poc-pg-20261014
docker rm flopwire-adapter-poc-pg-20261014
