# Independent review

Method: Sol subagent, read-only source review against pinned Zoekt and current Flopwire handlers, followed by focused regression tests. The reviewer did not author index.go, scan.go, or authority.go.

Initial findings:

- P1: NewScan accepted an index and documents from different generations. This could claim complete absence incorrectly. Fixed with exact document-count/ID checks and SHA256 of each complete serialized document, including body and metadata.
- P2: q.Limit was ignored. Fixed by capping page candidate work using the requested limit.

Re-review found both fixes effective and no remaining material blocker within the isolated POC scope. It checked terminal replay, original nonmatch skipping, current server read scope, candidate coverage exclusions, and incomplete-index outcomes.

Remaining gates: durable publication, crash recovery, cursor persistence and identity binding, retention, startup bounds, hosted tenant isolation, and global duplicate semantics. Concurrent HTTP 429 outcomes are capacity failures, not successful searches.

After review, the parent extended only the timing harness TTL from one to five minutes because race instrumentation exceeded one minute, and made SnapshotPG reject an explicit injected-kind filter to match the scanner's supported subset. Final source hashes are in source-sha256.txt. The final full race run covers these changes.
