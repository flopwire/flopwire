package adapter

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"regexp/syntax"
	"sort"
	"strconv"
	"strings"
	"sync"

	"github.com/sourcegraph/zoekt"
	"github.com/sourcegraph/zoekt/index"
	"github.com/sourcegraph/zoekt/query"
)

// CandidateIndex owns fixed shard handles. Nothing watches or changes its directory.
// It returns supersets only; the caller must run its original Go regexp on authoritative text.
type CandidateIndex struct {
	mu       sync.RWMutex
	shards   []zoekt.Searcher
	all      []int64
	fallback []int64
	coverage map[int64]string
	hashes   map[int64][32]byte
	closed   bool
}

func BuildIndex(ctx context.Context, dir string, docs []Document) (*CandidateIndex, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if err := os.Mkdir(dir, 0700); err != nil {
		return nil, fmt.Errorf("new immutable directory: %w", err)
	}
	c := &CandidateIndex{coverage: make(map[int64]string), hashes: make(map[int64][32]byte)}
	b, err := index.NewBuilder(index.Options{IndexDir: dir, RepositoryDescription: zoekt.Repository{Name: "generation", ID: 1}, DisableCTags: true, Parallelism: 1})
	if err != nil {
		return nil, err
	}
	seen := map[int64]bool{}
	for _, d := range docs {
		if err := ctx.Err(); err != nil {
			_ = b.Finish()
			return nil, err
		}
		if seen[d.ID] {
			_ = b.Finish()
			return nil, fmt.Errorf("duplicate document %d", d.ID)
		}
		seen[d.ID] = true
		c.all = append(c.all, d.ID)
		hash, hashErr := documentHash(d)
		if hashErr != nil {
			_ = b.Finish()
			return nil, hashErr
		}
		c.hashes[d.ID] = hash
		reason := coverageReason(d.Text)
		c.coverage[d.ID] = reason
		if reason != "indexed" {
			c.fallback = append(c.fallback, d.ID)
			continue
		}
		if err = b.AddFile(strconv.FormatInt(d.ID, 10), []byte(d.Text)); err != nil {
			_ = b.Finish()
			return nil, err
		}
	}
	if err = b.Finish(); err != nil {
		return nil, err
	}
	paths, err := filepath.Glob(filepath.Join(dir, "*.zoekt"))
	if err != nil {
		return nil, err
	}
	for _, p := range paths {
		f, err := os.Open(p)
		if err != nil {
			c.Close()
			return nil, err
		}
		inf, err := index.NewIndexFile(f)
		if err != nil {
			f.Close()
			c.Close()
			return nil, err
		}
		s, err := index.NewSearcher(inf)
		if err != nil {
			inf.Close()
			c.Close()
			return nil, err
		}
		c.shards = append(c.shards, s)
	}
	sort.Slice(c.all, func(i, j int) bool { return c.all[i] < c.all[j] })
	sort.Slice(c.fallback, func(i, j int) bool { return c.fallback[i] < c.fallback[j] })
	if err := ctx.Err(); err != nil {
		c.Close()
		return nil, err
	}
	return c, nil
}

func coverageReason(s string) string {
	if len(s) < 3 {
		return "short"
	}
	if len(s) > 2<<20 {
		return "size"
	}
	grams := map[[3]byte]struct{}{}
	for i := 0; i < len(s); i++ {
		if s[i] == 0 {
			return "nul"
		}
		if s[i] >= 128 {
			return "non_ascii"
		}
		if i >= 2 {
			grams[[3]byte{s[i-2], s[i-1], s[i]}] = struct{}{}
			if len(grams) > 20000 {
				return "diversity"
			}
		}
	}
	return "indexed"
}

func (c *CandidateIndex) Coverage() map[int64]string {
	c.mu.RLock()
	defer c.mu.RUnlock()
	out := make(map[int64]string, len(c.coverage))
	for id, v := range c.coverage {
		out[id] = v
	}
	return out
}
func (c *CandidateIndex) Close() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if !c.closed {
		for _, s := range c.shards {
			s.Close()
		}
		c.closed = true
	}
	return nil
}

var ErrIncompleteCandidates = errors.New("candidate engine returned incomplete results")

func (c *CandidateIndex) Candidates(ctx context.Context, re *regexp.Regexp) ([]int64, error) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if c.closed {
		return nil, errors.New("index closed")
	}
	if re == nil {
		return nil, errors.New("nil regexp")
	}
	literals, ok := finiteLiterals(re.String())
	if !ok {
		return append([]int64(nil), c.all...), nil
	}
	atoms := make([]query.Q, 0, len(literals))
	for _, v := range literals {
		atoms = append(atoms, &query.Substring{Pattern: v, Content: true, CaseSensitive: false})
	}
	var q query.Q = &query.Or{Children: atoms}
	ids := map[int64]bool{}
	for _, id := range c.fallback {
		ids[id] = true
	}
	for _, s := range c.shards {
		result, err := s.Search(ctx, q, &zoekt.SearchOptions{ShardMaxMatchCount: math.MaxInt, TotalMaxMatchCount: math.MaxInt})
		if err != nil {
			return nil, err
		}
		if err = ctx.Err(); err != nil {
			return nil, err
		}
		if result == nil || result.FilesSkipped > 0 || result.ShardsSkipped > 0 || result.Crashes > 0 || result.FilesSkippedDueToCancellation > 0 || result.FileCount != len(result.Files) {
			return nil, ErrIncompleteCandidates
		}
		for _, f := range result.Files {
			id, err := strconv.ParseInt(f.FileName, 10, 64)
			if err != nil {
				return nil, fmt.Errorf("invalid candidate name: %w", err)
			}
			if _, exists := c.coverage[id]; !exists {
				return nil, fmt.Errorf("unknown candidate %d", id)
			}
			ids[id] = true
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	out := make([]int64, 0, len(ids))
	for id := range ids {
		out = append(out, id)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out, nil
}

// Enumerate a bounded finite language only. Ignore regex case flags by searching
// every ASCII literal without case sensitivity. Other regex features scan all IDs.
func finiteLiterals(pattern string) ([]string, bool) {
	for i := 0; i < len(pattern); i++ {
		if pattern[i] >= 128 {
			return nil, false
		}
	}
	r, err := syntax.Parse(pattern, syntax.Perl)
	if err != nil {
		return nil, false
	}
	out, ok := enumerate(r)
	if !ok || len(out) == 0 {
		return nil, false
	}
	seen := map[string]bool{}
	result := []string{}
	for _, v := range out {
		if len(v) < 3 {
			return nil, false
		}
		v = strings.ToLower(v)
		if !seen[v] {
			seen[v] = true
			result = append(result, v)
		}
	}
	return result, true
}
func enumerate(r *syntax.Regexp) ([]string, bool) {
	switch r.Op {
	case syntax.OpLiteral:
		for _, ch := range r.Rune {
			if ch <= 0 || ch >= 128 {
				return nil, false
			}
		}
		return []string{string(r.Rune)}, true
	case syntax.OpCapture:
		return enumerate(r.Sub[0])
	case syntax.OpCharClass:
		out := []string{}
		for i := 0; i < len(r.Rune); i += 2 {
			if r.Rune[i] <= 0 || r.Rune[i+1] >= 128 {
				return nil, false
			}
			for ch := r.Rune[i]; ch <= r.Rune[i+1]; ch++ {
				out = append(out, string(ch))
				if len(out) > 256 {
					return nil, false
				}
			}
		}
		return out, true
	case syntax.OpAlternate:
		out := []string{}
		for _, child := range r.Sub {
			v, ok := enumerate(child)
			if !ok {
				return nil, false
			}
			out = append(out, v...)
			if len(out) > 256 {
				return nil, false
			}
		}
		return out, true
	case syntax.OpConcat:
		out := []string{""}
		for _, child := range r.Sub {
			values, ok := enumerate(child)
			if !ok {
				return nil, false
			}
			if len(out)*len(values) > 256 {
				return nil, false
			}
			next := []string{}
			for _, a := range out {
				for _, b := range values {
					if len(a)+len(b) > 4096 {
						return nil, false
					}
					next = append(next, a+b)
				}
			}
			out = next
		}
		return out, true
	default:
		return nil, false
	}
}

// ValidateGeneration rejects incomplete or stale pairings before claiming absence.
func (c *CandidateIndex) ValidateGeneration(docs []Document) error {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if c.closed {
		return errors.New("index closed")
	}
	if len(docs) != len(c.hashes) {
		return errors.New("generation document count mismatch")
	}
	seen := map[int64]bool{}
	for _, d := range docs {
		if seen[d.ID] {
			return fmt.Errorf("duplicate generation ID %d", d.ID)
		}
		seen[d.ID] = true
		hash, ok := c.hashes[d.ID]
		actual, err := documentHash(d)
		if err != nil {
			return err
		}
		if !ok || hash != actual {
			return fmt.Errorf("generation mismatch for ID %d", d.ID)
		}
	}
	return nil
}

func documentHash(d Document) ([32]byte, error) {
	data, err := json.Marshal(d)
	if err != nil {
		return [32]byte{}, err
	}
	return sha256.Sum256(data), nil
}
