package adapter

import (
	"context"
	"errors"
	"math/rand"
	"path/filepath"
	"regexp"
	"slices"
	"sync"
	"testing"

	"github.com/sourcegraph/zoekt"
	"github.com/sourcegraph/zoekt/query"
)

func buildFixture(t *testing.T, docs []Document) *CandidateIndex {
	t.Helper()
	c, err := BuildIndex(context.Background(), filepath.Join(t.TempDir(), "generation"), docs)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { c.Close() })
	return c
}
func TestCoverageFallback(t *testing.T) {
	rng := rand.New(rand.NewSource(91))
	diverse := make([]byte, 100000)
	for i := range diverse {
		diverse[i] = byte(33 + rng.Intn(90))
	}
	docs := []Document{{ID: 1, Text: "xy"}, {ID: 2, Text: "prefix\x00needle"}, {ID: 3, Text: "KELVIN needle"}, {ID: 4, Text: string(make([]byte, (2<<20)+1)) + "needle"}, {ID: 5, Text: string(diverse) + "needle"}, {ID: 6, Text: "ordinary needle"}, {ID: 7, Text: "ordinary unrelated"}}
	c := buildFixture(t, docs)
	coverage := c.Coverage()
	want := map[int64]string{1: "short", 2: "nul", 3: "non_ascii", 4: "size", 5: "diversity", 6: "indexed", 7: "indexed"}
	for id, reason := range want {
		if coverage[id] != reason {
			t.Fatalf("coverage %d = %s, want %s", id, coverage[id], reason)
		}
	}
	for _, p := range []string{"needle", "xy", "(?i)kelvin", "needle|unrelated", "[a-z]+", "^xy$"} {
		assertCandidateOracle(t, c, docs, p)
	}
	ids, err := c.Candidates(context.Background(), regexp.MustCompile("needle"))
	if err != nil {
		t.Fatal(err)
	}
	if !slices.Equal(ids, []int64{1, 2, 3, 4, 5, 6}) {
		t.Fatalf("fallback IDs %v", ids)
	}
	coverage[6] = "tampered"
	if c.Coverage()[6] != "indexed" {
		t.Fatal("coverage must be copy")
	}
}
func assertCandidateOracle(t *testing.T, c *CandidateIndex, docs []Document, p string) {
	t.Helper()
	re := regexp.MustCompile(p)
	ids, err := c.Candidates(context.Background(), re)
	if err != nil {
		t.Fatal(err)
	}
	got := []int64{}
	want := []int64{}
	for _, d := range docs {
		matches := re.MatchString(d.Text)
		if matches {
			want = append(want, d.ID)
		}
		if slices.Contains(ids, d.ID) && matches {
			got = append(got, d.ID)
		}
	}
	if !slices.Equal(got, want) {
		t.Fatalf("%q candidate exact oracle mismatch: got %v want %v IDs %v", p, got, want, ids)
	}
}
func TestFiniteSubsetOracle(t *testing.T) {
	rng := rand.New(rand.NewSource(83))
	docs := []Document{}
	tokens := []string{"heron", "HERON", "timeout", "failure", "foo.bar", "a\nb", "unrelated"}
	for i := int64(1); i <= 120; i++ {
		docs = append(docs, Document{ID: i, Text: tokens[rng.Intn(len(tokens))] + " " + tokens[rng.Intn(len(tokens))]})
	}
	c := buildFixture(t, docs)
	for _, p := range []string{"heron", "heron|timeout", "(?i)heron|failure", "(?:heron|timeout)", "foo\\.bar", "a\\nb", "her(on|ald)", "fail[ua]re", "x|heron", "(?i)k", "a.*b", "^heron", "[A-Za-z]{30}", "(?s)a.b", "heron?"} {
		assertCandidateOracle(t, c, docs, p)
	}
	for i := 0; i < 100; i++ {
		a, b := tokens[rng.Intn(len(tokens))], tokens[rng.Intn(len(tokens))]
		assertCandidateOracle(t, c, docs, "(?i)"+regexp.QuoteMeta(a)+"|"+regexp.QuoteMeta(b))
	}
}
func TestCancellationAndClosed(t *testing.T) {
	c := buildFixture(t, []Document{{ID: 1, Text: "needle"}})
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if ids, err := c.Candidates(ctx, regexp.MustCompile("needle")); !errors.Is(err, context.Canceled) || ids != nil {
		t.Fatalf("canceled search %v %v", ids, err)
	}
	if ids, err := c.Candidates(ctx, regexp.MustCompile(".*")); !errors.Is(err, context.Canceled) || ids != nil {
		t.Fatalf("canceled fallback %v %v", ids, err)
	}
	c.Close()
	if _, err := c.Candidates(context.Background(), regexp.MustCompile("needle")); err == nil {
		t.Fatal("closed accepted")
	}
}

type incompleteSearcher struct {
	result *zoekt.SearchResult
	cancel context.CancelFunc
}

func (s incompleteSearcher) Search(_ context.Context, _ query.Q, _ *zoekt.SearchOptions) (*zoekt.SearchResult, error) {
	if s.cancel != nil {
		s.cancel()
	}
	return s.result, nil
}
func (s incompleteSearcher) List(context.Context, query.Q, *zoekt.ListOptions) (*zoekt.RepoList, error) {
	return nil, nil
}
func (s incompleteSearcher) Close()         {}
func (s incompleteSearcher) String() string { return "fake" }
func TestRejectPartialEngineResults(t *testing.T) {
	for _, stats := range []zoekt.Stats{{FilesSkipped: 1}, {ShardsSkipped: 1}, {Crashes: 1}, {FilesSkippedDueToCancellation: 1}, {FileCount: 1}} {
		c := &CandidateIndex{shards: []zoekt.Searcher{incompleteSearcher{result: &zoekt.SearchResult{Stats: stats}}}, coverage: map[int64]string{}}
		if ids, err := c.Candidates(context.Background(), regexp.MustCompile("needle")); !errors.Is(err, ErrIncompleteCandidates) || ids != nil {
			t.Fatalf("partial %v yielded %v %v", stats, ids, err)
		}
	}
	ctx, cancel := context.WithCancel(context.Background())
	c := &CandidateIndex{shards: []zoekt.Searcher{incompleteSearcher{result: &zoekt.SearchResult{}, cancel: cancel}}}
	if _, err := c.Candidates(ctx, regexp.MustCompile("needle")); !errors.Is(err, context.Canceled) {
		t.Fatalf("engine canceled without error: %v", err)
	}
}
func TestImmutableDirectoryAndDuplicateIDs(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "gen")
	c, err := BuildIndex(context.Background(), dir, []Document{{ID: 1, Text: "needle"}})
	if err != nil {
		t.Fatal(err)
	}
	c.Close()
	if _, err = BuildIndex(context.Background(), dir, nil); err == nil {
		t.Fatal("reused generation directory accepted")
	}
	if _, err = BuildIndex(context.Background(), filepath.Join(t.TempDir(), "dup"), []Document{{ID: 1, Text: "first"}, {ID: 1, Text: "second"}}); err == nil {
		t.Fatal("duplicate ID accepted")
	}
}

func TestConcurrentCandidates(t *testing.T) {
	docs := []Document{{ID: 1, Text: "heron"}, {ID: 2, Text: "timeout"}, {ID: 3, Text: "xy"}}
	c := buildFixture(t, docs)
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 10; j++ {
				ids, err := c.Candidates(context.Background(), regexp.MustCompile("heron|timeout"))
				if err != nil || !slices.Equal(ids, []int64{1, 2, 3}) {
					t.Errorf("concurrent candidate %v %v", ids, err)
				}
			}
		}()
	}
	wg.Wait()
}

func TestProductionPatternsUseFiniteCandidates(t *testing.T) {
	for _, p := range []string{"(?i)timeout|failure", "(?i)heron", "(?i)ancientneedle", "(?i)needle"} {
		literals, ok := finiteLiterals(p)
		t.Logf("pattern=%q finite=%v literals=%v", p, ok, literals)
		if !ok {
			t.Fatalf("production pattern fell back unexpectedly %q", p)
		}
	}
	for _, p := range []string{"x|heron", "(?i)Kelvin", "heron.*failure", "[a-z]{30}", "(?i)ſ"} {
		if _, ok := finiteLiterals(p); ok {
			t.Fatalf("unsafe/unbounded unexpectedly indexed %q", p)
		}
	}
}

func TestValidateGeneration(t *testing.T) {
	docs := []Document{{ID: 1, Text: "needle", UUID: "uuid1", Version: 1}, {ID: 2, Text: "xy", UUID: "uuid2", Version: 1}}
	c := buildFixture(t, docs)
	if err := c.ValidateGeneration(docs); err != nil {
		t.Fatal(err)
	}
	uuidSwap := append([]Document(nil), docs...)
	uuidSwap[0].UUID = "wrong"
	versionSwap := append([]Document(nil), docs...)
	versionSwap[0].Version++
	hitSwap := append([]Document(nil), docs...)
	hitSwap[0].Hit.MessageID = "wrong"
	for _, bad := range [][]Document{uuidSwap, versionSwap, hitSwap, docs[:1], {{ID: 1, Text: "changed"}, {ID: 2, Text: "xy"}}, {{ID: 1, Text: "needle"}, {ID: 1, Text: "needle"}}, {{ID: 3, Text: "needle"}, {ID: 2, Text: "xy"}}} {
		if err := c.ValidateGeneration(bad); err == nil {
			t.Fatal("invalid generation accepted")
		}
	}
}
