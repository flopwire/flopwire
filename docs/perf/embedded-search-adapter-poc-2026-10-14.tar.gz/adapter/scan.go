package adapter

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	"github.com/flopwire/flopwire/internal/client"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/flopwire/flopwire/internal/retrieval/grep"
)

type WorkBudget struct {
	Candidates int
	Bytes      int64
}
type ScanPage struct {
	Hits             []format.Hit
	CoverageComplete bool
	// Not inferred from an empty page. Suppression makes this conservative.
	NoMatchesProven bool
	Blocked         bool
	NextSequence    uint64
}
type savedPage struct {
	ids                          []int64
	complete, blocked, noMatches bool
	next                         uint64
}
type Scan struct {
	mu                        sync.Mutex
	docs                      map[int64]Document
	candidates                []int64
	q                         format.GrepQuery
	authority                 Authority
	binding                   string
	expires                   time.Time
	position                  int
	sequence                  uint64
	originalMatch, suppressed bool
	pages                     map[uint64]savedPage
}

// NewScan consumes an already published complete generation. Index generation
// publication and production tenant binding are caller responsibilities. The
// supplied opaque binding identifies principal/tenant/query/generation together.
// Only content newest-order POC semantics are implemented, without hit offsets,
// cross-page duplicate suppression or cross-page per-session limits.
func NewScan(ctx context.Context, index *CandidateIndex, docs []Document, q format.GrepQuery, authority Authority, binding string, ttl time.Duration) (*Scan, error) {
	if authority == nil || index == nil || binding == "" || ttl <= 0 {
		return nil, fmt.Errorf("invalid scan configuration")
	}
	if q.Offset != 0 || q.Sort != "" && q.Sort != format.SortNewest || q.Mode != "" && q.Mode != format.ModeContent || q.MaxPerSession != 0 {
		return nil, fmt.Errorf("POC supports newest content without offsets/session limits")
	}
	if err := authority.Check(ctx); err != nil {
		return nil, err
	}
	if err := index.ValidateGeneration(docs); err != nil {
		return nil, err
	}
	plan, err := grep.Compile(q)
	if err != nil {
		return nil, err
	}
	ids, err := index.Candidates(ctx, plan.Re)
	if err != nil {
		return nil, err
	}
	s := &Scan{docs: map[int64]Document{}, q: q, authority: authority, binding: binding, expires: time.Now().Add(ttl), pages: map[uint64]savedPage{}}
	uuids := map[string]bool{}
	for _, d := range docs {
		if d.UUID == "" || uuids[d.UUID] {
			return nil, fmt.Errorf("duplicate/empty authoritative UUID")
		}
		uuids[d.UUID] = true
		// Deep clone nested Hit metadata/timestamps, not just the document slice.
		raw, err := json.Marshal(d)
		if err != nil {
			return nil, err
		}
		var cloned Document
		if err = json.Unmarshal(raw, &cloned); err != nil {
			return nil, err
		}
		if _, ok := s.docs[d.ID]; ok {
			return nil, fmt.Errorf("duplicate generation ID")
		}
		s.docs[d.ID] = cloned
	}
	for _, id := range ids {
		d, ok := s.docs[id]
		if !ok {
			return nil, fmt.Errorf("candidate outside generation")
		}
		if !d.Hit.Superseded && !d.Hit.OffPath && d.Hit.Kind != "injected" {
			s.candidates = append(s.candidates, id)
		}
	}
	sort.Slice(s.candidates, func(i, j int) bool {
		a, b := s.docs[s.candidates[i]], s.docs[s.candidates[j]]
		if a.Hit.TS == nil && b.Hit.TS != nil {
			return false
		}
		if a.Hit.TS != nil && b.Hit.TS == nil {
			return true
		}
		if a.Hit.TS != nil && !a.Hit.TS.Equal(*b.Hit.TS) {
			return a.Hit.TS.After(*b.Hit.TS)
		}
		return a.UUID < b.UUID
	})
	return s, nil
}

// Next stages progress until all calls succeed. A mutex gives same-sequence
// callers one commit and reauthorized replay; no durable/process-crash claim.
// Work caps verification rows/body bytes, not engine startup or HTTP wire bytes.
func (s *Scan) Next(ctx context.Context, binding string, sequence uint64, work WorkBudget) (ScanPage, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := ctx.Err(); err != nil {
		return ScanPage{}, err
	}
	if err := s.authority.Check(ctx); err != nil {
		return ScanPage{}, err
	}
	if binding != s.binding {
		return ScanPage{}, fmt.Errorf("binding mismatch")
	}
	if !time.Now().Before(s.expires) {
		return ScanPage{}, fmt.Errorf("scan expired")
	}
	if page, ok := s.pages[sequence]; ok {
		out, _, err := s.render(ctx, page)
		return out, err
	}
	if s.sequence > 0 && s.pages[s.sequence-1].complete {
		return ScanPage{}, fmt.Errorf("terminal sequence must be replayed")
	}
	if sequence != s.sequence {
		return ScanPage{}, fmt.Errorf("invalid sequence")
	}
	if work.Candidates <= 0 || work.Bytes <= 0 {
		return ScanPage{}, fmt.Errorf("positive work budget required")
	}
	limit := s.q.Limit
	if limit <= 0 {
		limit = grep.DefaultLimit
	}
	count := min(work.Candidates, grep.MaxLimit, limit)
	plan, err := grep.Compile(s.q)
	if err != nil {
		return ScanPage{}, err
	}
	position := s.position
	matched := s.originalMatch
	suppressed := s.suppressed
	page := savedPage{next: sequence + 1}
	var bytes int64
	for len(page.ids) < count && position < len(s.candidates) {
		if err := ctx.Err(); err != nil {
			return ScanPage{}, err
		}
		id := s.candidates[position]
		d := s.docs[id]
		if int64(len(d.Text)) > work.Bytes-bytes {
			page.blocked = true
			break
		}
		bytes += int64(len(d.Text))
		page.ids = append(page.ids, id)
		position++
		if plan.Re.MatchString(d.Text) {
			matched = true
		}
	}
	page.complete = position == len(s.candidates)
	if page.complete {
		page.next = sequence
	}
	// Rendering authoritative bodies may fail or cancel; do not commit progress.
	out, pageSuppressed, err := s.render(ctx, page)
	if err != nil {
		return ScanPage{}, err
	}
	suppressed = suppressed || pageSuppressed
	page.noMatches = page.complete && !matched && !suppressed
	out.NoMatchesProven = page.noMatches
	if err := ctx.Err(); err != nil {
		return ScanPage{}, err
	}
	s.position = position
	s.originalMatch = matched
	s.suppressed = suppressed
	s.pages[sequence] = page
	s.sequence++
	return out, nil
}

func (s *Scan) render(ctx context.Context, page savedPage) (ScanPage, bool, error) {
	suppressed := false
	plan, err := grep.Compile(s.q)
	if err != nil {
		return ScanPage{}, false, err
	}
	q := s.q
	q.Limit = grep.MaxLimit
	q.Offset = 0
	col := grep.NewCollector(plan.Re, q)
	for _, id := range page.ids {
		if err := ctx.Err(); err != nil {
			return ScanPage{}, false, err
		}
		d := s.docs[id]
		if !plan.Re.MatchString(d.Text) {
			continue
		}
		current, err := s.authority.Current(ctx, d.UUID)
		if err != nil {
			var apiErr *client.APIError
			if errors.Is(err, format.ErrNotFound) || errors.As(err, &apiErr) && apiErr.StatusCode == 404 {
				suppressed = true
				continue
			}
			return ScanPage{}, false, err
		}
		if current.ID != d.UUID || current.Version != d.Version || current.Text != d.Text || current.Clipped || current.Superseded || current.OffPath {
			suppressed = true
			continue
		}
		row := grep.Row{Session: d.Hit.SessionID, Text: current.Text, SHA: sha256.Sum256([]byte(current.Text)), Ref: d.Hit}
		if !col.Add(row) {
			return ScanPage{}, false, fmt.Errorf("collector unexpectedly stopped before bounded page exhausted")
		}
	}
	out := ScanPage{Hits: []format.Hit{}, CoverageComplete: page.complete, NoMatchesProven: page.noMatches, Blocked: page.blocked, NextSequence: page.next}
	for _, found := range col.Result().Hits {
		h := found.Ref.(format.Hit)
		h.Lines = found.Lines
		h.MoreLines = found.MoreLines
		h.Copies = found.Copies
		out.Hits = append(out.Hits, h)
	}
	if suppressed {
		out.NoMatchesProven = false
	}
	return out, suppressed, nil
}
