package adapter

import (
 "context"
 "github.com/flopwire/flopwire/internal/retrieval/format"
)

// ID is generation-local; UUID is the authoritative message address.
type Document struct {
 ID int64
 UUID string
 Text string
 Version int
 Hit format.Hit
}

type Authority interface {
 Check(context.Context) error
 Current(context.Context, string) (format.Message, error)
}
