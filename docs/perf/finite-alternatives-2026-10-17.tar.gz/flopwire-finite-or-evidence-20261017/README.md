# Reproduce the paired finite-alternative experiment

Run from a flopwire checkout. Use Docker and Go 1.26.6. The seed helper writes
only to the dedicated local test cluster. It refuses to replace an existing
`finite_or_shared` database. Setup is outside every measured call.

Extract this archive into `/tmp`. Create two fresh worktrees:

```sh
git worktree add -b test/finite-or-evidence-baseline /tmp/flopwire-finite-baseline 17c10b17a0ec6f8fe5d7d4c1ba972c271f1d5ddc
git worktree add -b test/finite-or-evidence-candidate /tmp/flopwire-finite-candidate 3bf8ef221655627f91d5bf14617abf8aed18ab2b
finite_or_evidence=/tmp/flopwire-finite-or-evidence-20261017
for finite_or_tree in /tmp/flopwire-finite-baseline /tmp/flopwire-finite-candidate; do
  cp "$finite_or_evidence"/grep_finite_or_*test.go "$finite_or_tree/internal/retrieval/"
done
(cd /tmp/flopwire-finite-baseline && go test -c ./internal/retrieval -o /tmp/flopwire-finite-baseline.test)
(cd /tmp/flopwire-finite-candidate && go test -c ./internal/retrieval -o /tmp/flopwire-finite-candidate.test)
```

Create an isolated PostgreSQL 17 container on a random loopback port:

```sh
finite_or_container=flopwire-finite-or-reproduction
docker run -d --name "$finite_or_container" -e POSTGRES_PASSWORD=synthetic-perf-only -p 127.0.0.1::5432 postgres:17
finite_or_port="$(docker port "$finite_or_container" 5432/tcp | awk -F: '{print $NF}')"
export FLOPWIRE_TEST_DATABASE_URL="postgres://postgres:synthetic-perf-only@127.0.0.1:$finite_or_port/postgres?sslmode=disable"
```

Wait for PostgreSQL readiness. Run the archived seed helper once:

```sh
until docker exec "$finite_or_container" pg_isready -U postgres; do sleep 1; done
/tmp/flopwire-finite-candidate.test -test.run '^TestSeedFiniteORShared$' -test.v -test.timeout=5m
export FLOPWIRE_FINITE_OR_SHARED_URL="postgres://postgres:synthetic-perf-only@127.0.0.1:$finite_or_port/finite_or_shared?sslmode=disable"
```

The helper must report 30,000 messages and 96,970,200 text bytes. It runs the
same fixture SQL as the checked-in benchmark, then clones the temporary migrated
database into a persistent synthetic fixture. VACUUM ANALYZE initializes its
planner statistics. The original measurement fixture used pg_dump/restore plus
VACUUM ANALYZE; the helper reproduces the same logical rows and byte count.
Physical layout and caches can differ.

Run the first-page cases against that single database:

```sh
finite_or_run=0
for finite_or_variant in baseline candidate candidate baseline baseline candidate; do
  finite_or_run=$((finite_or_run+1))
  /tmp/flopwire-finite-${finite_or_variant}.test -test.run '^TestFiniteORSharedExperiment$' -test.v -test.timeout=5m > /tmp/finite-or-${finite_or_run}-${finite_or_variant}.log
done
```

The driver uses a 60-second per-call budget. Ordinary calls use limit 35 and
max_per_session 7. Continuation clamps the supplied limit to 20 and omits
max_per_session. Compare elapsed_ms, hit counts, totals and ordered-ID signatures.
Ignore randomly generated continuation cursors. Keep all failures in the record.

For the controls, set `FLOPWIRE_FINITE_OR_CONTROLS=1`. Repeat with order
baseline/candidate/candidate/baseline. Run full-result semantic checks separately:

```sh
(cd /tmp/flopwire-finite-candidate && go test -race ./internal/retrieval -run 'TestLiteralRegexp|TestFoldedLiteral' -count=1 -v)
```

Stop and remove the disposable container after the experiment:

```sh
docker stop "$finite_or_container"
docker rm "$finite_or_container"
```

The archive contains the original paired driver, fixture benchmark, sanitized
measurements, default-budget baseline failures and this recipe. The seed helper
was added afterward to make the paired setup reproducible. The helper does not
change the production implementation or recorded measurements.
