package retrieval

import (
	"context"
	"crypto/sha256"
	"fmt"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/jackc/pgx/v5/pgxpool"
	"os"
	"strings"
	"testing"
	"time"
)

// Temporary local A/B driver: only reads an already seeded isolated corpus.
func TestFiniteORSharedExperiment(t *testing.T) {
	url := os.Getenv("FLOPWIRE_FINITE_OR_SHARED_URL")
	if url == "" {
		t.Skip("local shared corpus not requested")
	}
	pool, err := pgxpool.New(context.Background(), url)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	s := &Store{Pool: pool}
	var owner string
	if err := pool.QueryRow(context.Background(), `SELECT user_id::text FROM conversations LIMIT 1`).Scan(&owner); err != nil {
		t.Fatal(err)
	}
	patterns := []string{`spotlight|mdutil|mds_stores`}
	if os.Getenv("FLOPWIRE_FINITE_OR_CONTROLS") != "" {
		patterns = []string{`mdutil`, `missingneedle`, `spotlight|absentneedle`}
	}
	for _, pattern := range patterns {
		for _, days := range []int{7, 2} {
			for _, continuation := range []bool{false, true} {
				t.Run(fmt.Sprintf("%s/%dd/continue=%v", pattern, days, continuation), func(t *testing.T) {
					q := format.GrepQuery{Pattern: pattern, Limit: 35, MaxPerSession: 7}
					if continuation {
						q.Continue, q.Authority, q.MaxPerSession = true, "local-experiment", 0
						s.GrepContinuations = NewGrepContinuations(pool)
						defer s.GrepContinuations.Close()
					}
					f := format.Filters{Owner: owner, Since: time.Date(2026, 10, 17-days, 0, 0, 0, 0, time.UTC)}
					ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
					defer cancel()
					start := time.Now()
					p, err := s.Grep(ctx, q, f)
					elapsed := time.Since(start)
					if err != nil {
						t.Fatal(err)
					}
					var ids strings.Builder
					for _, h := range p.Hits {
						ids.WriteString(h.MessageID)
						ids.WriteByte('\n')
					}
					t.Logf("elapsed_ms=%.3f hits=%d total=%d truncated=%v signature=%x scan=%+v", float64(elapsed.Microseconds())/1000, len(p.Hits), p.Total, p.Truncated, sha256.Sum256([]byte(ids.String())), p.Scan)
					if p.Truncated || (p.Scan != nil && p.Scan.Status != "more" && p.Scan.Status != "complete") {
						t.Fatalf("incomplete: %s", p.Reason)
					}
				})
			}
		}
	}
}
