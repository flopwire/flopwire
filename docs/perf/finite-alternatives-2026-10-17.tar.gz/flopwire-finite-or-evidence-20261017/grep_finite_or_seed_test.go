package retrieval

import (
	"context"
	"os"
	"testing"

	"github.com/flopwire/flopwire/internal/pgtest"
	"github.com/jackc/pgx/v5"
)

// TestSeedFiniteORShared creates one persistent synthetic database in the
// dedicated loopback test cluster. It refuses to replace an existing database.
func TestSeedFiniteORShared(t *testing.T) {
	ctx := context.Background()
	config, err := pgx.ParseConfig(os.Getenv(pgtest.EnvURL))
	if err != nil {
		t.Fatal(err)
	}
	if config.Host != "127.0.0.1" && config.Host != "localhost" {
		t.Fatal("use a dedicated loopback test PostgreSQL cluster")
	}
	s, _ := perfCorpus(t, 30, 1000)
	for _, sql := range []string{
		`UPDATE messages m SET text=(SELECT string_agg(md5(m.id::text||j),' ') FROM generate_series(1,96) j)
 ||' spo pot otl tli lig igh ght mdu dut uti til mds sto tor ore res '
 ||CASE WHEN ordinal%100=0 THEN ' spotlight ' WHEN ordinal%100=1 THEN ' mdutil ' WHEN ordinal%100=2 THEN ' mdſ_ſtoreſ ' ELSE '' END,
 ts=CASE WHEN conversation_id IN (SELECT md5('c'||i)::uuid FROM generate_series(1,20) i) THEN '2026-10-12'::timestamptz ELSE '2026-10-16'::timestamptz END+ordinal*interval '1 millisecond'`,
		`UPDATE conversation_activity a SET last_activity_at=x.newest FROM (SELECT conversation_id,max(ts) newest FROM messages GROUP BY 1) x WHERE x.conversation_id=a.conversation_id`,
		`VACUUM ANALYZE`,
	} {
		if _, err := s.Pool.Exec(ctx, sql); err != nil {
			t.Fatal(err)
		}
	}
	source := s.Pool.Config().ConnConfig.Database
	s.Pool.Close()
	admin, err := pgx.ConnectConfig(ctx, config)
	if err != nil {
		t.Fatal(err)
	}
	defer admin.Close(ctx)
	if _, err := admin.Exec(ctx, `CREATE DATABASE finite_or_shared TEMPLATE `+pgx.Identifier{source}.Sanitize()); err != nil {
		t.Fatal(err)
	}
	sharedConfig := config.Copy()
	sharedConfig.Database = "finite_or_shared"
	shared, err := pgx.ConnectConfig(ctx, sharedConfig)
	if err != nil {
		t.Fatal(err)
	}
	defer shared.Close(ctx)
	if _, err := shared.Exec(ctx, `VACUUM ANALYZE`); err != nil {
		t.Fatal(err)
	}
	var count, bytes int64
	if err := shared.QueryRow(ctx, `SELECT count(*),sum(octet_length(text)) FROM messages`).Scan(&count, &bytes); err != nil {
		t.Fatal(err)
	}
	if count != 30000 || bytes != 96970200 {
		t.Fatalf("seed count=%d bytes=%d", count, bytes)
	}
	t.Logf("finite_or_shared ready: count=%d bytes=%d", count, bytes)
}
