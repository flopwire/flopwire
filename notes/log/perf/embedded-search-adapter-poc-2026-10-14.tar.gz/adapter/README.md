# Embedded adapter experiment

This is a separate research module. Production imports and dependencies are unchanged.

## Reproduce

Use repository commit `883a467f427be88f05a58c2751a08f1cb30e6d86` or this report's branch. Use Go 1.26.6 and Docker.

1. Create `.poc-stress-test` at the repository root.
2. Extract the archive there. It contains the `adapter` directory.
3. Run `sh .poc-stress-test/adapter/db-start.sh` from the repository root.
4. Change directory to `.poc-stress-test/adapter`.
5. Run the commands below.

```sh
export FLOPWIRE_TEST_DATABASE_URL='postgres://postgres:synthetic-adapter-poc@127.0.0.1:55449/postgres?sslmode=disable'
go test -race -count=1 -v ./...
go test -count=1 -v -run '^TestPostgresAdapterTimingSmoke$' ./...
```

Run `sh db-stop.sh` after testing. Return to the repository root. Remove `.poc-stress-test` after saving any needed evidence.

The password is a synthetic credential for the loopback-only disposable database. Tests create isolated databases, run production migrations, and drop them afterward. No production connection is required.

## Boundaries

`SnapshotPG` is privileged server-side code. Authenticate the caller before invoking it. The current server authorizes the shared visible corpus; this experiment does not establish multi-tenant isolation or future per-row permission policy. Unsupported filters fail explicitly.

`BuildIndex` fixes the source generation. `ValidateGeneration` rejects any different body or metadata before search. `NewScan` uses production regexp compilation and `Next` uses the production collector. Each request, including empty and replayed pages, checks current credentials. Returned bodies pass the real authenticated read handler and must equal the original version and text. Later additions stay outside the snapshot.

Work budgets cover candidate verification count and source bytes. They do not cover index candidate enumeration, generation hashing/cloning, network transfer, or allocation. A blocked oversized message is not skipped. Replays save IDs and re-read current bodies; the snapshot itself still retains original plaintext until released.

Pagination uses in-process state, a mutex, and a caller-supplied binding. This is not a durable cursor implementation. The caller must derive binding from authenticated identity, query, and generation; no production endpoint exposes it. Each distinct message address appears once in forward traversal, including identical text at separate addresses. Replaying a page repeats its still-authorized addresses. CoverageComplete means candidate traversal ended; an empty final page does not prove absence.

The 30-concurrent test records expected HTTP 429 responses as overload outcomes. A passing test means those outcomes were accounted for, not that all requests succeeded. Latency samples exclude rejected requests and are explicitly labeled. The initial exploratory failure is retained in postgres-test.log.
