package adapter

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"math"
	"net/http/httptest"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/flopwire/flopwire/internal/api"
	"github.com/flopwire/flopwire/internal/auth"
	"github.com/flopwire/flopwire/internal/client"
	"github.com/flopwire/flopwire/internal/domain"
	"github.com/flopwire/flopwire/internal/pgtest"
	"github.com/flopwire/flopwire/internal/retrieval"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/flopwire/flopwire/internal/retrieval/grep"
	"github.com/flopwire/flopwire/internal/store"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

type pgFixture struct {
	pool                            *pgxpool.Pool
	authority                       HTTPAuthority
	owner, device, conv, credential string
	login                           client.HTTP
}

func newPGFixture(t *testing.T) *pgFixture {
	t.Helper()
	ctx := t.Context()
	pool, err := pgxpool.New(ctx, pgtest.NewDatabase(t))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)
	if err = store.Migrate(ctx, pool); err != nil {
		t.Fatal(err)
	}
	pg := store.NewPostgres(pool, nil, "")
	server := httptest.NewServer(api.New(pg, api.Config{Logger: slog.New(slog.NewTextHandler(io.Discard, nil)), Retrieval: &retrieval.Store{Pool: pool}}).Handler(nil))
	t.Cleanup(server.Close)
	now := time.Now().UTC()
	plain, hash, err := auth.NewToken()
	if err != nil {
		t.Fatal(err)
	}
	owner := uuid.NewString()
	cred := uuid.NewString()
	err = pg.BootstrapIdentity(ctx, domain.User{ID: owner, Email: "adapter@example.test", Name: "Synthetic", Role: domain.RoleAdmin, IdentityType: domain.IdentityHuman, CreatedAt: now}, domain.Credential{ID: cred, UserID: owner, Kind: domain.CredentialSession, TokenHash: hash, ExpiresAt: now.Add(time.Hour), CreatedAt: now, Active: true}, domain.AuditEvent{ID: uuid.NewString(), ActorID: owner, Action: "bootstrap", CreatedAt: now})
	if err != nil {
		t.Fatal(err)
	}
	login := client.HTTP{Server: server.URL, Token: plain}
	var enrolled map[string]any
	if err = login.JSON(ctx, "POST", "/v1/devices", map[string]string{"name": "adapter", "platform": "darwin"}, &enrolled); err != nil {
		t.Fatal(err)
	}
	device := enrolled["device"].(map[string]any)["id"].(string)
	deviceHTTP := client.HTTP{Server: server.URL, Token: enrolled["token"].(string)}
	var deviceCred string
	if err = pool.QueryRow(ctx, "SELECT id::text FROM credentials WHERE device_id=$1 AND kind='device'", device).Scan(&deviceCred); err != nil {
		t.Fatal(err)
	}
	conv := uuid.NewString()
	if _, err = pool.Exec(ctx, "INSERT INTO conversations(id,agent,session_id,device_id,user_id,repo_root) VALUES($1,'codex',$2,$3,$4,'/synthetic/adapter')", conv, "adapter-session-"+conv, device, owner); err != nil {
		t.Fatal(err)
	}
	return &pgFixture{pool: pool, authority: HTTPAuthority{HTTP: deviceHTTP}, owner: owner, device: device, conv: conv, credential: deviceCred, login: login}
}
func (f *pgFixture) add(t *testing.T, ordinal int64, body string, at *time.Time) string {
	t.Helper()
	id := uuid.NewString()
	sum := sha256.Sum256([]byte(body))
	_, err := f.pool.Exec(t.Context(), "INSERT INTO messages(id,conversation_id,ordinal,kind,ts,text,text_len,content_sha,source_generation,parser) VALUES($1,$2,$3,'assistant',$4,$5,$6,$7,0,'poc')", id, f.conv, ordinal, at, body, len(body), sum[:])
	if err != nil {
		t.Fatal(err)
	}
	return id
}
func (f *pgFixture) exec(t *testing.T, sql string, args ...any) {
	t.Helper()
	if _, err := f.pool.Exec(t.Context(), sql, args...); err != nil {
		t.Fatal(err)
	}
}

func TestProductionAuthority(t *testing.T) {
	t.Run("live read and actual redaction", func(t *testing.T) {
		f := newPGFixture(t)
		id := f.add(t, 1, "private synthetic needle", nil)
		if err := f.authority.Check(t.Context()); err != nil {
			t.Fatal(err)
		}
		m, err := f.authority.Current(t.Context(), id)
		if err != nil || m.Text != "private synthetic needle" {
			t.Fatalf("read %+v %v", m, err)
		}
		var redacted format.RedactResult
		if err = f.authority.HTTP.JSON(t.Context(), "POST", "/v1/redactions", format.RedactRequest{Address: id}, &redacted); err != nil {
			t.Fatal(err)
		}
		m, err = f.authority.Current(t.Context(), id)
		if err != nil || m.Text == "private synthetic needle" || redacted.Messages != 1 {
			t.Fatalf("redaction %+v %+v %v", redacted, m, err)
		}
	})
	t.Run("credential revoked", func(t *testing.T) {
		f := newPGFixture(t)
		id := f.add(t, 1, "needle", nil)
		f.exec(t, "UPDATE credentials SET revoked_at=now(),revoke_reason='revoked' WHERE id=$1", f.credential)
		if f.authority.Check(t.Context()) == nil {
			t.Fatal("revoked check allowed")
		}
		if _, err := f.authority.Current(t.Context(), id); err == nil {
			t.Fatal("revoked read allowed")
		}
	})
	t.Run("upload only", func(t *testing.T) {
		f := newPGFixture(t)
		var minted map[string]any
		if err := f.authority.HTTP.JSON(t.Context(), "POST", "/v1/tokens", map[string]any{"ttl_seconds": 3600, "scopes": []string{"upload"}, "label": "synthetic-upload"}, &minted); err != nil {
			t.Fatal(err)
		}
		up := HTTPAuthority{HTTP: client.HTTP{Server: f.authority.HTTP.Server, Token: minted["token"].(string)}}
		if up.Check(t.Context()) == nil {
			t.Fatal("upload-only check allowed")
		}
	})
	t.Run("hide and delete", func(t *testing.T) {
		f := newPGFixture(t)
		id := f.add(t, 1, "needle", nil)
		f.exec(t, "UPDATE conversations SET hidden_at=now() WHERE id=$1", f.conv)
		if _, err := f.authority.Current(t.Context(), id); err == nil {
			t.Fatal("hidden read allowed")
		}
		f.exec(t, "DELETE FROM conversations WHERE id=$1", f.conv)
		if _, err := f.authority.Current(t.Context(), id); err == nil {
			t.Fatal("deleted read allowed")
		}
	})
	t.Run("focus flags reach adapter", func(t *testing.T) {
		f := newPGFixture(t)
		id := f.add(t, 1, "needle", nil)
		f.exec(t, "UPDATE messages SET superseded=true,on_active_path=false WHERE id=$1", id)
		m, err := f.authority.Current(context.Background(), id)
		if err != nil || !m.Superseded || !m.OffPath {
			t.Fatalf("focus flags %+v %v", m, err)
		}
	})
}

func TestPostgresSnapshotGeneration(t *testing.T) {
	f := newPGFixture(t)
	if err := f.authority.Check(t.Context()); err != nil {
		t.Fatal(err)
	}
	now := time.Now().UTC()
	a := f.add(t, 1, "needle one", &now)
	b := f.add(t, 2, "needle tied", &now)
	c := f.add(t, 3, "needle null", nil)
	injected := f.add(t, 4, "needle injected", nil)
	f.exec(t, "UPDATE messages SET kind='injected' WHERE id=$1", injected)
	off := f.add(t, 5, "needle offpath", nil)
	f.exec(t, "UPDATE messages SET on_active_path=false WHERE id=$1", off)
	dead := f.add(t, 6, "needle superseded", nil)
	f.exec(t, "UPDATE messages SET superseded=true WHERE id=$1", dead)
	docs, err := SnapshotPG(t.Context(), f.pool, format.Filters{})
	if err != nil {
		t.Fatal(err)
	}
	if len(docs) != 3 {
		t.Fatalf("eligible %d", len(docs))
	}
	want := map[string]bool{a: true, b: true, c: true}
	for i, d := range docs {
		if !want[d.UUID] || d.ID != int64(i+1) {
			t.Fatalf("doc %+v", d)
		}
		delete(want, d.UUID)
	}
	later := f.add(t, 7, "needle later ingest", &now)
	for _, d := range docs {
		if d.UUID == later {
			t.Fatal("later ingest changed frozen generation")
		}
	}
	if _, err = SnapshotPG(t.Context(), f.pool, format.Filters{Repo: "/synthetic/adapter"}); err == nil {
		t.Fatal("unsupported filter silently approximated")
	}
	if _, err = SnapshotPG(t.Context(), f.pool, format.Filters{Kinds: []string{"injected"}}); err == nil {
		t.Fatal("injected filter silently dropped by scanner")
	}
	since, err := SnapshotPG(t.Context(), f.pool, format.Filters{Since: now})
	if err != nil || len(since) != 3 {
		t.Fatalf("time filtered count %d %v", len(since), err)
	}
	var active int
	if err = f.pool.QueryRow(t.Context(), "SELECT count(*) FROM pg_stat_activity WHERE datname=current_database() AND state='idle in transaction'").Scan(&active); err != nil || active != 0 {
		t.Fatalf("retained tx=%d %v", active, err)
	}
}

func (f *pgFixture) scan(t *testing.T, pattern string) (*Scan, []Document) {
	t.Helper()
	if err := f.authority.Check(t.Context()); err != nil {
		t.Fatal(err)
	}
	docs, err := SnapshotPG(t.Context(), f.pool, format.Filters{})
	if err != nil {
		t.Fatal(err)
	}
	idx, err := BuildIndex(t.Context(), filepath.Join(t.TempDir(), "index"), docs)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { idx.Close() })
	s, err := NewScan(t.Context(), idx, docs, format.GrepQuery{Pattern: pattern, Limit: 50}, f.authority, "synthetic-binding", time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	return s, docs
}

func TestPostgresScanMutations(t *testing.T) {
	for _, mutation := range []string{"hide", "delete", "supersede", "offpath", "redact", "hash-mismatch", "revoke", "upload-only"} {
		t.Run(mutation, func(t *testing.T) {
			f := newPGFixture(t)
			id := f.add(t, 1, "needle private synthetic", nil)
			s, _ := f.scan(t, "needle")
			p, err := s.Next(t.Context(), "synthetic-binding", 0, WorkBudget{Candidates: 1, Bytes: 1 << 20})
			if err != nil || len(p.Hits) != 1 {
				t.Fatalf("first %+v %v", p, err)
			}
			switch mutation {
			case "hide":
				f.exec(t, "UPDATE conversations SET hidden_at=now() WHERE id=$1", f.conv)
			case "delete":
				f.exec(t, "DELETE FROM conversations WHERE id=$1", f.conv)
			case "supersede":
				f.exec(t, "UPDATE messages SET superseded=true WHERE id=$1", id)
			case "offpath":
				f.exec(t, "UPDATE messages SET on_active_path=false WHERE id=$1", id)
			case "hash-mismatch":
				f.exec(t, "UPDATE messages SET text='needle changed synthetic',text_len=24 WHERE id=$1", id)
			case "redact":
				var out format.RedactResult
				if err = f.authority.HTTP.JSON(t.Context(), "POST", "/v1/redactions", format.RedactRequest{Address: id}, &out); err != nil {
					t.Fatal(err)
				}
			case "revoke":
				f.exec(t, "UPDATE credentials SET revoked_at=now(),revoke_reason='revoked' WHERE id=$1", f.credential)
			case "upload-only":
				f.exec(t, "UPDATE credentials SET scopes=ARRAY['upload'] WHERE id=$1", f.credential)
			}
			replay, err := s.Next(t.Context(), "synthetic-binding", 0, WorkBudget{Candidates: 1, Bytes: 1 << 20})
			if mutation == "revoke" || mutation == "upload-only" {
				if err == nil {
					t.Fatal("credential change failed to deny replay")
				}
			} else if err != nil || len(replay.Hits) != 0 || replay.NoMatchesProven {
				t.Fatalf("stale replay %+v %v", replay, err)
			}
		})
	}
	t.Run("empty generation still authorizes", func(t *testing.T) {
		f := newPGFixture(t)
		s, _ := f.scan(t, "needle")
		f.exec(t, "UPDATE credentials SET revoked_at=now(),revoke_reason='revoked' WHERE id=$1", f.credential)
		if _, err := s.Next(t.Context(), "synthetic-binding", 0, WorkBudget{Candidates: 1, Bytes: 1 << 20}); err == nil {
			t.Fatal("revoked empty scan allowed")
		}
	})
	t.Run("later ingest excluded null and tie order stable", func(t *testing.T) {
		f := newPGFixture(t)
		now := time.Now().UTC()
		ids := []string{f.add(t, 1, "needle first", &now), f.add(t, 2, "needle tied", &now)}
		null := f.add(t, 3, "needle null", nil)
		sort.Strings(ids)
		want := append(ids, null)
		s, _ := f.scan(t, "needle")
		f.add(t, 4, "needle later", &now)
		got := []string{}
		sequence := uint64(0)
		for {
			p, err := s.Next(t.Context(), "synthetic-binding", sequence, WorkBudget{Candidates: 1, Bytes: 1 << 20})
			if err != nil {
				t.Fatal(err)
			}
			for _, h := range p.Hits {
				got = append(got, h.MessageID)
			}
			if p.CoverageComplete {
				break
			}
			sequence = p.NextSequence
		}
		if strings.Join(got, ",") != strings.Join(want, ",") {
			t.Fatalf("got %v want %v", got, want)
		}
	})
}

func TestPostgresDistinctAddressesIdenticalText(t *testing.T) {
	f := newPGFixture(t)
	const body = "needle identical synthetic body"
	a := f.add(t, 1, body, nil)
	b := f.add(t, 2, body, nil)
	s, _ := f.scan(t, "needle")
	work := WorkBudget{Candidates: 10, Bytes: 1 << 20}
	first, err := s.Next(t.Context(), "synthetic-binding", 0, work)
	if err != nil || len(first.Hits) != 2 || !first.CoverageComplete || first.NoMatchesProven {
		t.Fatalf("distinct first page %+v %v", first, err)
	}
	seen := map[string]string{}
	for _, h := range first.Hits {
		seen[h.MessageID] = h.Address
		if h.Copies != 0 {
			t.Fatalf("distinct address folded copies %+v", h)
		}
		matched := false
		for _, line := range h.Lines {
			if line.Match && line.Text == body {
				matched = true
			}
		}
		if !matched {
			t.Fatalf("missing authoritative match %+v", h)
		}
	}
	if len(seen) != 2 || seen[a] == "" || seen[b] == "" || seen[a] == seen[b] {
		t.Fatalf("lost distinct addresses %v", seen)
	}
	var redacted format.RedactResult
	if err = f.authority.HTTP.JSON(t.Context(), "POST", "/v1/redactions", format.RedactRequest{Address: a}, &redacted); err != nil {
		t.Fatal(err)
	}
	if redacted.Messages != 1 {
		t.Fatalf("redacted wrong count %+v", redacted)
	}
	current, err := f.authority.Current(t.Context(), a)
	if err != nil || current.Text == body {
		t.Fatalf("redaction did not change authority %+v %v", current, err)
	}
	other, err := f.authority.Current(t.Context(), b)
	if err != nil || other.Text != body {
		t.Fatalf("other identical address changed %+v %v", other, err)
	}
	replay, err := s.Next(t.Context(), "synthetic-binding", 0, work)
	if err != nil || len(replay.Hits) != 1 || replay.Hits[0].MessageID != b || !replay.CoverageComplete || replay.NoMatchesProven {
		t.Fatalf("unsafe replay %+v %v", replay, err)
	}
	for _, line := range replay.Hits[0].Lines {
		if line.Match && line.Text != body {
			t.Fatalf("stale or wrong replay text %+v", line)
		}
	}
	t.Log("two distinct UUID/address hits retained despite identical text; actual POST redaction removes only its address on replay; surviving address remains authoritative; no false absence")
}

type countingAuthority struct {
	Authority
	reads  atomic.Int64
	checks atomic.Int64
}

func (a *countingAuthority) Check(ctx context.Context) error {
	a.checks.Add(1)
	return a.Authority.Check(ctx)
}
func (a *countingAuthority) Current(ctx context.Context, id string) (format.Message, error) {
	a.reads.Add(1)
	return a.Authority.Current(ctx, id)
}

func TestPostgresAdapterTimingSmoke(t *testing.T) {
	f := newPGFixture(t)
	start := time.Now()
	now := time.Now().UTC()
	const n = 1000
	for i := 0; i < n; i++ {
		body := strings.Repeat("abcdefghij ", 180) + fmt.Sprintf(" unique-%d", i)
		if i%5 == 0 {
			body += " broadneedle"
		}
		if i == 0 {
			body += " rareneedle"
		}
		f.add(t, int64(i+1), body, &now)
	}
	seedMS := float64(time.Since(start).Microseconds()) / 1000
	if err := f.authority.Check(t.Context()); err != nil {
		t.Fatal(err)
	}
	start = time.Now()
	docs, err := SnapshotPG(t.Context(), f.pool, format.Filters{})
	if err != nil {
		t.Fatal(err)
	}
	snapshotMS := float64(time.Since(start).Microseconds()) / 1000
	start = time.Now()
	idx, err := BuildIndex(t.Context(), filepath.Join(t.TempDir(), "index"), docs)
	if err != nil {
		t.Fatal(err)
	}
	defer idx.Close()
	indexMS := float64(time.Since(start).Microseconds()) / 1000
	t.Logf("setup seed_ms=%.3f snapshot_ms=%.3f index_ms=%.3f docs=%d", seedMS, snapshotMS, indexMS, len(docs))
	run := func(pattern string, want int, emit bool) (float64, float64, error) {
		plan, err := grep.Compile(format.GrepQuery{Pattern: pattern})
		if err != nil {
			return 0, 0, err
		}
		oracle := []string{}
		for _, d := range docs {
			if plan.Re.MatchString(d.Text) {
				oracle = append(oracle, d.UUID)
			}
		}
		sort.Strings(oracle)
		start := time.Now()
		auth := &countingAuthority{Authority: f.authority}
		s, err := NewScan(t.Context(), idx, docs, format.GrepQuery{Pattern: pattern, Limit: 50}, auth, "timing-binding", 5*time.Minute)
		if err != nil {
			return 0, 0, err
		}
		seq := uint64(0)
		startup := float64(time.Since(start).Microseconds()) / 1000
		hits := 0
		got := []string{}
		first := float64(0)
		for {
			p, err := s.Next(t.Context(), "timing-binding", seq, WorkBudget{Candidates: 50, Bytes: 1 << 20})
			if err != nil {
				return 0, 0, err
			}
			if seq == 0 {
				first = float64(time.Since(start).Microseconds()) / 1000
			}
			hits += len(p.Hits)
			for _, h := range p.Hits {
				got = append(got, h.MessageID)
			}
			if p.CoverageComplete {
				break
			}
			seq = p.NextSequence
		}
		if hits != want {
			return 0, 0, fmt.Errorf("pattern %s hits %d want %d", pattern, hits, want)
		}
		sort.Strings(got)
		if strings.Join(got, ",") != strings.Join(oracle, ",") {
			return 0, 0, fmt.Errorf("UUID oracle mismatch for %s", pattern)
		}
		if emit {
			raw, _ := json.Marshal(map[string]any{"pattern": pattern, "startup_ms": startup, "first_next_ms": first - startup, "first_page_ms": first, "total_ms": float64(time.Since(start).Microseconds()) / 1000, "read_calls": auth.reads.Load(), "check_calls": auth.checks.Load(), "hits": hits, "oracle_uuid_equal": true})
			t.Log(string(raw))
		}
		return first, float64(time.Since(start).Microseconds()) / 1000, nil
	}
	for _, tc := range []struct {
		pattern string
		want    int
	}{{"rareneedle", 1}, {"broadneedle", 200}, {"broadneedle|rareneedle", 200}, {"a.*b", 1000}, {"[A-Za-z]{30}", 0}} {
		_, _, err := run(tc.pattern, tc.want, true)
		if err != nil {
			t.Fatal(err)
		}
	}
	var wg sync.WaitGroup
	var mu sync.Mutex
	samples := []float64{}
	errs := []error{}
	for i := 0; i < 30; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_, total, err := run("rareneedle", 1, false)
			mu.Lock()
			defer mu.Unlock()
			if err != nil {
				errs = append(errs, err)
			} else {
				samples = append(samples, total)
			}
		}()
	}
	wg.Wait()
	for _, err := range errs {
		var apiErr *client.APIError
		if !errors.As(err, &apiErr) || apiErr.StatusCode != 429 {
			t.Fatalf("unexpected concurrent error %v", err)
		}
	}
	sort.Float64s(samples)
	if len(samples) == 0 {
		t.Fatal("all30concurrent scans rejected")
	}
	t.Logf("30 concurrent rare scans smoke attempts=30 successful=%d rejected_429=%d successful_only_p50_ms=%.3f successful_only_p95_ms=%.3f; not capacity qualification", len(samples), len(errs), samples[int(math.Ceil(float64(len(samples))*.5))-1], samples[int(math.Ceil(float64(len(samples))*.95))-1])
}
