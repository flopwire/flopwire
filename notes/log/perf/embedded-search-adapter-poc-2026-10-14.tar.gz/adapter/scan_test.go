package adapter

import (
	"context"
	"errors"
	"fmt"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"path/filepath"
	"reflect"
	"strings"
	"sync"
	"testing"
	"time"
)

type scanAuthority struct {
	currentCalls int
	mu           sync.Mutex
	denied       bool
	rows         map[string]format.Message
	failure      error
	cancel       context.CancelFunc
}

func (a *scanAuthority) Check(ctx context.Context) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.denied {
		return errors.New("revoked")
	}
	return ctx.Err()
}
func (a *scanAuthority) Current(ctx context.Context, id string) (format.Message, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.currentCalls++
	if a.cancel != nil {
		a.cancel()
		a.cancel = nil
		return format.Message{}, context.Canceled
	}
	if a.failure != nil {
		return format.Message{}, a.failure
	}
	m, ok := a.rows[id]
	if !ok {
		return m, format.ErrNotFound
	}
	return m, nil
}
func scanDoc(id int64, uuid, text string, ts *time.Time) Document {
	return Document{ID: id, UUID: uuid, Text: text, Version: 1, Hit: format.Hit{MessageID: uuid, SessionID: "session", TS: ts, Kind: "assistant"}}
}
func scanFixture(t *testing.T, docs []Document, pattern string) (*Scan, *scanAuthority) {
	t.Helper()
	idx, err := BuildIndex(context.Background(), filepath.Join(t.TempDir(), "index"), docs)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { idx.Close() })
	a := &scanAuthority{rows: map[string]format.Message{}}
	for _, d := range docs {
		a.rows[d.UUID] = format.Message{ID: d.UUID, Text: d.Text, Version: d.Version}
	}
	s, err := NewScan(context.Background(), idx, docs, format.GrepQuery{Pattern: pattern}, a, "binding", time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	return s, a
}
func scanIDs(p ScanPage) []string {
	out := []string{}
	for _, h := range p.Hits {
		out = append(out, h.MessageID)
	}
	return out
}
func TestScanOrderingClone(t *testing.T) {
	now := time.Now()
	docs := []Document{scanDoc(1, "b", "needle-b", &now), scanDoc(2, "a", "needle-a", &now), scanDoc(3, "z", "needle-z", nil)}
	s, a := scanFixture(t, docs, "needle")
	docs[1].Text = "changed"
	*docs[0].Hit.TS = now.Add(time.Hour)
	a.rows["late"] = format.Message{ID: "late", Text: "needle-late", Version: 1}
	all := []string{}
	for seq := uint64(0); seq < 3; seq++ {
		p, e := s.Next(context.Background(), "binding", seq, WorkBudget{1, 100})
		if e != nil {
			t.Fatal(e)
		}
		all = append(all, scanIDs(p)...)
		if p.CoverageComplete != (seq == 2) {
			t.Fatal(p)
		}
	}
	if !reflect.DeepEqual(all, []string{"a", "b", "z"}) {
		t.Fatal(all)
	}
}
func TestScanSuppressReplayAndErrors(t *testing.T) {
	for _, kind := range []string{"text", "version", "superseded", "offpath", "404", "error"} {
		t.Run(kind, func(t *testing.T) {
			s, a := scanFixture(t, []Document{scanDoc(1, "a", "needle", nil)}, "needle")
			p, e := s.Next(context.Background(), "binding", 0, WorkBudget{10, 100})
			if e != nil || len(p.Hits) != 1 {
				t.Fatal(p, e)
			}
			m := a.rows["a"]
			switch kind {
			case "text":
				m.Text = "needle-redacted"
			case "version":
				m.Version++
			case "superseded":
				m.Superseded = true
			case "offpath":
				m.OffPath = true
			case "404":
				delete(a.rows, "a")
			case "error":
				a.failure = errors.New("server error")
			}
			if kind != "404" {
				a.rows["a"] = m
			}
			p, e = s.Next(context.Background(), "binding", 0, WorkBudget{10, 100})
			if kind == "error" {
				if e == nil {
					t.Fatal("error hidden")
				}
				return
			}
			if e != nil || len(p.Hits) != 0 || p.NoMatchesProven {
				t.Fatal(p, e)
			}
			a.denied = true
			if _, e = s.Next(context.Background(), "binding", 0, WorkBudget{10, 100}); e == nil {
				t.Fatal("replay auth")
			}
		})
	}
}
func TestScanBudgetCancelAndExpiry(t *testing.T) {
	s, a := scanFixture(t, []Document{scanDoc(1, "a", "needle-big", nil)}, "needle")
	p, e := s.Next(context.Background(), "binding", 0, WorkBudget{10, 1})
	if e != nil || !p.Blocked || s.position != 0 {
		t.Fatal(p, e)
	}
	ctx, cancel := context.WithCancel(context.Background())
	a.cancel = cancel
	if _, e = s.Next(ctx, "binding", 1, WorkBudget{10, 100}); e == nil || s.position != 0 || s.sequence != 1 {
		t.Fatal(e)
	}
	p, e = s.Next(context.Background(), "binding", 1, WorkBudget{10, 100})
	if e != nil || len(p.Hits) != 1 || p.NextSequence != 1 {
		t.Fatal(p, e)
	}
	if _, e = s.Next(context.Background(), "wrong", 1, WorkBudget{10, 100}); e == nil {
		t.Fatal("binding")
	}
	s.expires = time.Now().Add(-time.Second)
	if _, e = s.Next(context.Background(), "binding", 1, WorkBudget{10, 100}); e == nil {
		t.Fatal("TTL")
	}
}
func TestScanConcurrentSequence(t *testing.T) {
	s, _ := scanFixture(t, []Document{scanDoc(1, "a", "needle-a", nil), scanDoc(2, "b", "needle-b", nil)}, "needle")
	var wg sync.WaitGroup
	results := make(chan ScanPage, 8)
	errs := make(chan error, 8)
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			p, e := s.Next(context.Background(), "binding", 0, WorkBudget{1, 100})
			results <- p
			errs <- e
		}()
	}
	wg.Wait()
	close(results)
	close(errs)
	for e := range errs {
		if e != nil {
			t.Fatal(e)
		}
	}
	for p := range results {
		if !reflect.DeepEqual(scanIDs(p), []string{"a"}) {
			t.Fatal(p)
		}
	}
	if s.position != 1 || s.sequence != 1 {
		t.Fatal(s.position, s.sequence)
	}
}
func TestScanEmptyTerminal(t *testing.T) {
	s, a := scanFixture(t, []Document{scanDoc(1, "a", "needle", nil), scanDoc(2, "b", "nothing", nil)}, "needle.*")
	p, e := s.Next(context.Background(), "binding", 0, WorkBudget{1, 100})
	if e != nil || len(p.Hits) != 1 {
		t.Fatal(p, e)
	}
	p, e = s.Next(context.Background(), "binding", 1, WorkBudget{1, 100})
	if e != nil || !p.CoverageComplete || p.NoMatchesProven || len(p.Hits) != 0 {
		t.Fatal(p, e)
	}
	a.denied = true
	if _, e = s.Next(context.Background(), "binding", 1, WorkBudget{1, 100}); e == nil {
		t.Fatal("empty replay auth")
	}
	zero, _ := scanFixture(t, []Document{scanDoc(1, "a", "nothing", nil)}, "needle.*")
	p, e = zero.Next(context.Background(), "binding", 0, WorkBudget{1, 100})
	if e != nil || !p.NoMatchesProven {
		t.Fatal(p, e)
	}
}
func TestScanLimit(t *testing.T) {
	s, _ := scanFixture(t, []Document{scanDoc(1, "a", "needle-a", nil), scanDoc(2, "b", "needle-b", nil)}, "needle")
	s.q.Limit = 1
	p, e := s.Next(context.Background(), "binding", 0, WorkBudget{10, 100})
	if e != nil || len(p.Hits) != 1 || p.CoverageComplete {
		t.Fatal(p, e)
	}
}

func TestScanGenerationMismatchAndDuplicateUUID(t *testing.T) {
	docs := []Document{scanDoc(1, "a", "ordinary", nil)}
	idx, err := BuildIndex(context.Background(), filepath.Join(t.TempDir(), "index"), docs)
	if err != nil {
		t.Fatal(err)
	}
	defer idx.Close()
	a := &scanAuthority{rows: map[string]format.Message{}}
	docs[0].Text = "needle"
	if _, err = NewScan(context.Background(), idx, docs, format.GrepQuery{Pattern: "needle"}, a, "binding", time.Minute); err == nil {
		t.Fatal("stale indexed body accepted")
	}
	docs = []Document{scanDoc(1, "a", "needle", nil), scanDoc(2, "a", "needle-two", nil)}
	idx2, err := BuildIndex(context.Background(), filepath.Join(t.TempDir(), "index"), docs)
	if err != nil {
		t.Fatal(err)
	}
	defer idx2.Close()
	if _, err = NewScan(context.Background(), idx2, docs, format.GrepQuery{Pattern: "needle"}, a, "binding", time.Minute); err == nil {
		t.Fatal("duplicate UUID accepted")
	}
}
func TestScanInitialInjectedNotExpandedAndTerminalStable(t *testing.T) {
	docs := []Document{scanDoc(1, "a", "needle", nil)}
	docs[0].Hit.Kind = "injected"
	s, _ := scanFixture(t, docs, "needle")
	p, err := s.Next(context.Background(), "binding", 0, WorkBudget{1, 100})
	if err != nil || len(p.Hits) != 0 || !p.CoverageComplete || p.NextSequence != 0 {
		t.Fatal(p, err)
	}
	if _, err = s.Next(context.Background(), "binding", 1, WorkBudget{1, 100}); err == nil {
		t.Fatal("new sequence after terminal")
	}
	p, err = s.Next(context.Background(), "binding", 0, WorkBudget{1, 100})
	if err != nil || !p.CoverageComplete {
		t.Fatal(p, err)
	}
}

func TestScanOriginalNonmatchAvoidsAuthorityBodyRead(t *testing.T) {
	s, a := scanFixture(t, []Document{scanDoc(1, "a", "ordinary", nil)}, "needle.*")
	p, err := s.Next(context.Background(), "binding", 0, WorkBudget{1, 100})
	if err != nil || !p.NoMatchesProven {
		t.Fatal(p, err)
	}
	if a.currentCalls != 0 {
		t.Fatal("unneeded body reads", a.currentCalls)
	}
	a.denied = true
	if _, err = s.Next(context.Background(), "binding", 0, WorkBudget{1, 100}); err == nil {
		t.Fatal("Check bypassed for empty replay")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err = s.Next(ctx, "binding", 0, WorkBudget{1, 100}); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}

func TestScanDistinctAddressesIdenticalText(t *testing.T) {
	for _, batch := range []int{1, 2} {
		t.Run(fmt.Sprintf("batch-%d", batch), func(t *testing.T) {
			s, a := scanFixture(t, []Document{scanDoc(1, "a", "needle identical", nil), scanDoc(2, "b", "needle identical", nil)}, "needle")
			first, err := s.Next(context.Background(), "binding", 0, WorkBudget{batch, 100})
			if err != nil {
				t.Fatal(err)
			}
			all := scanIDs(first)
			if batch == 1 {
				second, err := s.Next(context.Background(), "binding", 1, WorkBudget{batch, 100})
				if err != nil {
					t.Fatal(err)
				}
				all = append(all, scanIDs(second)...)
			}
			if !reflect.DeepEqual(all, []string{"a", "b"}) {
				t.Fatal("text collapsed distinct addresses", all)
			}
			a.mu.Lock()
			m := a.rows["a"]
			m.Text = "redacted"
			a.rows["a"] = m
			a.mu.Unlock()
			replay, err := s.Next(context.Background(), "binding", 0, WorkBudget{batch, 100})
			if err != nil {
				t.Fatal(err)
			}
			want := []string{}
			if batch == 2 {
				want = []string{"b"}
			}
			if !reflect.DeepEqual(scanIDs(replay), want) {
				t.Fatal(replay)
			}
			if batch == 1 {
				replay, err = s.Next(context.Background(), "binding", 1, WorkBudget{batch, 100})
				if err != nil || !reflect.DeepEqual(scanIDs(replay), []string{"b"}) {
					t.Fatal(replay, err)
				}
			}
			for _, hit := range replay.Hits {
				if hit.Copies != 0 {
					t.Fatal("distinct address reports copies", hit)
				}
				for _, line := range hit.Lines {
					if strings.Contains(line.Text, "redacted") {
						t.Fatal("stale/changed content served", line)
					}
				}
			}
		})
	}
}
