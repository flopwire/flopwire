Synthetic broad historical grep microbenchmark, 2026-10-15

Baseline origin/main 3fc0415. Dedicated Docker postgres:17 on localhost:55448; synthetic-only credentials. Container stopped after measurements. No production data/configuration accessed.

Derived deterministic hash/TOAST fixture and cursor/EXPLAIN method from #268 archived helper. run.py creates 30,000 rows / 31,036,500 text bytes. During setup, scope was corrected to (id/100)%100; the archived run.py incorporates that correction. Final measurement was after VACUUM ANALYZE and container restart. options.py adds kind/time index. results-clean.json is final matrix; earlier results.json not retained here. First final sample has cold PostgreSQL shared buffers, but warm host OS cache; no true cold-cache claim. Sequential three repeats, not p95/capacity.

Exact strings occur every100 rows; scattered cass unrelated search occurs everywhere, exercising exact-page trigram rechecks. 60 rows repeat to large TOAST bodies. This intentionally adversarial distribution is not a representative production transcript sample. Repo/session represented by scope ranges, not full production joins or #277 adapter; variant timings isolate predicate/cursor SQL and hydration, not endpoint latency.

Final clean matrix: broad regex8 Unicode-fold OR alternatives ~1.88–1.96s first fetch; fixed~0.285s; continuation no startup relief. Session regex~22ms but fixed~285ms due different access plans. Exact-page rejected rechecks29,700, no lossy blocks. Sort adds <1ms; heap text rechecks dominate. Hydration32~3–10ms.

ILIKE ANY preserves same escaped alternatives but offers no broad improvement (~1.84s) and frequent search regresses (~267 vs154–191ms). All ordered IDs equal, explicit Unicode fold/case and LIKE escape checks pass.

Factored native regex candidate with explicit [aA] and [sSſ] yields~107–159ms exact,~98–118ms frequent,~0.05ms absent. These three ASCII fixture terms match same ordered IDs. This is promising experimental evidence, not general Unicode/escaping proof or a product implementation. Keep authoritative Go regexp and prove superset for any generated native candidate.

Metadata kind/time index alone leaves broad exact fixed~279ms. Explicit LIMIT256 metadata barrier yields~1.8–2ms exact/absent/frequent, metadata-only~0.07ms. These are bounded progress pages, not full search or guaranteed first-match latency.

Artifacts: setup, clean results/plans, options/plans, OR/ANY plans/equality, factored plans, reproduction scripts. No private corpus. SQL fixtures omit auth/visibility joins and API overhead. No deployment, capacity, p95 or product-semantic equivalence claim.
