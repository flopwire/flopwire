import psycopg,itertools,json,pathlib
r=pathlib.Path(__file__).parent;c=psycopg.connect('host=127.0.0.1 port=55448 dbname=postgres user=postgres password=synthetic-only',autocommit=True);c.execute("SET statement_timeout='20s'")
out=[]
for term in ['cass search','missingneedle','search']:
 variants=[''.join(z) for z in itertools.product(*[(x,'ſ') if x=='s' else (x,) for x in term])]
 patterns=['%'+v+'%' for v in variants]
 for mode in ['or','any']:
  pred='('+' OR '.join('text ILIKE %s' for _ in patterns)+')' if mode=='or' else 'text ILIKE ANY(%s)'
  args=patterns if mode=='or' else [patterns]
  sql="SELECT id FROM messages WHERE "+pred+" AND ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 200000"
  plans=[c.execute('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+sql,args).fetchone()[0][0] for _ in range(3)]
  ids=[x[0] for x in c.execute(sql,args)]
  out.append({'term':term,'mode':mode,'plans':plans,'ids':ids})
  print(term,mode,[x['Execution Time'] for x in plans],len(ids),flush=True)
 assert out[-1]['ids']==out[-2]['ids']
# Explicit case-fold alternatives with punctuation and escaped LIKE metacharacters.
for term in ['cass search','CASS SEARCH','a%s_s\\x']:
 esc=lambda s:s.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
 variants=[''.join(z) for z in itertools.product(*[(x,'ſ') if x.lower()=='s' else (x,) for x in term])]
 patterns=['%'+esc(v)+'%' for v in variants]
 texts=variants+[v.swapcase() for v in variants]+['no match','cass unrelated search']
 for body in texts:
  got=c.execute('SELECT ('+' OR '.join('%s ILIKE %s' for _ in patterns)+'), %s ILIKE ANY(%s)',sum(([body,p] for p in patterns),[])+[body,patterns]).fetchone()
  assert got[0]==got[1],(term,body,got)
(r/'any.json').write_text(json.dumps(out,indent=2));print('EQUALITY PASSED',flush=True)
