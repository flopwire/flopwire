exec(open('/tmp/flopwire-broad-grep-20261015/any.py').read().split('out=[]')[0])
import re
out=[]
for term in ['cass search','missingneedle','search']:
 pattern=''.join('[sSſ]' if x=='s' else '['+x+x.upper()+']' if x.isalpha() else re.escape(x) for x in term)
 sql="SELECT id FROM messages WHERE text ~ %s AND ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 200000"
 plans=[c.execute('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+sql,[pattern]).fetchone()[0][0] for _ in range(3)]
 ids=[x[0] for x in c.execute(sql,[pattern])];previous=next(x['ids'] for x in json.load(open(r/'any.json')) if x['term']==term)
 assert ids==previous
 out.append({'term':term,'pattern':pattern,'plans':plans,'ids':ids});print(term,[x['Execution Time'] for x in plans],len(ids),flush=True)
(r/'factored.json').write_text(json.dumps(out,indent=2))
