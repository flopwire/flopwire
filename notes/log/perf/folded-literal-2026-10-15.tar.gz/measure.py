import psycopg,time,json,pathlib
r=pathlib.Path(__file__).parent
c=psycopg.connect('host=127.0.0.1 port=55448 dbname=postgres user=postgres password=synthetic-only',autocommit=True)
c.execute("SET statement_timeout='20s'")
out=[]

for scope,extra in [('broad',''),('repo',' AND scope<10'),('session',' AND scope=0')]:
 for fixed in [False,True]:
  for continuation in [False,True]:
   variants=['']
   if not fixed:
    import itertools
    variants=[''.join(z) for z in itertools.product(*[(x,'ſ') if x=='s' else (x,) for x in 'cass search'])]
   predicate="("+" OR ".join("text ILIKE '%"+v+"%'" for v in variants)+")" if not fixed else "text ILIKE '%cass search%'"
   sql="SELECT id FROM messages WHERE "+predicate+" AND ts<25000 AND kind='tool_call'"+extra+' ORDER BY ts DESC NULLS LAST,id'+('' if continuation else ' LIMIT 200000')
   runs=[]
   for repeat in range(3):
    t=time.perf_counter()
    with c.transaction():
     cur=c.cursor(name='candidate');cur.execute(sql); declared=(time.perf_counter()-t)*1000
     ids=[x[0] for x in cur.fetchmany(32 if continuation else 256)];first=(time.perf_counter()-t)*1000
    h=time.perf_counter();bodies=list(c.execute('SELECT id,text FROM messages WHERE id=ANY(%s)',(ids,)));hydrate=(time.perf_counter()-h)*1000
    assert all('cass search' in b for _,b in bodies)
    runs.append({'repeat':repeat,'declare_ms':declared,'first_fetch_ms':first,'hydrate_ms':hydrate,'ids':len(ids)})
   plan=c.execute('EXPLAIN (ANALYZE,BUFFERS,SETTINGS,FORMAT JSON) '+sql).fetchone()[0][0]
   row={'scope':scope,'fixed':fixed,'continuation':continuation,'runs':runs,'plan':plan};out.append(row)
   (r/'results-clean.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in row.items() if k!='plan'}),flush=True)
