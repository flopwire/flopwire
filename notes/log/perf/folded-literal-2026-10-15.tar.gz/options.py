import psycopg,json,pathlib,time
r=pathlib.Path(__file__).parent;c=psycopg.connect('host=127.0.0.1 port=55448 dbname=postgres user=postgres password=synthetic-only',autocommit=True);c.execute("SET statement_timeout='20s'")
c.execute('CREATE INDEX metadata_kind_ts ON messages(kind,ts DESC NULLS LAST,id)')
qs={
'ordinary_index':"SELECT id FROM messages WHERE text ILIKE '%cass search%' AND ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 200000",
'metadata_page':"SELECT id FROM messages WHERE ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 256",
'barrier_page':"SELECT id FROM (SELECT id,ts,text FROM messages WHERE ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 256 OFFSET 0) eligible WHERE text ILIKE '%cass search%' ORDER BY ts DESC NULLS LAST,id",
'absent_page':"SELECT id FROM (SELECT id,ts,text FROM messages WHERE ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 256 OFFSET 0) eligible WHERE text ILIKE '%missingneedle%' ORDER BY ts DESC NULLS LAST,id",
'frequent_page':"SELECT id FROM (SELECT id,ts,text FROM messages WHERE ts<25000 AND kind='tool_call' ORDER BY ts DESC NULLS LAST,id LIMIT 256 OFFSET 0) eligible WHERE text ILIKE '%search%' ORDER BY ts DESC NULLS LAST,id"
}
o={}
for n,q in qs.items():
 o[n]=[c.execute('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+q).fetchone()[0][0] for _ in range(3)];print(n,[x['Execution Time'] for x in o[n]],flush=True)
(r/'options.json').write_text(json.dumps(o,indent=2))
