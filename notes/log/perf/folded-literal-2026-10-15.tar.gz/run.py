import psycopg,hashlib,time,json,pathlib
root=pathlib.Path(__file__).parent
c=psycopg.connect('host=127.0.0.1 port=55448 dbname=postgres user=postgres password=synthetic-only',autocommit=True)
c.execute("SET statement_timeout='20s'")
c.execute('CREATE EXTENSION pg_trgm')
c.execute('CREATE TABLE messages(id bigint PRIMARY KEY, ts bigint, scope int, kind text, text text)')
t=time.perf_counter()
with c.cursor().copy('COPY messages FROM STDIN') as cp:
 for i in range(1,30001):
  body=' '.join(hashlib.md5(f'{i}:{j}'.encode()).hexdigest() for j in range(24))+' cass unrelated search marker '
  if i%100==0: body+=' cass search exact '
  if i%500==0: body*=128
  cp.write_row((i,i,(i//100)%100,'tool_call' if i%3 else 'tool_result',body))
c.execute("SET statement_timeout='5min'")
c.execute('CREATE INDEX messages_text_trgm_idx ON messages USING gin(text gin_trgm_ops)')
c.execute('CREATE INDEX conversation_idx ON messages(scope,id)')
c.execute('ANALYZE messages')
(root/'setup.json').write_text(json.dumps({'setup_s':time.perf_counter()-t,'rows_bytes':c.execute('SELECT count(*),sum(octet_length(text)) FROM messages').fetchone()}))
print('SETUP DONE',flush=True)
