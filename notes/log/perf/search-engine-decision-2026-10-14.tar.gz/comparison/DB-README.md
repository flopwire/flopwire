# Isolated comparison database

Use cached `postgres:17.6-bookworm`. Container `flopwire-engine-decision-pg-20261014` exposes only loopback port 55450. Files stay in this POC's `dbdata` directory. Do not use an existing database service.

Change directory to `.poc-stress-test/comparison`. Run `sh db-start.sh` once.

Set `FLOPWIRE_TEST_DATABASE_URL='postgres://postgres:synthetic-engine-poc@127.0.0.1:55450/postgres?sslmode=disable'`. Run small tests with `go test -race -count=1 -v -run '^TestDecisionPG' .`.

After the parent approves the host timing slot, run `FLOPWIRE_DECISION_BENCH=1 go test -count=1 -v -run '^TestDecisionEngineBenchmark$' -timeout 20m .` with the database URL set in the same environment.

Optional controls: `FLOPWIRE_DECISION_N` (default 50000), `FLOPWIRE_DECISION_REPEATS` (default 20), `FLOPWIRE_DECISION_PATTERNS` (comma-separated), `FLOPWIRE_DECISION_ALL_ONLY=1`, `FLOPWIRE_DECISION_SCOPED_ONLY=1`, `FLOPWIRE_DECISION_SKIP_BURST=1`, and `FLOPWIRE_DECISION_LABEL` (unique evidence directory). Each test creates and drops its own database through `pgtest.NewDatabase` and applies real production migrations.

The 50000-message corpus contains exactly 134144076 synthetic text bytes, including approximately 270 KiB tool-result bodies. All production indexes and triggers remain. Both common engines use the same repeatable-read visibility fence, frozen version/SHA/rank manifest, 128-row SQL hydration, original Go verifier, and per-message production line collector. First-page measurements return 20 distinct UUIDs or exhaustive completion. Full parity compares every ordered UUID with the oracle.

Actual `retrieval.Store.Grep` is a separate essential baseline. It retains the production cursor, totals, and unindexed-pattern policy. Bodies are unique, so duplicate policy does not change these result addresses. The common PostgreSQL route fully enumerates candidates and can differ from the production cursor. Unsupported common regexes explicitly use a bounded scan; this is a POC extension over the production global refusal. Backend measurements exclude HTTP authentication and serialization.

Warm repeats alternate engine order. Thirty simultaneous mixed calls share an 8-active/64-waiting admission controller. This workload does not model 30 people. Per-call deadlines are 30 seconds. The measurement stages have a 10-minute deadline after seeding. Cold-cache behavior is unproven. Timeouts, cap failures, and parity failures remain visible in persisted JSONL.

Run `sh db-stop.sh` after final checks. Archive sources and small evidence before deleting the POC. Exclude `dbdata`.
