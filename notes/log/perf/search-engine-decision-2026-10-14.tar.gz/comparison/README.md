# Search engine and freshness decision POC

This archive accompanies PR #271. Run it inside the Flopwire repository at
`.poc-stress-test/comparison`; `go.mod` replaces the parent module with `../..`.
The production source baseline is `b4f4bb5e` (#267). No production module or
runtime code changed. All fixture content is synthetic.

## Reproduce

1. Extract this archive into `.poc-stress-test/`.
2. Change directory to `.poc-stress-test/comparison`.
3. Run `sh db-start.sh`.
4. Export `FLOPWIRE_TEST_DATABASE_URL='postgres://postgres:synthetic-engine-poc@127.0.0.1:55450/postgres?sslmode=disable'`.
5. Run `go test -race -count=1 -v -run '^TestDecision' -skip 'Cost|Benchmark' .`.
6. Run `FLOPWIRE_DECISION_BENCH=1 FLOPWIRE_DECISION_N=50000 FLOPWIRE_DECISION_REPEATS=20 FLOPWIRE_DECISION_LABEL=reproduction go test -count=1 -v -run '^TestDecisionEngineBenchmark$' -timeout 20m .`.
7. Run `FLOPWIRE_DECISION_BENCH=1 FLOPWIRE_DECISION_N=50000 FLOPWIRE_DECISION_REPEATS=5 FLOPWIRE_DECISION_SCOPED_ONLY=1 FLOPWIRE_DECISION_LABEL=scoped-reproduction go test -count=1 -v -run '^TestDecisionEngineBenchmark$' -timeout 20m .` if the initial run did not complete scoped/burst stages.
8. Run `go test -count=1 -v -run '^TestDecisionFreshnessLedgerCaptureCost$' -timeout 5m .`.
9. Run `python3 decision_summary.py`.
10. Run `sh db-stop.sh`.
11. Preserve any new evidence before removing `.poc-stress-test/`.

Run measurement jobs sequentially. Setup builds real production indexes and
can take several minutes. The engine test has a ten-minute measurement deadline
and 30-second per-call deadlines. Preserve failures; do not count incomplete
runs as successful latency samples. See DB-README.md for fixture and controls.

## Contents

- `decision_*`: same-corpus engines, production Store.Grep baseline, oracle,
  batched verifier, bounded admission, measurements and summary script.
- `freshness*`: rejected full-metadata capture and replacement exact-event
  coverage ledger. Ledger tables are isolated fixtures, not migrations.
- `index*`, `scan*`, `types.go`, `authority.go`, `postgres_test.go`: inherited
  adapter infrastructure and tests from PR #269. Old timing artifacts are
  excluded. The new engine runner does not use its per-hit HTTP scan path.
- `decision-evidence`: final comparison samples, summaries, environment,
  review and combined race log.
- `evidence/freshness*`: prototype and ledger correctness/cost evidence.

## Interpretation

`first_useful_ms` means reaching 20 distinct addresses or exhaustive completion.
The main latency table uses total first-page call time, including transaction
completion. Common engines share candidate enumeration, current database
visibility filtering, frozen version/SHA/rank checks, 128-row hydration and
production Go matching. The real Store.Grep baseline retains its own cursor,
totals and policy. It is not the common PostgreSQL adapter.

The corpus is deterministic hash text with broad trigram collisions, 100 large
bodies and skewed scope zero. It diagnoses a mechanism; it does not model a
30-person team. Timings are warm local backend calls on a shared host. HTTP,
authentication, concurrent ingestion and distributed continuation are excluded
from engine timings. Authority and mutation behavior have separate tests.

Twenty repeats provide a descriptive nearest-rank p95, not a capacity or
confidence guarantee. The mixed burst starts 30 calls together, permits eight
active calls and includes admission wait. A person is not a concurrent request.

The ledger captures a pinned immutable base plus committed uncovered events.
Exact event acknowledgments avoid sequence-allocation/commit-order races.
Its pending partial index still requires vacuum/cleanup, and each publication
copies the base map. All production mutation paths and retention policies remain
to be integrated. The engine benchmark and freshness ledger are separate POCs;
there is no end-to-end implementation of their combined design here.

## Recorded runs

`50k20` preserves the original failed overall-deadline run. Its complete unscoped
measurements are usable as described in the report; later already-canceled calls
are invalid timing samples. One unscoped exhaustive embedded attempt reached its
30-second per-call deadline. `decision_bench_test.initial.go.txt` preserves that
initial harness. The corrected harness stops when its global deadline expires.

`50k-scoped5-burst` is the successful scoped follow-up with five warm repeats and
the same mixed 30-call workload across both scopes for each engine. It is not a
replacement for the failed evidence. All 60 burst calls matched their oracles.
The summary script retains error counts and attempt durations; do not interpret
already-canceled call durations from the first run as latency percentiles.
