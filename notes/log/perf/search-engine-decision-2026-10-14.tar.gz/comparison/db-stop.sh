#!/bin/sh
set -eu
docker stop flopwire-engine-decision-pg-20261014
docker rm flopwire-engine-decision-pg-20261014
