# Independent review, 2026-10-14

Sol reviewers inspected the common PostgreSQL runner, shared embedded index, freshness designs and concurrent PRs. The parent assessed their recommendations.

- Added the actual production Store.Grep baseline because draining all common PostgreSQL candidates changes the algorithm and could exaggerate embedded gains.
- Kept candidate startup, visibility fencing, batch hydration and exact verification inside first-page timings. Corpus cloning/hashing occurs once per immutable generation and remains a separately measured build cost.
- Replaced full metadata capture after its 250,000-row allocation/cost result. Preserve that failed prototype and measurements as evidence.
- A reviewer found a cache-publication race: Capture/Release could retire a committed generation before current-generation assignment. One lock now spans cache installation, commit, assignment and retirement. A deterministic post-commit barrier test covers it. The final read-only review approved this fix within POC scope.
- Exact acknowledged event IDs and per-message revisions preserve late commits; global sequence values are not commit watermarks.
- Remaining gates: physical pending-index maintenance, full-base publication copying, historical body retention, production-wide mutation/version integration, bounded candidate enumeration, current authorization, and deployment capacity.

The combined final correctness command passed under Go race detection in 35.270 seconds. Benchmark results and production qualification are separate.

Adjacent work: #267 is in the comparison base b4f4bb5; its receiver-authorized shared excerpts remain the authority boundary. Open #272 preserves repository scope without a local full index; #273 binds delegated execution and waits for upload drain; #274 isolates retained inboxes by server/device authority. None changes hosted grep or the comparison schema. Search publication must not equate upload acknowledgment with complete index coverage, and cursors must bind to server/principal/instance identity.

Store.Grep interpretation: Exact=false can reflect a bounded footer count after the first 20 results (countExtra/countTime), while first-page address parity remains true. Production uses 256-row batches and carries full metadata; the common runner uses 128 rows and invokes the line collector but retains only matching IDs for comparison. Engine attribution comes from common-runner phase timings, not the whole Store/embedded ratio. Scope zero contains every heron match and every large body, so it is not a random one-percent corpus.

Final report review verified the twenty-repeat unscoped tables and phase medians against retained summaries, and approved only the gated acceleration recommendation. The report retains the original overall deadline failure and invalid canceled calls, separately from the genuine per-call exhaustive timeout. Scoped follow-up passed with all ten full ordered-oracle comparisons, all 75 warm first-page calls, and all 60 mixed-burst calls matching expected pages.
