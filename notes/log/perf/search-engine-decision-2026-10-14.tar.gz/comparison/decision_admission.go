package adapter

import (
	"context"
	"errors"
	"time"
)

var ErrDecisionOverloaded = errors.New("bounded admission queue full")

// DecisionAdmission bounds active and waiting calls. It does not promise
// per-principal fairness or preemption; the callback must respect its context.
type DecisionAdmission struct{ active, outstanding chan struct{} }

func NewDecisionAdmission(active, queued int) *DecisionAdmission {
	if active <= 0 || queued < 0 {
		panic("invalid admission limits")
	}
	return &DecisionAdmission{make(chan struct{}, active), make(chan struct{}, active+queued)}
}
func (a *DecisionAdmission) Run(ctx context.Context, fn func(context.Context) error) (time.Duration, error) {
	start := time.Now()
	if err := ctx.Err(); err != nil {
		return time.Since(start), err
	}
	select {
	case a.outstanding <- struct{}{}:
	default:
		return time.Since(start), ErrDecisionOverloaded
	}
	defer func() { <-a.outstanding }()
	select {
	case a.active <- struct{}{}:
	case <-ctx.Done():
		return time.Since(start), ctx.Err()
	}
	defer func() { <-a.active }()
	waited := time.Since(start)
	if err := ctx.Err(); err != nil {
		return waited, err
	}
	return waited, fn(ctx)
}
