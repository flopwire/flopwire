package adapter

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestDecisionAdmissionBoundsAndCancellation(t *testing.T) {
	a := NewDecisionAdmission(1, 1)
	entered := make(chan struct{})
	release := make(chan struct{})
	done := make(chan error, 1)
	go func() {
		_, err := a.Run(t.Context(), func(context.Context) error { close(entered); <-release; return nil })
		done <- err
	}()
	<-entered
	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()
	waiting := make(chan error, 1)
	go func() {
		_, err := a.Run(ctx, func(context.Context) error { t.Error("canceled queue executed"); return nil })
		waiting <- err
	}()
	deadline := time.After(time.Second)
	for len(a.outstanding) != 2 {
		select {
		case <-deadline:
			t.Fatal("queue never filled")
		default:
			time.Sleep(time.Millisecond)
		}
	}
	if _, err := a.Run(t.Context(), func(context.Context) error { return nil }); !errors.Is(err, ErrDecisionOverloaded) {
		t.Fatal(err)
	}
	cancel()
	if err := <-waiting; !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	close(release)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	if len(a.active) != 0 || len(a.outstanding) != 0 {
		t.Fatal("admission slot leaked")
	}
}
func TestDecisionAdmissionConcurrentCap(t *testing.T) {
	a := NewDecisionAdmission(3, 30)
	var active, maximum atomic.Int64
	var wg sync.WaitGroup
	for i := 0; i < 30; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_, err := a.Run(t.Context(), func(context.Context) error {
				n := active.Add(1)
				defer active.Add(-1)
				for old := maximum.Load(); n > old; old = maximum.Load() {
					if maximum.CompareAndSwap(old, n) {
						break
					}
				}
				time.Sleep(time.Millisecond)
				return nil
			})
			if err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if maximum.Load() > 3 {
		t.Fatal("active cap exceeded", maximum.Load())
	}
}
