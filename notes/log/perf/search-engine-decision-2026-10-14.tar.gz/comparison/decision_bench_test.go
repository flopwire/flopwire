package adapter

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/flopwire/flopwire/internal/retrieval"
	"github.com/flopwire/flopwire/internal/retrieval/format"
)

func decisionEnvInt(name string, def int) int {
	if s := os.Getenv(name); s != "" {
		n, err := strconv.Atoi(s)
		if err == nil && n > 0 {
			return n
		}
	}
	return def
}

// Heavy measurements run only with explicit opt-in. All evidence is synthetic.
func TestDecisionEngineBenchmark(t *testing.T) {
	if os.Getenv("FLOPWIRE_DECISION_BENCH") != "1" {
		t.Skip("explicit benchmark opt-in required")
	}
	n := decisionEnvInt("FLOPWIRE_DECISION_N", 50000)
	repeats := decisionEnvInt("FLOPWIRE_DECISION_REPEATS", 20)
	patterns := []string{"ancientneedle", "heron", "timeout|failure", "[A-Za-z]{30}", ".*"}
	if v := os.Getenv("FLOPWIRE_DECISION_PATTERNS"); v != "" {
		patterns = strings.Split(v, ",")
	}
	f := NewDecisionFixture(t, n)
	if n == 50000 && f.LogicalBytes != 134144076 {
		t.Fatalf("original corpus changed bytes=%d", f.LogicalBytes)
	}
	ctx, cancel := context.WithTimeout(t.Context(), 10*time.Minute)
	defer cancel()
	start := time.Now()
	index, err := BuildDecisionIndex(ctx, t.TempDir()+"/engine-index", f.Documents)
	if err != nil {
		t.Fatal(err)
	}
	defer index.Close()
	indexMS := millis(start)
	var relationBytes int64
	if err = f.PG.pool.QueryRow(ctx, "SELECT pg_total_relation_size('messages')").Scan(&relationBytes); err != nil {
		t.Fatal(err)
	}
	label := fmt.Sprintf("n%d-r%d", n, repeats)
	if v := os.Getenv("FLOPWIRE_DECISION_LABEL"); v != "" {
		label = v
	}
	dir := filepath.Join("decision-evidence", label)
	if err = os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	evidence, err := os.Create(filepath.Join(dir, "samples.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	defer evidence.Close()
	var mu sync.Mutex
	emit := func(v any) {
		raw, _ := json.Marshal(v)
		mu.Lock()
		defer mu.Unlock()
		fmt.Fprintln(evidence, string(raw))
		t.Log(string(raw))
	}
	emit(map[string]any{"stage": "setup", "n": n, "logical_bytes": f.LogicalBytes, "postgres_relation_bytes": relationBytes, "seed_ms": f.SeedMS, "embedded_build_ms": indexMS, "repeats": repeats, "cache": "warm exploratory; cold cache unproven", "transport": "backend direct, HTTP auth excluded", "scope": "default eligible rows; warm scope flags apply; mixed burst always both scopes", "scoped_only": os.Getenv("FLOPWIRE_DECISION_SCOPED_ONLY") == "1", "all_only": os.Getenv("FLOPWIRE_DECISION_ALL_ONLY") == "1", "batch_rows": 128, "page_messages": 20})
	engines := []DecisionCandidateEngine{DecisionPG{}, index}
	store := &retrieval.Store{Pool: f.PG.pool}
	failures := 0
	checkMeasurement := func(stage string) {
		if err := ctx.Err(); err != nil {
			emit(map[string]any{"stage": "measurement_aborted", "before_stage": stage, "error": err.Error(), "failures_recorded": failures})
			t.Fatalf("measurement deadline reached before %s; stopped without recording subsequent canceled-context calls", stage)
		}
	}
	oraclePages := map[string][]string{}
	scopes := [][]string{nil, f.ScopeIDs}
	if os.Getenv("FLOPWIRE_DECISION_ALL_ONLY") == "1" {
		scopes = [][]string{nil}
	}
	if os.Getenv("FLOPWIRE_DECISION_SCOPED_ONLY") == "1" {
		if os.Getenv("FLOPWIRE_DECISION_ALL_ONLY") == "1" {
			t.Fatal("SCOPED_ONLY and ALL_ONLY cannot both be set")
		}
		scopes = [][]string{f.ScopeIDs}
	}
	for _, scope := range scopes {
		for _, pattern := range patterns {
			checkMeasurement("pattern oracle")
			q := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: pattern, Limit: 20}, ConversationIDs: scope, CandidateCap: 1000000}
			oracle, err := DecisionOracle(f.Documents, q)
			if err != nil {
				t.Fatal(err)
			}
			want := oracle[:min(20, len(oracle))]
			oraclePages[fmt.Sprintf("%t:%s", scope != nil, pattern)] = want
			// Preserve actual Store.Grep's cursor/collector strategy and policy separately.
			filters := format.Filters{}
			if scope != nil {
				filters.Session = f.ScopeSession
			}
			baseline := func(repetition int) {
				checkMeasurement("actual Store.Grep")
				baselineCtx, done := context.WithTimeout(ctx, 30*time.Second)
				begin := time.Now()
				p, baselineErr := store.Grep(baselineCtx, q.Query, filters)
				done()
				ids := []string{}
				if p != nil {
					for _, h := range p.Hits {
						ids = append(ids, h.MessageID)
					}
				}
				record := map[string]any{"stage": "actual_store", "repetition": repetition, "pattern": pattern, "scoped": scope != nil, "total_ms": millis(begin), "ids_equal": strings.Join(ids, ",") == strings.Join(want, ","), "hits": len(ids), "global_deadline_expired": ctx.Err() != nil}
				if baselineErr != nil {
					record["error"] = baselineErr.Error()
					_, _, fallback, _ := decisionPGSQL(q)
					expectedPolicy := fallback && scope == nil && strings.Contains(baselineErr.Error(), "specify a session")
					record["expected_policy_refusal"] = expectedPolicy
					if !expectedPolicy {
						failures++
					}
				} else {
					record["exact"] = p.Exact
					record["truncated"] = p.Truncated
					if p.Truncated || strings.Join(ids, ",") != strings.Join(want, ",") {
						failures++
					}
				}
				emit(record)
				checkMeasurement("after actual Store.Grep")
			}
			baseline(-1)
			for _, engine := range engines {
				checkMeasurement("full parity")
				runCtx, done := context.WithTimeout(ctx, 30*time.Second)
				run, err := RunDecision(runCtx, f.PG.pool, engine, q, true)
				done()
				equal := err == nil && strings.Join(run.IDs, ",") == strings.Join(oracle, ",")
				emit(map[string]any{"stage": "full_parity", "run": run, "oracle_count": len(oracle), "oracle_equal": equal, "global_deadline_expired": ctx.Err() != nil})
				if !equal {
					failures++
				}
				checkMeasurement("after full parity")
			}
			for repetition := 0; repetition < repeats; repetition++ {
				checkMeasurement("warm repetition")
				if repetition%2 == 0 {
					baseline(repetition)
				}
				order := engines
				if repetition%2 == 1 {
					order = []DecisionCandidateEngine{index, DecisionPG{}}
				}
				for _, engine := range order {
					checkMeasurement("warm first page")
					runCtx, done := context.WithTimeout(ctx, 30*time.Second)
					run, err := RunDecision(runCtx, f.PG.pool, engine, q, false)
					done()
					equal := err == nil && strings.Join(run.IDs, ",") == strings.Join(want, ",")
					emit(map[string]any{"stage": "warm_first_page", "repetition": repetition, "run": run, "oracle_equal": equal, "global_deadline_expired": ctx.Err() != nil})
					if !equal {
						failures++
					}
					checkMeasurement("after warm first page")
				}
				if repetition%2 == 1 {
					baseline(repetition)
				}
			}
		}
	}
	if os.Getenv("FLOPWIRE_DECISION_SKIP_BURST") != "1" {
		checkMeasurement("mixed burst oracle preparation")
		burstScopes := [][]string{nil, f.ScopeIDs}
		for _, scope := range burstScopes {
			for _, pattern := range patterns {
				key := fmt.Sprintf("%t:%s", scope != nil, pattern)
				if _, exists := oraclePages[key]; exists {
					continue
				}
				checkMeasurement("missing mixed burst oracle")
				q := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: pattern, Limit: 20}, ConversationIDs: scope, CandidateCap: 1000000}
				oracle, err := DecisionOracle(f.Documents, q)
				if err != nil {
					t.Fatal(err)
				}
				oraclePages[key] = oracle[:min(20, len(oracle))]
			}
		}
		// Thirty calls are a specified mixed burst, not a model of thirty people.
		for _, engine := range engines {
			checkMeasurement("mixed burst engine")
			admission := NewDecisionAdmission(8, 64)
			var wg sync.WaitGroup
			release := make(chan struct{})
			type burstJob struct {
				query DecisionQuery
				want  []string
			}
			jobs := make([]burstJob, 30)
			for i := range jobs {
				pattern := patterns[i%len(patterns)]
				scope := burstScopes[i%len(burstScopes)]
				jobs[i] = burstJob{query: DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: pattern, Limit: 20}, ConversationIDs: scope, CandidateCap: 1000000}, want: oraclePages[fmt.Sprintf("%t:%s", scope != nil, pattern)]}
			}
			for i := 0; i < 30; i++ {
				wg.Add(1)
				go func(i int) {
					defer wg.Done()
					<-release
					job := jobs[i]
					q := job.query
					pattern := q.Query.Pattern
					scope := q.ConversationIDs
					want := job.want

					runCtx, done := context.WithTimeout(ctx, 30*time.Second)
					defer done()
					begin := time.Now()
					var run DecisionRun
					wait, err := admission.Run(runCtx, func(c context.Context) error {
						var err error
						run, err = RunDecision(c, f.PG.pool, engine, q, false)
						return err
					})
					equal := err == nil && strings.Join(run.IDs, ",") == strings.Join(want, ",")
					record := map[string]any{"stage": "mixed_burst", "attempt": i, "engine": engine.Name(), "pattern": pattern, "scoped": scope != nil, "queue_wait_ms": float64(wait.Microseconds()) / 1000, "total_including_queue_ms": millis(begin), "run": run, "oracle_equal": equal, "global_deadline_expired": ctx.Err() != nil}
					if err != nil {
						record["error"] = err.Error()
					}
					emit(record)
					if !equal {
						mu.Lock()
						failures++
						mu.Unlock()
					}
				}(i)
			}
			close(release)
			wg.Wait()
			checkMeasurement("after mixed burst engine")
		}
	}
	if failures > 0 {
		t.Fatalf("comparison recorded %d errors or oracle mismatches; inspect persisted evidence", failures)
	}
}
