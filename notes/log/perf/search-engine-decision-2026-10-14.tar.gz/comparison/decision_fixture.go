package adapter

import (
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"regexp"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/flopwire/flopwire/internal/retrieval/grep"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
)

type DecisionFixture struct {
	PG            *pgFixture
	Documents     []Document
	Conversations []string
	ScopeIDs      []string
	ScopeSession  string
	LogicalBytes  int64
	SeedMS        float64
	Expected      map[string]DecisionVersion
}

func decisionBody(i int) string {
	parts := make([]string, 64)
	for j := 1; j <= 64; j++ {
		sum := md5.Sum([]byte(fmt.Sprintf("%d:%d", i, j)))
		parts[j-1] = hex.EncodeToString(sum[:])
	}
	body := strings.Join(parts, " ") + " her xxx ero xxx ron "
	if i%100 == 0 {
		body += " heron protocol "
	}
	if i%5 == 0 {
		body += " timeout "
	} else if i%7 == 0 {
		body += " failure "
	}
	if i <= 50 {
		body += " ancientneedle "
	}
	if i%500 == 0 {
		body = strings.Repeat(body, 128)
	}
	return body
}

// NewDecisionFixture builds the previous deterministic synthetic corpus in the
// REAL migrated message schema with all production indexes/triggers intact.
func NewDecisionFixture(t *testing.T, n int) *DecisionFixture {
	t.Helper()
	f := newPGFixture(t)
	start := time.Now()
	out := &DecisionFixture{PG: f, Expected: make(map[string]DecisionVersion, n)}
	ctx := t.Context()
	for scope := 0; scope < 100; scope++ {
		conv := uuid.NewString()
		session := fmt.Sprintf("decision-scope-%03d-%s", scope, conv)
		if _, err := f.pool.Exec(ctx, `INSERT INTO conversations(id,agent,session_id,device_id,user_id,repo_root) VALUES($1,'codex',$2,$3,$4,'/synthetic/decision')`, conv, session, f.device, f.owner); err != nil {
			t.Fatal(err)
		}
		out.Conversations = append(out.Conversations, conv)
		if scope == 0 {
			out.ScopeIDs = []string{conv}
			out.ScopeSession = session
		}
	}
	base := time.Date(2026, 10, 1, 0, 0, 0, 0, time.UTC)
	out.Documents = make([]Document, n)
	for i := 1; i <= n; i++ {
		body := decisionBody(i)
		out.LogicalBytes += int64(len(body))
		id := uuid.NewSHA1(uuid.NameSpaceOID, []byte(fmt.Sprintf("decision-message-%d", i))).String()
		at := base.Add(time.Duration(i) * time.Second)
		scope := i % 100
		kind := "assistant"
		if i%500 == 0 {
			kind = "tool_result"
		}
		out.Documents[i-1] = Document{ID: int64(i), UUID: id, Text: body, Version: 1, Hit: format.Hit{MessageID: id, ConversationID: out.Conversations[scope], Agent: "codex", SessionID: fmt.Sprintf("decision-scope-%03d-%s", scope, out.Conversations[scope]), Ordinal: int64((i-1)/100 + 1), Kind: kind, TS: &at}}
		out.Expected[id] = DecisionVersion{Version: 1, SHA: sha256.Sum256([]byte(body))}
	}
	ranked := append([]Document(nil), out.Documents...)
	sortDecisionDocuments(ranked)
	for rank, d := range ranked {
		v := out.Expected[d.UUID]
		v.Rank = rank
		out.Expected[d.UUID] = v
	}
	_, err := f.pool.CopyFrom(ctx, pgx.Identifier{"messages"}, []string{"id", "conversation_id", "ordinal", "kind", "ts", "text", "text_len", "content_sha", "source_generation", "parser"}, pgx.CopyFromSlice(n, func(i int) ([]any, error) {
		d := out.Documents[i]
		sum := sha256.Sum256([]byte(d.Text))
		return []any{d.UUID, d.Hit.ConversationID, d.Hit.Ordinal, d.Hit.Kind, d.Hit.TS, d.Text, len(d.Text), sum[:], int64(0), "synthetic-decision"}, nil
	}))
	if err != nil {
		t.Fatal(err)
	}
	if _, err = f.pool.Exec(ctx, "ANALYZE messages"); err != nil {
		t.Fatal(err)
	}
	out.SeedMS = millis(start)
	return out
}

func DecisionOracle(docs []Document, q DecisionQuery) ([]string, error) {
	plan, err := decisionRegexp(q.Query)
	if err != nil {
		return nil, err
	}
	allowed := map[string]bool{}
	for _, id := range q.ConversationIDs {
		allowed[id] = true
	}
	matches := []Document{}
	for _, d := range docs {
		if q.ConversationIDs != nil && !allowed[d.Hit.ConversationID] {
			continue
		}
		if plan.MatchString(d.Text) {
			matches = append(matches, d)
		}
	}
	sortDecisionDocuments(matches)
	ids := make([]string, len(matches))
	for i, d := range matches {
		ids[i] = d.UUID
	}
	return ids, nil
}

func decisionRegexp(q format.GrepQuery) (*regexp.Regexp, error) {
	p, err := grep.Compile(q)
	if err != nil {
		return nil, err
	}
	return p.Re, nil
}
func sortDecisionDocuments(docs []Document) {
	sort.Slice(docs, func(i, j int) bool {
		a, b := docs[i], docs[j]
		if a.Hit.TS == nil && b.Hit.TS != nil {
			return false
		}
		if a.Hit.TS != nil && b.Hit.TS == nil {
			return true
		}
		if a.Hit.TS != nil && !a.Hit.TS.Equal(*b.Hit.TS) {
			return a.Hit.TS.After(*b.Hit.TS)
		}
		return a.UUID < b.UUID
	})
}
