package adapter

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"sync"

	"github.com/flopwire/flopwire/internal/retrieval/grep"
	"github.com/jackc/pgx/v5"
)

const decisionDefaultCandidateCap = 100000

// DecisionIndex pins one generation for its lifetime. Construction owns the
// document clone, content hash validation and shard loading. Queries do none of
// those whole-history operations. Its metadata maps are immutable after build.
//
// CandidateIndex still materializes every engine match before this wrapper can
// apply scope/cap. The cap bounds downstream hydration, not engine CPU/memory.
// This is an explicit unresolved gate for huge match sets, not a bounded pager.
type DecisionIndex struct {
	mu         sync.RWMutex
	index      *CandidateIndex
	docs       []Document
	byID       map[int64]decisionIndexMetadata
	generation string
	closed     bool
}
type decisionIndexMetadata struct{ uuid, conversation string }

var _ DecisionCandidateEngine = (*DecisionIndex)(nil)

func BuildDecisionIndex(ctx context.Context, dir string, docs []Document) (*DecisionIndex, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	cloned := make([]Document, len(docs))
	byID := make(map[int64]decisionIndexMetadata, len(docs))
	uuids := make(map[string]bool, len(docs))
	for i, d := range docs {
		if i%256 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		if d.UUID == "" || uuids[d.UUID] {
			return nil, fmt.Errorf("empty/duplicate generation UUID %q", d.UUID)
		}
		if _, exists := byID[d.ID]; exists {
			return nil, fmt.Errorf("duplicate generation ID %d", d.ID)
		}
		raw, err := json.Marshal(d)
		if err != nil {
			return nil, err
		}
		if err = json.Unmarshal(raw, &cloned[i]); err != nil {
			return nil, err
		}
		byID[d.ID] = decisionIndexMetadata{uuid: cloned[i].UUID, conversation: cloned[i].Hit.ConversationID}
		uuids[d.UUID] = true
	}
	idx, err := BuildIndex(ctx, dir, cloned)
	if err != nil {
		return nil, err
	}
	if err = idx.ValidateGeneration(cloned); err != nil {
		idx.Close()
		return nil, err
	}
	// BuildIndex already stores full-Document hashes. Canonical ID order binds all
	// versions and metadata without another corpus serialization or text scan.
	hash := sha256.New()
	hash.Write([]byte("flopwire-decision-generation-v1\x00"))
	var idBytes [8]byte
	for _, id := range idx.all {
		binary.BigEndian.PutUint64(idBytes[:], uint64(id))
		hash.Write(idBytes[:])
		h := idx.hashes[id]
		hash.Write(h[:])
	}
	if err = ctx.Err(); err != nil {
		idx.Close()
		return nil, err
	}
	return &DecisionIndex{index: idx, docs: cloned, byID: byID, generation: hex.EncodeToString(hash.Sum(nil))}, nil
}
func (d *DecisionIndex) Name() string         { return "embedded-zoekt" }
func (d *DecisionIndex) GenerationID() string { return d.generation }
func (d *DecisionIndex) DocumentCount() int   { return len(d.docs) }
func (d *DecisionIndex) Close() error {
	d.mu.Lock()
	defer d.mu.Unlock()
	if !d.closed {
		d.closed = true
		return d.index.Close()
	}
	return nil
}
func (d *DecisionIndex) Candidates(ctx context.Context, _ pgx.Tx, q DecisionQuery) (DecisionCandidates, error) {
	d.mu.RLock()
	defer d.mu.RUnlock()
	if err := ctx.Err(); err != nil {
		return DecisionCandidates{}, err
	}
	if d.closed {
		return DecisionCandidates{}, errors.New("decision index closed")
	}
	cap := q.CandidateCap
	if cap == 0 {
		cap = decisionDefaultCandidateCap
	}
	if cap < 0 {
		return DecisionCandidates{}, errors.New("negative candidate cap")
	}
	plan, err := grep.Compile(q.Query)
	if err != nil {
		return DecisionCandidates{}, err
	}
	// A non-nil empty scope is explicitly empty; nil means the whole generation.
	var scope map[string]bool
	if q.ConversationIDs != nil {
		scope = make(map[string]bool, len(q.ConversationIDs))
		for _, id := range q.ConversationIDs {
			scope[id] = true
		}
		if len(scope) == 0 {
			return DecisionCandidates{IDs: []string{}, Complete: true}, nil
		}
	}
	ids, err := d.index.Candidates(ctx, plan.Re)
	if err != nil {
		return DecisionCandidates{}, err
	}
	out := make([]string, 0, min(len(ids), cap))
	for i, id := range ids {
		if i%256 == 0 {
			if err := ctx.Err(); err != nil {
				return DecisionCandidates{}, err
			}
		}
		metadata, ok := d.byID[id]
		if !ok {
			return DecisionCandidates{}, fmt.Errorf("candidate outside pinned generation %d", id)
		}
		if scope != nil && !scope[metadata.conversation] {
			continue
		}
		if len(out) == cap {
			return DecisionCandidates{Complete: false}, nil
		}
		out = append(out, metadata.uuid)
	}
	if err := ctx.Err(); err != nil {
		return DecisionCandidates{}, err
	}
	return DecisionCandidates{IDs: out, Complete: true}, nil
}
