package adapter

import (
	"context"
	"errors"
	"path/filepath"
	"runtime"
	"slices"
	"testing"
	"time"

	"github.com/flopwire/flopwire/internal/retrieval/format"
)

func decisionFixture(t *testing.T, docs []Document) *DecisionIndex {
	t.Helper()
	d, err := BuildDecisionIndex(context.Background(), filepath.Join(t.TempDir(), "generation"), docs)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { d.Close() })
	return d
}
func TestDecisionIndexPinnedGeneration(t *testing.T) {
	ts := time.Unix(1234, 0)
	docs := []Document{{ID: 1, UUID: "uuid1", Text: "timeout", Version: 1, Hit: format.Hit{ConversationID: "conv1", Branches: []string{"main"}, TS: &ts}}, {ID: 2, UUID: "uuid2", Text: "failure", Version: 1, Hit: format.Hit{ConversationID: "conv2"}}}
	d := decisionFixture(t, docs)
	generation := d.GenerationID()
	docs[0].UUID = "mutated"
	docs[0].Text = "different"
	docs[0].Version++
	docs[0].Hit.ConversationID = "mutated"
	docs[0].Hit.Branches[0] = "mutated"
	ts = time.Unix(5678, 0)
	if d.docs[0].Hit.Branches[0] != "main" || d.docs[0].Hit.TS.Unix() != 1234 {
		t.Fatal("generation nested metadata changed")
	}
	out, err := d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: "timeout|failure"}, ConversationIDs: []string{"conv1"}})
	if err != nil || !out.Complete || !slices.Equal(out.IDs, []string{"uuid1"}) {
		t.Fatalf("pinned results %v %v", out, err)
	}
	if generation != d.GenerationID() {
		t.Fatal("identity changed")
	}
	fresh := decisionFixture(t, docs)
	if fresh.GenerationID() == generation {
		t.Fatal("changed generation reused identity")
	}
}
func TestDecisionIndexCapsAndFallback(t *testing.T) {
	docs := []Document{{ID: 1, UUID: "u1", Text: "timeout", Hit: format.Hit{ConversationID: "a"}}, {ID: 2, UUID: "u2", Text: "failure", Hit: format.Hit{ConversationID: "a"}}, {ID: 3, UUID: "u3", Text: "xy", Hit: format.Hit{ConversationID: "b"}}}
	d := decisionFixture(t, docs)
	for _, p := range []string{"timeout|failure", ".*"} {
		out, err := d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: p}, CandidateCap: 1})
		if err != nil || out.Complete || len(out.IDs) != 0 {
			t.Fatalf("cap claimed complete %v %v", out, err)
		}
	}
	out, err := d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: ".*"}, ConversationIDs: []string{"b"}, CandidateCap: 1})
	if err != nil || !out.Complete || !slices.Equal(out.IDs, []string{"u3"}) {
		t.Fatalf("scoped cap %v %v", out, err)
	}
	out, err = d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: ".*"}, ConversationIDs: []string{}})
	if err != nil || !out.Complete || len(out.IDs) != 0 {
		t.Fatalf("empty scope %v %v", out, err)
	}
	if _, err = d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: ".*"}, CandidateCap: -1}); err == nil {
		t.Fatal("negative cap accepted")
	}
}
func TestDecisionIndexCancellationAndInvalid(t *testing.T) {
	d := decisionFixture(t, []Document{{ID: 1, UUID: "u1", Text: "needle"}})
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if out, err := d.Candidates(ctx, nil, DecisionQuery{Query: format.GrepQuery{Pattern: "needle"}}); !errors.Is(err, context.Canceled) || out.Complete {
		t.Fatalf("cancel %v %v", out, err)
	}
	if _, err := d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: "["}}); err == nil {
		t.Fatal("invalid regex accepted")
	}
	d.Close()
	if _, err := d.Candidates(context.Background(), nil, DecisionQuery{Query: format.GrepQuery{Pattern: "needle"}}); err == nil {
		t.Fatal("closed accepted")
	}
	for _, docs := range [][]Document{{{ID: 1, Text: "needle"}}, {{ID: 1, UUID: "same", Text: "one"}, {ID: 2, UUID: "same", Text: "two"}}} {
		if _, err := BuildDecisionIndex(context.Background(), filepath.Join(t.TempDir(), "invalid"), docs); err == nil {
			t.Fatal("invalid UUID generation accepted")
		}
	}
}

// Query cost should depend on candidates, not original text size. This tiny
// allocation check is a regression gate, not a performance or load benchmark.
func TestDecisionIndexLookupDoesNotCopyHistory(t *testing.T) {
	docs := []Document{{ID: 1, UUID: "u1", Text: "rare_needle"}, {ID: 2, UUID: "u2", Text: string(make([]byte, 3<<20)) + "other"}}
	d := decisionFixture(t, docs)
	q := DecisionQuery{Query: format.GrepQuery{Pattern: "rare_needle"}}
	allocs := testing.AllocsPerRun(3, func() {
		out, err := d.Candidates(context.Background(), nil, q)
		if err != nil || !out.Complete {
			t.Fatalf("lookup %v %v", out, err)
		}
	})
	t.Logf("candidate lookup allocations=%f; history retained=%d bytes; candidates include ineligible fallback", allocs, len(d.docs[1].Text))
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	out, err := d.Candidates(context.Background(), nil, q)
	runtime.ReadMemStats(&after)
	if err != nil || !out.Complete {
		t.Fatalf("lookup %v %v", out, err)
	}
	allocated := after.TotalAlloc - before.TotalAlloc
	t.Logf("candidate lookup allocated_bytes=%d", allocated)
	if allocated > 1<<20 {
		t.Fatalf("query allocated %d bytes for two candidate IDs; likely history copying", allocated)
	}
}
