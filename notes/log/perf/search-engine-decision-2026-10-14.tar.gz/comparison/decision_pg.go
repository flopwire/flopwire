package adapter

import (
	"context"
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/flopwire/flopwire/internal/retrieval/grep"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type DecisionPG struct{}

func (DecisionPG) Name() string { return "postgres" }

// The finite-literal route mirrors production literalRegexpCond's ILIKE OR
// shape and default visibility. Other syntax deliberately uses an explicit
// bounded scan rather than silently treating an unsupported pattern as empty.
func decisionPGSQL(q DecisionQuery) (string, []any, bool, error) {
	if q.CandidateCap < 0 {
		return "", nil, false, fmt.Errorf("negative candidate cap")
	}
	plan, err := grep.Compile(q.Query)
	if err != nil {
		return "", nil, false, err
	}
	args := []any{}
	arg := func(v any) string { args = append(args, v); return fmt.Sprintf("$%d", len(args)) }
	where := []string{"c.hidden_at IS NULL", "NOT m.superseded", "m.on_active_path IS NOT FALSE", "m.kind<>'injected'"}
	if len(q.ConversationIDs) > 0 {
		where = append(where, "m.conversation_id=ANY("+arg(q.ConversationIDs)+"::uuid[])")
	}
	literals, ok := finiteLiterals(plan.Re.String())
	ok = ok && len(literals) <= 32 && len(plan.Re.String()) <= 1024
	// PostgreSQL locale folding is not relied on for Go's long-s/Kelvin orbit.
	if ok {
		expanded := []string{}
		for _, literal := range literals {
			variants := []string{""}
			for _, r := range literal {
				orbit := []rune{r}
				if r == 's' {
					orbit = append(orbit, 'ſ')
				}
				if r == 'k' {
					orbit = append(orbit, 'K')
				}
				next := []string{}
				for _, prefix := range variants {
					for _, fold := range orbit {
						next = append(next, prefix+string(fold))
					}
				}
				variants = next
				if len(variants) > 32 {
					ok = false
					break
				}
			}
			expanded = append(expanded, variants...)
			if !ok || len(expanded) > 32 {
				ok = false
				break
			}
		}
		literals = expanded
	}
	if ok {
		parts := []string{}
		for _, literal := range literals {
			escaped := strings.NewReplacer(`\`, `\\`, "%", `\%`, "_", `\_`).Replace(literal)
			parts = append(parts, "m.text ILIKE "+arg("%"+escaped+"%"))
		}
		where = append(where, "("+strings.Join(parts, " OR ")+")")
	}
	cap := q.CandidateCap
	if cap <= 0 {
		cap = 100000
	}
	sql := `SELECT m.id::text FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE ` + strings.Join(where, " AND ") + ` ORDER BY m.ts DESC NULLS LAST,m.id LIMIT ` + fmt.Sprint(cap+1)
	return sql, args, !ok, nil
}
func (p DecisionPG) Candidates(ctx context.Context, tx pgx.Tx, q DecisionQuery) (DecisionCandidates, error) {
	if q.CandidateCap < 0 {
		return DecisionCandidates{}, fmt.Errorf("negative candidate cap")
	}
	if q.ConversationIDs != nil && len(q.ConversationIDs) == 0 {
		return DecisionCandidates{IDs: []string{}, Complete: true}, nil
	}
	sql, args, _, err := decisionPGSQL(q)
	if err != nil {
		return DecisionCandidates{}, err
	}
	rows, err := tx.Query(ctx, sql, args...)
	if err != nil {
		return DecisionCandidates{}, err
	}
	ids, err := pgx.CollectRows(rows, pgx.RowTo[string])
	if err != nil {
		return DecisionCandidates{}, err
	}
	cap := q.CandidateCap
	if cap <= 0 {
		cap = 100000
	}
	if len(ids) > cap {
		return DecisionCandidates{Complete: false}, nil
	}
	return DecisionCandidates{IDs: ids, Complete: true}, nil
}

type DecisionRun struct {
	Engine        string   `json:"engine"`
	Pattern       string   `json:"pattern"`
	Scope         string   `json:"scope"`
	CandidateMS   float64  `json:"candidate_ms"`
	FenceMS       float64  `json:"fence_ms"`
	HydrateMS     float64  `json:"hydrate_ms"`
	VerifyMS      float64  `json:"verify_ms"`
	FirstUsefulMS float64  `json:"first_useful_ms"`
	TotalMS       float64  `json:"total_ms"`
	Candidates    int      `json:"candidates"`
	Checked       int      `json:"checked"`
	BodyBytes     int64    `json:"body_bytes"`
	HydratedBytes int64    `json:"hydrated_bytes"`
	Suppressed    int      `json:"suppressed"`
	Complete      bool     `json:"complete"`
	IDs           []string `json:"-"`
	ResultCount   int      `json:"result_count"`
	Error         string   `json:"error,omitempty"`
}

func millis(t time.Time) float64 { return float64(time.Since(t).Microseconds()) / 1000 }

// RunDecision shares the same short RR snapshot, current visibility fence,
// SQL body batches and original Go verifier across candidate engines. First
// page requires complete candidate enumeration before loading sorted bodies.
func RunDecision(ctx context.Context, pool *pgxpool.Pool, engine DecisionCandidateEngine, q DecisionQuery, full bool) (out DecisionRun, err error) {
	start := time.Now()
	out = DecisionRun{Engine: engine.Name(), Pattern: q.Query.Pattern, Scope: "all", IDs: []string{}}
	if len(q.ConversationIDs) > 0 {
		out.Scope = "scoped"
	}
	defer func() {
		out.TotalMS = millis(start)
		out.ResultCount = len(out.IDs)
		if err != nil {
			out.Error = err.Error()
		}
	}()
	if q.Expected == nil {
		return out, fmt.Errorf("expected version manifest required")
	}
	tx, err := pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.RepeatableRead, AccessMode: pgx.ReadOnly})
	if err != nil {
		return out, err
	}
	defer tx.Rollback(context.Background())
	phase := time.Now()
	candidates, err := engine.Candidates(ctx, tx, q)
	out.CandidateMS = millis(phase)
	if err != nil {
		return out, err
	}
	if !candidates.Complete {
		return out, fmt.Errorf("candidate cap reached: incomplete")
	}
	out.Candidates = len(candidates.IDs)
	eligible := make([]string, 0, len(candidates.IDs))
	for _, id := range candidates.IDs {
		if _, ok := q.Expected[id]; ok {
			eligible = append(eligible, id)
		} else {
			out.Suppressed++
		}
	}
	phase = time.Now()
	rows, err := tx.Query(ctx, `SELECT m.id::text FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE m.id=ANY($1::uuid[]) AND c.hidden_at IS NULL AND NOT m.superseded AND m.on_active_path IS NOT FALSE AND m.kind<>'injected' AND (COALESCE(cardinality($2::uuid[]),0)=0 OR m.conversation_id=ANY($2::uuid[]))`, eligible, q.ConversationIDs)
	if err != nil {
		return out, err
	}
	ordered, err := pgx.CollectRows(rows, pgx.RowTo[string])
	if err == nil {
		sort.Slice(ordered, func(i, j int) bool { return q.Expected[ordered[i]].Rank < q.Expected[ordered[j]].Rank })
	}
	out.FenceMS = millis(phase)
	if err != nil {
		return out, err
	}
	plan, err := grep.Compile(q.Query)
	if err != nil {
		return out, err
	}
	limit := q.Query.Limit
	if limit <= 0 {
		limit = 20
	}
	for offset := 0; offset < len(ordered); offset += 128 {
		end := min(offset+128, len(ordered))
		phase = time.Now()
		rows, err := tx.Query(ctx, `SELECT m.id::text,m.text,m.version FROM unnest($1::uuid[]) WITH ORDINALITY page(id,n) JOIN messages m ON m.id=page.id ORDER BY page.n`, ordered[offset:end])
		if err != nil {
			return out, err
		}
		type bodyRow struct {
			ID, Text string
			Version  int
		}
		batch, err := pgx.CollectRows(rows, func(r pgx.CollectableRow) (bodyRow, error) {
			var pair bodyRow
			err := r.Scan(&pair.ID, &pair.Text, &pair.Version)
			return pair, err
		})
		out.HydrateMS += millis(phase)
		if err != nil {
			return out, err
		}
		phase = time.Now()
		for _, pair := range batch {
			out.HydratedBytes += int64(len(pair.Text))
		}
		for _, pair := range batch {
			out.Checked++
			out.BodyBytes += int64(len(pair.Text))
			expected := q.Expected[pair.ID]
			sum := sha256.Sum256([]byte(pair.Text))
			if pair.Version != expected.Version || sum != expected.SHA {
				out.Suppressed++
				continue
			}
			col := grep.NewCollector(plan.Re, q.Query)
			col.Add(grep.Row{Session: pair.ID, Text: pair.Text, SHA: sum, Ref: pair.ID})
			if len(col.Result().Hits) > 0 {
				out.IDs = append(out.IDs, pair.ID)
				if len(out.IDs) == limit && out.FirstUsefulMS == 0 {
					out.FirstUsefulMS = millis(start)
				}
				if !full && len(out.IDs) >= limit {
					out.VerifyMS += millis(phase)
					if err = tx.Commit(ctx); err != nil {
						return out, err
					}
					return out, nil
				}
			}
		}
		out.VerifyMS += millis(phase)
	}
	out.Complete = true
	if out.FirstUsefulMS == 0 {
		out.FirstUsefulMS = millis(start)
	}
	err = tx.Commit(ctx)
	return out, err
}

// Keep public query types imported alongside the finite predicate implementation.
var _ = format.GrepQuery{}
