package adapter

import (
	"crypto/sha256"
	"strings"
	"testing"

	"github.com/flopwire/flopwire/internal/retrieval/format"
)

func TestDecisionPGCommonParity(t *testing.T) {
	f := NewDecisionFixture(t, 600)
	idx, err := BuildDecisionIndex(t.Context(), t.TempDir()+"/decision-index", f.Documents)
	if err != nil {
		t.Fatal(err)
	}
	defer idx.Close()
	for _, pattern := range []string{"ancientneedle", "heron", "timeout|failure", "[A-Za-z]{30}", ".*"} {
		for _, scope := range [][]string{nil, f.ScopeIDs, []string{}} {
			q := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: pattern, Limit: 20}, ConversationIDs: scope, CandidateCap: 1000}
			want, err := DecisionOracle(f.Documents, q)
			if err != nil {
				t.Fatal(err)
			}
			for _, engine := range []DecisionCandidateEngine{DecisionPG{}, idx} {
				run, err := RunDecision(t.Context(), f.PG.pool, engine, q, true)
				if err != nil || !run.Complete || strings.Join(run.IDs, ",") != strings.Join(want, ",") {
					t.Fatalf("%s pattern=%q scope=%v got %+v want %v err %v", engine.Name(), pattern, scope, run, want, err)
				}
			}
		}
	}
	for _, engine := range []DecisionCandidateEngine{DecisionPG{}, idx} {
		q := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: ".*"}, CandidateCap: 3}
		run, err := RunDecision(t.Context(), f.PG.pool, engine, q, true)
		if err == nil || run.Complete || len(run.IDs) != 0 {
			t.Fatalf("cap falsely complete %+v %v", run, err)
		}
	}
}

func TestDecisionPGFrozenBodyAndLateIDs(t *testing.T) {
	f := NewDecisionFixture(t, 20)
	idx, err := BuildDecisionIndex(t.Context(), t.TempDir()+"/decision-index", f.Documents)
	if err != nil {
		t.Fatal(err)
	}
	defer idx.Close()
	a, b := f.Documents[0].UUID, f.Documents[1].UUID
	initial := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: "ancientneedle"}, CandidateCap: 100}
	initialOracle, err := DecisionOracle(f.Documents, initial)
	if err != nil {
		t.Fatal(err)
	}
	f.PG.exec(t, "UPDATE messages SET ts=now() WHERE id=$1", a)
	for _, engine := range []DecisionCandidateEngine{DecisionPG{}, idx} {
		run, err := RunDecision(t.Context(), f.PG.pool, engine, initial, true)
		if err != nil || strings.Join(run.IDs, ",") != strings.Join(initialOracle, ",") {
			t.Fatalf("timestamp-only mutation changed frozen order %s %+v %v", engine.Name(), run, err)
		}
	}
	f.PG.exec(t, "UPDATE messages SET text='ancientneedle changed',text_len=21 WHERE id=$1", a)
	f.PG.exec(t, "UPDATE messages SET text='ancientneedle version changed',text_len=29,version=2 WHERE id=$1", b)
	f.PG.add(t, 999, "ancientneedle later ingest", nil)
	q := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: "ancientneedle"}, CandidateCap: 100}
	oracle, err := DecisionOracle(f.Documents, q)
	if err != nil {
		t.Fatal(err)
	}
	want := []string{}
	for _, id := range oracle {
		if id != a && id != b {
			want = append(want, id)
		}
	}
	for _, engine := range []DecisionCandidateEngine{DecisionPG{}, idx} {
		run, err := RunDecision(t.Context(), f.PG.pool, engine, q, true)
		if err != nil || strings.Join(run.IDs, ",") != strings.Join(want, ",") {
			t.Fatalf("stale or late body leaked %s %+v %v", engine.Name(), run, err)
		}
	}
	// Validate Unicode fold and SQL wildcard escaping with real stored bodies.
	for _, body := range []string{"ſnow", "key_% marker"} {
		id := f.PG.add(t, 1000+int64(len(body)), body, nil)
		sum := sha256.Sum256([]byte(body))
		f.Expected[id] = DecisionVersion{Version: 1, SHA: sum}
	}
	for _, pattern := range []string{"snow", "key_%"} {
		q := DecisionQuery{Expected: f.Expected, Query: format.GrepQuery{Pattern: pattern}, CandidateCap: 100}
		run, err := RunDecision(t.Context(), f.PG.pool, DecisionPG{}, q, true)
		if err != nil || len(run.IDs) != 1 {
			t.Fatalf("safe literal %q %+v %v", pattern, run, err)
		}
	}
}

func TestDecisionPGPredicateShape(t *testing.T) {
	sql, args, fallback, err := decisionPGSQL(DecisionQuery{Query: format.GrepQuery{Pattern: "timeout|failure"}})
	if err != nil || fallback || len(args) != 2 || !strings.Contains(sql, "m.text ILIKE $1 OR m.text ILIKE $2") || !strings.Contains(sql, "m.ts DESC NULLS LAST,m.id") {
		t.Fatalf("shape sql=%s args=%v fallback=%v err=%v", sql, args, fallback, err)
	}
	_, _, fallback, err = decisionPGSQL(DecisionQuery{Query: format.GrepQuery{Pattern: "[A-Za-z]{30}"}})
	if err != nil || !fallback {
		t.Fatalf("unindexed route should be explicit fallback=%v err=%v", fallback, err)
	}
	if len(decisionBody(500)) < 250000 {
		t.Fatal("long tool body missing")
	}

}
