#!/usr/bin/env python3
import json,math,statistics,pathlib,collections
out={}
for path in sorted(pathlib.Path('decision-evidence').glob('*/samples.jsonl')):
    records=[json.loads(x) for x in path.read_text().splitlines()]
    groups=collections.defaultdict(list)
    for r in records:
        stage=r['stage']
        if stage=='warm_first_page':
            v=r['run']; key=(stage,v['engine'],v['pattern'],v['scope']); groups[key].append((v['total_ms'],r['oracle_equal'],v))
        elif stage=='actual_store' and r['repetition']>=0:
            key=(stage,'store',r['pattern'],'scoped' if r['scoped'] else 'all'); groups[key].append((r['total_ms'],r.get('ids_equal',False),r))
        elif stage=='mixed_burst':
            key=(stage,r['engine'],'mixed','mixed'); groups[key].append((r['total_including_queue_ms'],r['oracle_equal'],r))
    summaries=[]
    for key,rows in groups.items():
        values=sorted(x[0] for x in rows)
        d=dict(zip(('stage','engine','pattern','scope'),key)); d.update(n=len(rows),median_ms=round(statistics.median(values),3),p95_ms=values[math.ceil(.95*len(values))-1],max_ms=max(values),unsuccessful_or_policy_refused=sum((not x[1]) or bool(x[2].get("error")) for x in rows),errors=sum(bool(x[2].get("error")) for x in rows),address_mismatches_without_error=sum((not x[1]) and not x[2].get("error") for x in rows),expected_policy_refusals=sum(x[2].get('expected_policy_refusal',False) for x in rows))
        if key[0]=='warm_first_page':
            for k in ('candidate_ms','fence_ms','hydrate_ms','verify_ms','candidates','checked','hydrated_bytes'):
                d['median_'+k]=statistics.median(x[2][k] for x in rows)
        if key[0]=='mixed_burst': d['median_queue_ms']=statistics.median(x[2]['queue_wait_ms'] for x in rows)
        summaries.append(d)
    out[path.parent.name]={'setup':[r for r in records if r['stage']=='setup'],'full_parity':[r for r in records if r['stage']=='full_parity'],'summary':summaries,'record_count':len(records)}
pathlib.Path('decision-evidence/summary.json').write_text(json.dumps(out,indent=2)+'\n')
for label,result in out.items():
    print(label, 'records',result['record_count'])
    for d in result['summary']: print(d['stage'],d['engine'],d['pattern'],d['scope'],'n',d['n'],'p50',d['median_ms'],'p95',d['p95_ms'],'errors',d['errors'],'mismatch',d['address_mismatches_without_error'],'refusal',d['expected_policy_refusals'])
