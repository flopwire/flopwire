package adapter

import (
	"context"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/jackc/pgx/v5"
)

type DecisionVersion struct {
	Rank    int
	Version int
	SHA     [32]byte
}

type DecisionQuery struct {
	Expected        map[string]DecisionVersion
	Query           format.GrepQuery
	ConversationIDs []string
	CandidateCap    int
}
type DecisionCandidates struct {
	IDs      []string
	Complete bool
}
type DecisionCandidateEngine interface {
	Name() string
	Candidates(context.Context, pgx.Tx, DecisionQuery) (DecisionCandidates, error)
}
