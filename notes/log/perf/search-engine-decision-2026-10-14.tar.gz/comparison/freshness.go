package adapter

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"github.com/flopwire/flopwire/internal/client"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"sort"
	"sync"
	"time"
)

var ErrFreshTailTooLarge = errors.New("uncovered committed tail exceeds explicit capture bound")

// FreshnessStore deliberately scans all eligible UUID/version metadata each
// capture. It proves correctness without a sequence watermark; NOT O(delta).
// Stored generated body hash detects edits even without version increments.
// Fixture SQL is isolated; production publication must enforce equivalent identity.
type FreshnessStore struct {
	publishMu sync.Mutex
	active    int
	mu        sync.Mutex
	pool      *pgxpool.Pool
	table     string
	base      *FreshGeneration
}
type FreshDocument struct{ doc Document }

func (d *FreshDocument) UUID() string { return d.doc.UUID }
func (d *FreshDocument) Text() string { return d.doc.Text }
func (d *FreshDocument) Version() int { return d.doc.Version }

type FreshGeneration struct {
	docs         map[string]*FreshDocument
	refs         int
	fingerprints map[string]string
}
type FreshSnapshot struct {
	store     *FreshnessStore
	base      *FreshGeneration
	documents []*FreshDocument
	expires   time.Time
	mu        sync.Mutex
	released  bool
}
type FreshCaptureStats struct {
	MetadataRows, HydratedRows int
	SharedRows                 int
	Elapsed                    time.Duration
}

func NewFreshnessStore(pool *pgxpool.Pool, table string) *FreshnessStore {
	return &FreshnessStore{pool: pool, table: pgx.Identifier{table}.Sanitize()}
}

// Publish replaces base with a committed capture; already pinned snapshots keep
// their old immutable pointer sets. Caller permits bounded full bootstrap once.
func (s *FreshnessStore) Publish(ctx context.Context, cap int) (FreshCaptureStats, error) {
	s.publishMu.Lock()
	defer s.publishMu.Unlock()
	snapshot, stats, err := s.Capture(ctx, cap, time.Minute)
	if err != nil {
		return stats, err
	}
	defer snapshot.Release()
	s.mu.Lock()
	defer s.mu.Unlock()
	next := &FreshGeneration{docs: map[string]*FreshDocument{}, fingerprints: map[string]string{}}
	for _, d := range snapshot.documents {
		next.docs[d.UUID()] = d
		sum := sha256.Sum256([]byte(d.Text()))
		next.fingerprints[d.UUID()] = hex.EncodeToString(sum[:])
	}
	s.base = next
	return stats, nil
}
func (s *FreshnessStore) Capture(ctx context.Context, tailCap int, ttl time.Duration) (*FreshSnapshot, FreshCaptureStats, error) {
	start := time.Now()
	stats := FreshCaptureStats{}
	if tailCap < 0 || ttl <= 0 {
		return nil, stats, fmt.Errorf("invalid capture bounds")
	}
	s.mu.Lock()
	defer s.mu.Unlock() // serializes publication/pinning, not DB writers
	if s.active >= 64 {
		return nil, stats, fmt.Errorf("active snapshot cap exceeded")
	}
	tx, err := s.pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.RepeatableRead, AccessMode: pgx.ReadOnly})
	if err != nil {
		return nil, stats, err
	}
	defer tx.Rollback(context.Background())
	// Complete metadata membership from one short snapshot catches late commits
	// regardless of allocated sequence or transcript time; index/scan cost measured.
	rows, err := tx.Query(ctx, "SELECT id::text,version,encode(body_hash,'hex'),ts FROM "+s.table+" WHERE visible ORDER BY id")
	if err != nil {
		return nil, stats, err
	}
	type member struct {
		id      string
		version int
		hash    string
		ts      *time.Time
	}
	members := []member{}
	for rows.Next() {
		var m member
		if err = rows.Scan(&m.id, &m.version, &m.hash, &m.ts); err != nil {
			rows.Close()
			return nil, stats, err
		}
		members = append(members, m)
	}
	rows.Close()
	if err = rows.Err(); err != nil {
		return nil, stats, err
	}
	stats.MetadataRows = len(members)
	if len(members) > 1000000 {
		return nil, stats, fmt.Errorf("metadata capture exceeds one-million row explicit POC cap")
	}
	docs := make([]*FreshDocument, 0, len(members))
	uncovered := []member{}
	for _, m := range members {
		if s.base != nil {
			if d := s.base.docs[m.id]; d != nil && d.Version() == m.version && s.base.fingerprints[m.id] == m.hash && sameFreshTime(d.doc.Hit.TS, m.ts) {
				docs = append(docs, d)
				stats.SharedRows++
				continue
			}
		}
		uncovered = append(uncovered, m)
	}
	if len(uncovered) > tailCap {
		return nil, stats, ErrFreshTailTooLarge
	}
	if len(uncovered) > 0 {
		ids := make([]string, 0, len(uncovered))
		for _, m := range uncovered {
			ids = append(ids, m.id)
		}
		bodyRows, err := tx.Query(ctx, "SELECT id::text,version,text,ts FROM "+s.table+" WHERE id=ANY($1::uuid[])", ids)
		if err != nil {
			return nil, stats, err
		}
		for bodyRows.Next() {
			var id, text string
			var version int
			var ts *time.Time
			if err = bodyRows.Scan(&id, &version, &text, &ts); err != nil {
				bodyRows.Close()
				return nil, stats, err
			}
			d := &FreshDocument{doc: Document{UUID: id, Text: text, Version: version, Hit: format.Hit{MessageID: id, SessionID: "freshness-fixture", TS: ts, Kind: "assistant"}}}
			docs = append(docs, d)
			stats.HydratedRows++
		}
		bodyRows.Close()
		if err = bodyRows.Err(); err != nil {
			return nil, stats, err
		}
		if stats.HydratedRows != len(uncovered) {
			return nil, stats, fmt.Errorf("snapshot hydration membership mismatch")
		}
	}
	sort.Slice(docs, func(i, j int) bool {
		a, b := docs[i], docs[j]
		if a.doc.Hit.TS == nil && b.doc.Hit.TS != nil {
			return false
		}
		if a.doc.Hit.TS != nil && b.doc.Hit.TS == nil {
			return true
		}
		if a.doc.Hit.TS != nil && !a.doc.Hit.TS.Equal(*b.doc.Hit.TS) {
			return a.doc.Hit.TS.After(*b.doc.Hit.TS)
		}
		return a.UUID() < b.UUID()
	})
	if err = tx.Commit(ctx); err != nil {
		return nil, stats, err
	}
	snapshot := &FreshSnapshot{store: s, base: s.base, documents: docs, expires: time.Now().Add(ttl)}
	if s.base != nil {
		s.base.refs++
	}
	s.active++
	time.AfterFunc(ttl, snapshot.Release)
	stats.Elapsed = time.Since(start)
	return snapshot, stats, nil
}

// Pinned returns opaque handles with read-only scalar accessors. The slice is
// copied, body strings and generation records are shared without mutable exports.
func (s *FreshSnapshot) Pinned() ([]*FreshDocument, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.released || !time.Now().Before(s.expires) {
		return nil, fmt.Errorf("snapshot expired/released; restart required")
	}
	return append([]*FreshDocument(nil), s.documents...), nil
}
func (s *FreshSnapshot) Release() {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.released {
		return
	}
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	if s.base != nil {
		s.base.refs--
	}
	s.documents = nil
	s.released = true
	s.store.active--
	s.base = nil
}

// Current authorizes exact pinned evidence using receiving server authority;
// no old snapshot or stored credential independently authorizes returned text.
func (s *FreshSnapshot) Current(ctx context.Context, authority Authority, id string) (*FreshDocument, error) {
	if err := authority.Check(ctx); err != nil {
		return nil, err
	}
	docs, err := s.Pinned()
	if err != nil {
		return nil, err
	}
	var pinned *FreshDocument
	for _, d := range docs {
		if d.UUID() == id {
			pinned = d
			break
		}
	}
	if pinned == nil {
		return nil, fmt.Errorf("outside snapshot scope")
	}
	current, err := authority.Current(ctx, id)
	if err != nil {
		var apiErr *client.APIError
		if errors.Is(err, format.ErrNotFound) || errors.As(err, &apiErr) && apiErr.StatusCode == 404 {
			return nil, nil
		}
		return nil, err
	}
	if current.ID != id || current.Text != pinned.Text() || current.Version != pinned.Version() || current.Clipped || current.Superseded || current.OffPath {
		return nil, nil
	}
	return pinned, nil
}

func sameFreshTime(a, b *time.Time) bool {
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	return a.Equal(*b)
}
