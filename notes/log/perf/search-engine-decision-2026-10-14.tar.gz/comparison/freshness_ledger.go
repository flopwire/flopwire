package adapter

import (
	"context"
	"errors"
	"fmt"
	"github.com/flopwire/flopwire/internal/client"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"sync"
	"time"
)

type ledgerValue struct {
	revision         int64
	doc              *FreshDocument
	visible, deleted bool
}
type ledgerGeneration struct {
	values map[string]ledgerValue
	refs   int
}
type LedgerStore struct {
	pool        *pgxpool.Pool
	publisher   sync.Mutex
	mu          sync.Mutex
	generations map[int64]*ledgerGeneration
	active      int
	current     int64
	failed      bool
	afterCommit func()
}
type LedgerCaptureStats struct {
	PendingRows, PendingBytes int
	Generation                int64
	Elapsed                   time.Duration
}
type LedgerSnapshot struct {
	store      *LedgerStore
	base       *ledgerGeneration
	overlay    map[string]ledgerValue
	generation int64
	expires    time.Time
	mu         sync.Mutex
	released   bool
}
type ledgerEvent struct {
	event int64
	id    string
	value ledgerValue
}

// InitLedgerStore creates ISOLATED fixture tables, not a production migration.
// ALL mutations must append atomically: ingest, body edits without version bump,
// hidden/unhidden, branch defaults, redaction and deletion. This POC covers only
// per-message body/visibility/tombstones. Process restart invalidates all handles.
func InitLedgerStore(ctx context.Context, pool *pgxpool.Pool) (*LedgerStore, error) {
	_, err := pool.Exec(ctx, `CREATE EXTENSION IF NOT EXISTS pgcrypto;
 CREATE TABLE ledger_heads(id uuid PRIMARY KEY,revision bigint NOT NULL);
 CREATE TABLE ledger_events(event_id bigserial PRIMARY KEY,id uuid NOT NULL,revision bigint NOT NULL,body text NOT NULL,body_hash bytea GENERATED ALWAYS AS(digest(body,'sha256')) STORED,visible boolean NOT NULL,deleted boolean NOT NULL,covered_generation bigint);
 CREATE INDEX ledger_pending_idx ON ledger_events(event_id) WHERE covered_generation IS NULL;
 CREATE TABLE ledger_pointer(singleton integer PRIMARY KEY CHECK(singleton=1),generation bigint NOT NULL);
 INSERT INTO ledger_pointer VALUES(1,0);`)
	if err != nil {
		return nil, err
	}
	return &LedgerStore{pool: pool, generations: map[int64]*ledgerGeneration{0: {values: map[string]ledgerValue{}}}}, nil
}

// WriteTx locks the per-message head. Revisions follow same-UUID commit order,
// unlike global sequence allocation; body hash is generated inside PostgreSQL.
func (s *LedgerStore) WriteTx(ctx context.Context, tx pgx.Tx, id, body string, visible, deleted bool) (int64, error) {
	var revision int64
	if err := tx.QueryRow(ctx, `INSERT INTO ledger_heads(id,revision) VALUES($1,1) ON CONFLICT(id) DO UPDATE SET revision=ledger_heads.revision+1 RETURNING revision`, id).Scan(&revision); err != nil {
		return 0, err
	}
	var event int64
	err := tx.QueryRow(ctx, `INSERT INTO ledger_events(id,revision,body,visible,deleted) VALUES($1,$2,$3,$4,$5) RETURNING event_id`, id, revision, body, visible, deleted).Scan(&event)
	return event, err
}
func (s *LedgerStore) Write(ctx context.Context, id, body string, visible, deleted bool) (int64, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(context.Background())
	event, err := s.WriteTx(ctx, tx, id, body, visible, deleted)
	if err != nil {
		return 0, err
	}
	return event, tx.Commit(ctx)
}
func (s *LedgerStore) read(ctx context.Context, cap int, byteCap int) (int64, []ledgerEvent, int, error) {
	if cap < 0 || byteCap < 0 {
		return 0, nil, 0, fmt.Errorf("invalid bounds")
	}
	tx, err := s.pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.RepeatableRead, AccessMode: pgx.ReadOnly})
	if err != nil {
		return 0, nil, 0, err
	}
	defer tx.Rollback(context.Background())
	var generation int64
	if err = tx.QueryRow(ctx, `SELECT generation FROM ledger_pointer WHERE singleton=1`).Scan(&generation); err != nil {
		return 0, nil, 0, err
	}
	rows, err := tx.Query(ctx, `SELECT event_id,octet_length(body) FROM ledger_events WHERE covered_generation IS NULL ORDER BY event_id LIMIT $1`, cap+1)
	if err != nil {
		return 0, nil, 0, err
	}
	ids := []int64{}
	bytes := 0
	for rows.Next() {
		var id int64
		var size int
		if err = rows.Scan(&id, &size); err != nil {
			rows.Close()
			return 0, nil, 0, err
		}
		ids = append(ids, id)
		bytes += size
	}
	rows.Close()
	if err = rows.Err(); err != nil {
		return 0, nil, 0, err
	}
	if len(ids) > cap || bytes > byteCap {
		return 0, nil, 0, ErrFreshTailTooLarge
	}
	events := make([]ledgerEvent, 0, len(ids))
	if len(ids) > 0 {
		bodyRows, err := tx.Query(ctx, `SELECT event_id,id::text,revision,body,visible,deleted FROM ledger_events WHERE event_id=ANY($1::bigint[])`, ids)
		if err != nil {
			return 0, nil, 0, err
		}
		for bodyRows.Next() {
			var e ledgerEvent
			var body string
			if err = bodyRows.Scan(&e.event, &e.id, &e.value.revision, &body, &e.value.visible, &e.value.deleted); err != nil {
				bodyRows.Close()
				return 0, nil, 0, err
			}
			e.value.doc = &FreshDocument{doc: Document{UUID: e.id, Text: body, Version: 1, Hit: format.Hit{MessageID: e.id, SessionID: "ledger-fixture", Kind: "assistant"}}}
			events = append(events, e)
		}
		bodyRows.Close()
		if err = bodyRows.Err(); err != nil {
			return 0, nil, 0, err
		}
		if len(events) != len(ids) {
			return 0, nil, 0, fmt.Errorf("pending snapshot hydration mismatch")
		}
	}
	if err = tx.Commit(ctx); err != nil {
		return 0, nil, 0, err
	}
	return generation, events, bytes, nil
}
func ledgerOverlay(base *ledgerGeneration, events []ledgerEvent) map[string]ledgerValue {
	overlay := map[string]ledgerValue{}
	for _, e := range events {
		previous, ok := overlay[e.id]
		if !ok {
			previous = base.values[e.id]
		}
		if e.value.revision > previous.revision {
			overlay[e.id] = e.value
		}
	}
	return overlay
}

// Publish builds one base copy, then atomically swaps pointer and acknowledges
// ONLY exact event IDs observed by the earlier read snapshot. A delayed commit
// with a lower allocated sequence remains pending. Serial publishers are a POC
// simplification; the database pointer CAS also rejects another process winner.
func (s *LedgerStore) Publish(ctx context.Context, cap, byteCap int) (int64, error) {
	return s.publish(ctx, cap, byteCap, nil)
}
func (s *LedgerStore) publish(ctx context.Context, cap, byteCap int, beforeAck func()) (int64, error) {
	s.publisher.Lock()
	defer s.publisher.Unlock()
	s.mu.Lock()
	failed := s.failed
	s.mu.Unlock()
	if failed {
		return 0, fmt.Errorf("publication outcome unknown; restart required")
	}
	generation, events, _, err := s.read(ctx, cap, byteCap)
	if err != nil {
		return 0, err
	}
	s.mu.Lock()
	base := s.generations[generation]
	s.mu.Unlock()
	if base == nil {
		return 0, fmt.Errorf("generation unavailable; restart required")
	}
	next := &ledgerGeneration{values: make(map[string]ledgerValue, len(base.values)+len(events))}
	for id, v := range base.values {
		next.values[id] = v
	}
	for id, v := range ledgerOverlay(base, events) {
		next.values[id] = v
	}
	if beforeAck != nil {
		beforeAck()
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(context.Background())
	var current int64
	if err = tx.QueryRow(ctx, `SELECT generation FROM ledger_pointer WHERE singleton=1 FOR UPDATE`).Scan(&current); err != nil {
		return 0, err
	}
	if current != generation {
		return 0, fmt.Errorf("publication CAS lost")
	}
	newID := generation + 1
	// Cache publication and retirement share a lock through DB commit and
	// current assignment: Capture/Release cannot retire a just-committed handle.
	s.mu.Lock()
	defer s.mu.Unlock()
	for id, g := range s.generations {
		if id != generation && g.refs == 0 {
			delete(s.generations, id)
		}
	}
	if len(s.generations) >= 16 {
		return 0, fmt.Errorf("pinned generation retention cap; retry after expiry")
	}
	s.generations[newID] = next
	ids := []int64{}
	for _, e := range events {
		ids = append(ids, e.event)
	}
	if _, err = tx.Exec(ctx, `UPDATE ledger_events SET covered_generation=$1 WHERE event_id=ANY($2::bigint[]) AND covered_generation IS NULL`, newID, ids); err != nil {
		delete(s.generations, newID)
		return 0, err
	}
	if _, err = tx.Exec(ctx, `UPDATE ledger_pointer SET generation=$1 WHERE singleton=1`, newID); err != nil {
		delete(s.generations, newID)
		return 0, err
	}
	if err = tx.Commit(ctx); err != nil {
		s.failed = true
		return 0, fmt.Errorf("ambiguous publication commit; restart required: %w", err)
	}
	if s.afterCommit != nil {
		s.afterCommit()
	}
	s.current = newID
	for id, g := range s.generations {
		if id != newID && g.refs == 0 {
			delete(s.generations, id)
		}
	}
	return newID, nil
}

// Capture reads the fixed pointer and indexed committed NULL-covered tail in a
// short RR transaction. It allocates O(pending) overlay; no covered metadata or
// base body/map/list copies. Current authorities still gate response rendering.
func (s *LedgerStore) Capture(ctx context.Context, cap, byteCap int, ttl time.Duration) (*LedgerSnapshot, LedgerCaptureStats, error) {
	start := time.Now()
	stats := LedgerCaptureStats{}
	if cap < 0 || byteCap < 0 || ttl <= 0 {
		return nil, stats, fmt.Errorf("invalid bounds")
	}
	// Holding the cache lock across this bounded read prevents retiring the
	// generation selected by its RR snapshot. It serializes captures in this POC.
	s.mu.Lock()
	if s.failed {
		s.mu.Unlock()
		return nil, stats, fmt.Errorf("publication outcome unknown; restart required")
	}
	if s.active >= 64 {
		s.mu.Unlock()
		return nil, stats, fmt.Errorf("active snapshot cap")
	}
	generation, events, bytes, err := s.read(ctx, cap, byteCap)
	if err != nil {
		s.mu.Unlock()
		return nil, stats, err
	}
	base := s.generations[generation]
	if base == nil {
		s.mu.Unlock()
		return nil, stats, fmt.Errorf("generation unavailable; restart required")
	}
	base.refs++
	s.active++
	s.mu.Unlock()
	snapshot := &LedgerSnapshot{store: s, base: base, overlay: ledgerOverlay(base, events), generation: generation, expires: time.Now().Add(ttl)}
	time.AfterFunc(ttl, snapshot.Release)
	stats = LedgerCaptureStats{PendingRows: len(events), PendingBytes: bytes, Generation: generation, Elapsed: time.Since(start)}
	return snapshot, stats, nil
}
func (s *LedgerSnapshot) Get(id string) (*FreshDocument, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.released || !time.Now().Before(s.expires) {
		return nil, fmt.Errorf("snapshot expired/released; restart required")
	}
	v, ok := s.overlay[id]
	if !ok {
		v = s.base.values[id]
	}
	if !v.visible || v.deleted {
		return nil, nil
	}
	return v.doc, nil
}
func (s *LedgerSnapshot) Release() {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.released {
		return
	}
	s.store.mu.Lock()
	s.base.refs--
	s.store.active--
	if s.base.refs == 0 && s.generation != s.store.current {
		delete(s.store.generations, s.generation)
	}
	s.store.mu.Unlock()
	s.base = nil
	s.overlay = nil
	s.released = true
}

func (s *LedgerSnapshot) Current(ctx context.Context, authority Authority, id string) (*FreshDocument, error) {
	if err := authority.Check(ctx); err != nil {
		return nil, err
	}
	pinned, err := s.Get(id)
	if err != nil || pinned == nil {
		return nil, err
	}
	current, err := authority.Current(ctx, id)
	if err != nil {
		var apiErr *client.APIError
		if errors.Is(err, format.ErrNotFound) || errors.As(err, &apiErr) && apiErr.StatusCode == 404 {
			return nil, nil
		}
		return nil, err
	}
	if current.ID != id || current.Text != pinned.Text() || current.Version != pinned.Version() || current.Superseded || current.OffPath || current.Clipped {
		return nil, nil
	}
	return pinned, nil
}
