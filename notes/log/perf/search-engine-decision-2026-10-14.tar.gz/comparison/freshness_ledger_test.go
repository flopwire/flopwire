package adapter

import (
	"context"
	"errors"
	"fmt"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/google/uuid"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
)

func ledgerFixture(t *testing.T) (*pgFixture, *LedgerStore) {
	t.Helper()
	f := newPGFixture(t)
	s, err := InitLedgerStore(t.Context(), f.pool)
	if err != nil {
		t.Fatal(err)
	}
	return f, s
}
func ledgerWrite(t *testing.T, s *LedgerStore, id, text string, visible, deleted bool) int64 {
	t.Helper()
	event, err := s.Write(t.Context(), id, text, visible, deleted)
	if err != nil {
		t.Fatal(err)
	}
	return event
}
func ledgerCapture(t *testing.T, s *LedgerStore, cap int) *LedgerSnapshot {
	t.Helper()
	snapshot, _, err := s.Capture(t.Context(), cap, 64<<20, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(snapshot.Release)
	return snapshot
}
func ledgerGet(t *testing.T, s *LedgerSnapshot, id string) *FreshDocument {
	t.Helper()
	d, err := s.Get(id)
	if err != nil {
		t.Fatal(err)
	}
	return d
}
func TestDecisionFreshnessLedgerDelayedCommitAndAckRace(t *testing.T) {
	f, s := ledgerFixture(t)
	delayed, err := f.pool.Begin(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	defer delayed.Rollback(context.Background())
	late := uuid.NewString()
	low, err := s.WriteTx(t.Context(), delayed, late, "late needle", true, false)
	if err != nil {
		t.Fatal(err)
	}
	seen := uuid.NewString()
	high := ledgerWrite(t, s, seen, "seen needle", true, false)
	if high <= low {
		t.Fatal("allocation inversion absent")
	}
	during := uuid.NewString()
	if _, err = s.publish(t.Context(), 10, 1000, func() { ledgerWrite(t, s, during, "commit after read before ack", true, false) }); err != nil {
		t.Fatal(err)
	}
	old := ledgerCapture(t, s, 10)
	if ledgerGet(t, old, late) != nil || ledgerGet(t, old, seen) == nil || ledgerGet(t, old, during) == nil {
		t.Fatal("initial committed scope mismatch")
	}
	if err = delayed.Commit(t.Context()); err != nil {
		t.Fatal(err)
	}
	next := ledgerCapture(t, s, 10)
	if ledgerGet(t, next, late) == nil || ledgerGet(t, old, late) != nil {
		t.Fatal("late committed event missed or old snapshot mutated")
	}
	var pending int
	if err = f.pool.QueryRow(t.Context(), "SELECT count(*) FROM ledger_events WHERE covered_generation IS NULL").Scan(&pending); err != nil || pending != 2 {
		t.Fatal("unseen records incorrectly acknowledged", pending, err)
	}
	t.Logf("allocated low=%d/high=%d; late commit and during-publish event remain pending=%d", low, high, pending)
}
func TestDecisionFreshnessLedgerOverlayBodyVisibilityDeletion(t *testing.T) {
	_, s := ledgerFixture(t)
	id := uuid.NewString()
	ledgerWrite(t, s, id, "original needle", true, false)
	if _, err := s.Publish(t.Context(), 10, 1000); err != nil {
		t.Fatal(err)
	}
	old := ledgerCapture(t, s, 0)
	original := ledgerGet(t, old, id)
	ledgerWrite(t, s, id, "changed without message version bump", true, false)
	changed := ledgerCapture(t, s, 10)
	if ledgerGet(t, changed, id).Text() == original.Text() || ledgerGet(t, changed, id).Version() != 1 || ledgerGet(t, old, id) != original {
		t.Fatal("overlay identity/frozen pointer broken")
	}
	ledgerWrite(t, s, id, "changed without message version bump", false, false)
	hidden := ledgerCapture(t, s, 10)
	if ledgerGet(t, hidden, id) != nil {
		t.Fatal("hide ignored")
	}
	ledgerWrite(t, s, id, "restored", true, false)
	unhidden := ledgerCapture(t, s, 10)
	if ledgerGet(t, unhidden, id) == nil || ledgerGet(t, hidden, id) != nil {
		t.Fatal("scope expansion changed old scan")
	}
	ledgerWrite(t, s, id, "", false, true)
	deleted := ledgerCapture(t, s, 10)
	if ledgerGet(t, deleted, id) != nil {
		t.Fatal("delete ignored")
	}
	if _, err := s.Publish(t.Context(), 10, 1000); err != nil {
		t.Fatal(err)
	}
	fresh := ledgerCapture(t, s, 0)
	if ledgerGet(t, fresh, id) != nil {
		t.Fatal("published tombstone lost")
	}
}
func TestDecisionFreshnessLedgerAuthorityOverrides(t *testing.T) {
	f, s := ledgerFixture(t)
	id := f.add(t, 1, "private ledger needle", nil)
	ledgerWrite(t, s, id, "private ledger needle", true, false)
	if _, err := s.Publish(t.Context(), 10, 1000); err != nil {
		t.Fatal(err)
	}
	snapshot := ledgerCapture(t, s, 0)
	d, err := snapshot.Current(t.Context(), f.authority, id)
	if err != nil || d == nil {
		t.Fatal(d, err)
	}
	var redacted format.RedactResult
	if err = f.authority.HTTP.JSON(t.Context(), "POST", "/v1/redactions", format.RedactRequest{Address: id}, &redacted); err != nil {
		t.Fatal(err)
	}
	if d, err = snapshot.Current(t.Context(), f.authority, id); err != nil || d != nil {
		t.Fatal("old body served after redaction", d, err)
	}
	f.exec(t, "UPDATE credentials SET revoked_at=now(),revoke_reason='revoked' WHERE id=$1", f.credential)
	if _, err = snapshot.Current(t.Context(), f.authority, id); err == nil {
		t.Fatal("revocation bypass")
	}
}
func TestDecisionFreshnessLedgerRetentionAndBounds(t *testing.T) {
	_, s := ledgerFixture(t)
	id := uuid.NewString()
	ledgerWrite(t, s, id, "payload", true, false)
	if _, _, err := s.Capture(t.Context(), 0, 100, time.Minute); !errors.Is(err, ErrFreshTailTooLarge) {
		t.Fatal(err)
	}
	if _, _, err := s.Capture(t.Context(), 10, 1, time.Minute); !errors.Is(err, ErrFreshTailTooLarge) {
		t.Fatal(err)
	}
	pins := []*LedgerSnapshot{}
	for i := 0; i < 16; i++ {
		pins = append(pins, ledgerCapture(t, s, 10))
		if i < 15 {
			if _, err := s.Publish(t.Context(), 10, 1000); err != nil {
				t.Fatal(err)
			}
		}
	}
	if _, err := s.Publish(t.Context(), 10, 1000); err == nil {
		t.Fatal("retention cap not enforced")
	}
	for _, pin := range pins {
		pin.Release()
	}
	if _, err := s.Publish(t.Context(), 10, 1000); err != nil {
		t.Fatal("retired references not released", err)
	}
	expired, _, err := s.Capture(t.Context(), 0, 1000, 10*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(30 * time.Millisecond)
	if _, err = expired.Get(id); err == nil {
		t.Fatal("expired snapshot still valid")
	}
	s.mu.Lock()
	active := s.active
	s.mu.Unlock()
	if active != 0 {
		t.Fatal("expiry reference leak", active)
	}
}
func TestDecisionFreshnessLedgerConcurrentCapturePublication(t *testing.T) {
	_, s := ledgerFixture(t)
	id := uuid.NewString()
	ledgerWrite(t, s, id, "always present", true, false)
	if _, err := s.Publish(t.Context(), 10, 1000); err != nil {
		t.Fatal(err)
	}
	var wg sync.WaitGroup
	errs := make(chan error, 8)
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			if i%2 == 0 {
				_, err := s.Publish(t.Context(), 10, 1000)
				errs <- err
			} else {
				snapshot, _, err := s.Capture(t.Context(), 10, 1000, time.Minute)
				if err == nil {
					d, e := snapshot.Get(id)
					if e != nil || d == nil {
						err = fmt.Errorf("pinned current generation unavailable: %v", e)
					}
					snapshot.Release()
				}
				errs <- err
			}
		}(i)
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		if err != nil {
			t.Fatal(err)
		}
	}
}
func TestDecisionFreshnessLedgerCaptureCost(t *testing.T) {
	f, s := ledgerFixture(t)
	f.exec(t, "ALTER TABLE ledger_events SET(autovacuum_enabled=false)")
	f.exec(t, `WITH heads AS(INSERT INTO ledger_heads(id,revision) SELECT gen_random_uuid(),1 FROM generate_series(1,250000) RETURNING id) INSERT INTO ledger_events(id,revision,body,visible,deleted) SELECT id,1,repeat('x',128),true,false FROM heads`)
	publishStart := time.Now()
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	if _, err := s.Publish(t.Context(), 250000, 64<<20); err != nil {
		t.Fatal(err)
	}
	runtime.ReadMemStats(&after)
	t.Logf("bootstrap publication rows=250000 sourceBodyBytes=32000000 elapsed=%s allocated=%d (full base build once)", time.Since(publishStart), after.TotalAlloc-before.TotalAlloc)
	for i := 0; i < 10; i++ {
		ledgerWrite(t, s, uuid.NewString(), "small fresh committed tail", true, false)
	}
	f.exec(t, "ANALYZE ledger_events")
	var plan string
	if err := f.pool.QueryRow(t.Context(), `EXPLAIN(ANALYZE,BUFFERS,FORMAT JSON) SELECT event_id,octet_length(body) FROM ledger_events WHERE covered_generation IS NULL ORDER BY event_id LIMIT 101`).Scan(&plan); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(plan, "ledger_pending_idx") || strings.Contains(plan, `"Node Type": "Seq Scan"`) {
		t.Fatal("pending query scanned covered history", plan)
	}
	t.Logf("pending indexed plan=%s", plan)
	runtime.ReadMemStats(&before)
	snapshot, stats, err := s.Capture(t.Context(), 100, 1<<20, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	runtime.ReadMemStats(&after)
	snapshot.Release()
	if stats.PendingRows != 10 {
		t.Fatal(stats)
	}
	t.Logf("capture PRE-VACUUM covered=250000 pending=%d hydratedBodyBytes=%d elapsed=%s allocated=%d; no covered UUID/body/map/list copy", stats.PendingRows, stats.PendingBytes, stats.Elapsed, after.TotalAlloc-before.TotalAlloc)
	f.exec(t, "VACUUM ANALYZE ledger_events")
	var vacuumPlan string
	if err = f.pool.QueryRow(t.Context(), `EXPLAIN(ANALYZE,BUFFERS,FORMAT JSON) SELECT event_id,octet_length(body) FROM ledger_events WHERE covered_generation IS NULL ORDER BY event_id LIMIT 101`).Scan(&vacuumPlan); err != nil {
		t.Fatal(err)
	}
	t.Logf("POST-VACUUM pending indexed plan=%s", vacuumPlan)
	runtime.ReadMemStats(&before)
	clean, cleanStats, err := s.Capture(t.Context(), 100, 1<<20, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	runtime.ReadMemStats(&after)
	clean.Release()
	t.Logf("capture POST-VACUUM covered=250000 pending=%d elapsed=%s allocated=%d", cleanStats.PendingRows, cleanStats.Elapsed, after.TotalAlloc-before.TotalAlloc)
	runtime.ReadMemStats(&before)
	publishStart = time.Now()
	if _, err = s.Publish(t.Context(), 100, 1<<20); err != nil {
		t.Fatal(err)
	}
	runtime.ReadMemStats(&after)
	t.Logf("republication covered=250000 delta=10 elapsed=%s allocated=%d (full base map copy each publication remains limitation)", time.Since(publishStart), after.TotalAlloc-before.TotalAlloc)
}

func TestDecisionFreshnessLedgerCommitCaptureReleaseBarrier(t *testing.T) {
	_, s := ledgerFixture(t)
	id := uuid.NewString()
	ledgerWrite(t, s, id, "preserved", true, false)
	committed := make(chan struct{})
	resume := make(chan struct{})
	s.afterCommit = func() { close(committed); <-resume }
	publication := make(chan error, 1)
	go func() { _, err := s.Publish(t.Context(), 10, 1000); publication <- err }()
	<-committed
	captured := make(chan error, 1)
	attempted := make(chan struct{})
	go func() {
		close(attempted)
		snapshot, _, err := s.Capture(t.Context(), 0, 1000, time.Minute)
		if err == nil {
			snapshot.Release()
		}
		captured <- err
	}()
	<-attempted
	select {
	case err := <-captured:
		t.Fatal("capture crossed unfinished publication state", err)
	case <-time.After(10 * time.Millisecond):
	}
	close(resume)
	if err := <-publication; err != nil {
		t.Fatal(err)
	}
	if err := <-captured; err != nil {
		t.Fatal(err)
	}
	fresh := ledgerCapture(t, s, 0)
	if ledgerGet(t, fresh, id) == nil {
		t.Fatal("just-published handle retired before current assignment")
	}
}
