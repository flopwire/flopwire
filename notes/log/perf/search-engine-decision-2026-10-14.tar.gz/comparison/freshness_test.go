package adapter

import (
	"context"
	"fmt"
	"github.com/flopwire/flopwire/internal/retrieval/format"
	"github.com/google/uuid"
	"reflect"
	"runtime"
	"sync"
	"testing"
	"time"
)

func freshTable(t *testing.T) (*pgFixture, *FreshnessStore) {
	t.Helper()
	f := newPGFixture(t)
	f.exec(t, "CREATE EXTENSION IF NOT EXISTS pgcrypto")
	f.exec(t, `CREATE TABLE freshness_fixture(id uuid PRIMARY KEY,seq bigserial UNIQUE,version integer NOT NULL DEFAULT 1,text text NOT NULL,ts timestamptz,visible boolean NOT NULL DEFAULT true,body_hash bytea GENERATED ALWAYS AS(digest(text,'sha256')) STORED)`)
	return f, NewFreshnessStore(f.pool, "freshness_fixture")
}
func freshAdd(t *testing.T, f *pgFixture, text string) string {
	t.Helper()
	id := uuid.NewString()
	f.exec(t, "INSERT INTO freshness_fixture(id,text) VALUES($1,$2)", id, text)
	return id
}
func freshMap(t *testing.T, s *FreshSnapshot) map[string]*FreshDocument {
	t.Helper()
	docs, err := s.Pinned()
	if err != nil {
		t.Fatal(err)
	}
	out := map[string]*FreshDocument{}
	for _, d := range docs {
		out[d.UUID()] = d
	}
	return out
}
func TestDecisionFreshnessCommittedTailAndVersionChange(t *testing.T) {
	f, s := freshTable(t)
	a := freshAdd(t, f, "base needle")
	if _, err := s.Publish(t.Context(), 10); err != nil {
		t.Fatal(err)
	}
	first, stats, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil || stats.HydratedRows != 0 || stats.SharedRows != 1 {
		t.Fatal(stats, err)
	}
	defer first.Release()
	before := freshMap(t, first)
	b := freshAdd(t, f, "tail needle")
	second, stats, err := s.Capture(t.Context(), 1, time.Minute)
	if err != nil || stats.SharedRows != 1 || stats.HydratedRows != 1 {
		t.Fatal(stats, err)
	}
	defer second.Release()
	after := freshMap(t, second)
	if after[a] != before[a] || after[b] == nil || before[b] != nil {
		t.Fatal("base not shared or snapshot changed")
	}
	f.exec(t, "UPDATE freshness_fixture SET text='changed redacted',version=version+1 WHERE id=$1", a)
	third, stats, err := s.Capture(t.Context(), 2, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer third.Release()
	updated := freshMap(t, third)
	if updated[a] == before[a] || updated[a].Version() != 2 || before[a].Text() != "base needle" {
		t.Fatal("version pointer mutated")
	}
	f.exec(t, "UPDATE freshness_fixture SET visible=false WHERE id=$1", a)
	f.exec(t, "DELETE FROM freshness_fixture WHERE id=$1", b)
	hidden, _, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer hidden.Release()
	if len(freshMap(t, hidden)) != 0 {
		t.Fatal("hidden/deleted retained")
	}
	if len(freshMap(t, first)) != 1 {
		t.Fatal("pinned initial membership changed")
	}
	t.Logf("capture fullmetadata=%d hydrated=%d shared=%d elapsed=%s", stats.MetadataRows, stats.HydratedRows, stats.SharedRows, stats.Elapsed)
}
func TestDecisionFreshnessDelayedCommitDefeatsSequenceWatermark(t *testing.T) {
	f, s := freshTable(t)
	ctx := t.Context()
	delayed, err := f.pool.Begin(ctx)
	if err != nil {
		t.Fatal(err)
	}
	defer delayed.Rollback(context.Background())
	late := uuid.NewString()
	var allocated int64
	if err = delayed.QueryRow(ctx, "INSERT INTO freshness_fixture(id,text) VALUES($1,'late needle') RETURNING seq", late).Scan(&allocated); err != nil {
		t.Fatal(err)
	}
	committed := freshAdd(t, f, "committed needle")
	var cutoff int64
	if err = f.pool.QueryRow(ctx, "SELECT max(seq) FROM freshness_fixture").Scan(&cutoff); err != nil {
		t.Fatal(err)
	}
	if cutoff <= allocated {
		t.Fatal("allocation inversion not reproduced")
	}
	if _, err = s.Publish(ctx, 10); err != nil {
		t.Fatal(err)
	}
	first, _, err := s.Capture(ctx, 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer first.Release()
	if freshMap(t, first)[late] != nil || freshMap(t, first)[committed] == nil {
		t.Fatal("uncommitted visibility")
	}
	if err = delayed.Commit(ctx); err != nil {
		t.Fatal(err)
	}
	var count int
	if err = f.pool.QueryRow(ctx, "SELECT count(*) FROM freshness_fixture WHERE seq>$1", cutoff).Scan(&count); err != nil || count != 0 {
		t.Fatal(count, err)
	}
	second, stats, err := s.Capture(ctx, 1, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer second.Release()
	if freshMap(t, second)[late] == nil || stats.HydratedRows != 1 {
		t.Fatal("late commit lost", stats)
	}
	t.Logf("unsafe allocated cutoff=%d lateSeq=%d seq>cutoff finds0; metadata capture finds late committed UUID", cutoff, allocated)
}
func TestDecisionFreshnessBoundPublicationRetentionExpiry(t *testing.T) {
	f, s := freshTable(t)
	a := freshAdd(t, f, "base")
	if _, err := s.Publish(t.Context(), 10); err != nil {
		t.Fatal(err)
	}
	old, _, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	oldBase := old.base
	b := freshAdd(t, f, "tail")
	if _, _, err = s.Capture(t.Context(), 0, time.Minute); err != ErrFreshTailTooLarge {
		t.Fatal("tail not bounded", err)
	}
	if _, err = s.Publish(t.Context(), 1); err != nil {
		t.Fatal(err)
	}
	current, stats, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil || stats.SharedRows != 2 {
		t.Fatal(stats, err)
	}
	defer current.Release()
	if freshMap(t, current)[b] == nil || freshMap(t, old)[a] == nil || freshMap(t, old)[b] != nil || oldBase.refs != 1 {
		t.Fatal("publication/pin mismatch")
	}
	old.Release()
	old.Release()
	if oldBase.refs != 0 {
		t.Fatal("reference leak", oldBase.refs)
	}
	current.expires = time.Now().Add(-time.Second)
	if _, err = current.Pinned(); err == nil {
		t.Fatal("expiry not restart")
	}
}
func TestDecisionFreshnessCaptureCost(t *testing.T) {
	f, s := freshTable(t)
	for _, n := range []int{50000, 250000} {
		f.exec(t, "TRUNCATE freshness_fixture")
		f.exec(t, fmt.Sprintf("INSERT INTO freshness_fixture(id,text) SELECT gen_random_uuid(),repeat('x',128) FROM generate_series(1,%d)", n))
		s.base = nil
		if _, err := s.Publish(t.Context(), n); err != nil {
			t.Fatal(err)
		}
		var memBefore, memAfter runtime.MemStats
		runtime.ReadMemStats(&memBefore)
		snapshot, stats, err := s.Capture(t.Context(), 0, time.Minute)
		runtime.ReadMemStats(&memAfter)
		if err != nil {
			t.Fatal(err)
		}
		snapshot.Release()
		if stats.MetadataRows != n || stats.HydratedRows != 0 {
			t.Fatal(stats)
		}
		t.Logf("n=%d metadataRows=%d bodyHydrations=%d shared=%d elapsed=%s totalAllocated=%d sourceBodyBytes=%d (fullmetadata O(N), not O(delta); shared handles, no per-query body clone)", n, stats.MetadataRows, stats.HydratedRows, stats.SharedRows, stats.Elapsed, memAfter.TotalAlloc-memBefore.TotalAlloc, n*128)
	}
}

func TestDecisionFreshnessUnversionedMutationAndAutoRelease(t *testing.T) {
	f, s := freshTable(t)
	id := freshAdd(t, f, "original")
	if _, err := s.Publish(t.Context(), 10); err != nil {
		t.Fatal(err)
	}
	initial, _, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer initial.Release()
	f.exec(t, "UPDATE freshness_fixture SET text='redacted without version bump' WHERE id=$1", id)
	next, stats, err := s.Capture(t.Context(), 1, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer next.Release()
	if stats.HydratedRows != 1 || freshMap(t, next)[id] == freshMap(t, initial)[id] {
		t.Fatal("unversioned text change reused stale pointer", stats)
	}
	expiry, _, err := s.Capture(t.Context(), 1, 10*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(30 * time.Millisecond)
	if _, err = expiry.Pinned(); err == nil {
		t.Fatal("expired pointer retained")
	}
	s.mu.Lock()
	active := s.active
	s.mu.Unlock()
	if active != 2 {
		t.Fatal("expiry ref not released", active)
	}
}

func TestDecisionFreshnessAuthorityOverridesPinnedEvidence(t *testing.T) {
	f, s := freshTable(t)
	id := f.add(t, 1, "private needle", nil)
	f.exec(t, "INSERT INTO freshness_fixture(id,text) VALUES($1,'private needle')", id)
	if _, err := s.Publish(t.Context(), 10); err != nil {
		t.Fatal(err)
	}
	snapshot, _, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer snapshot.Release()
	d, err := snapshot.Current(t.Context(), f.authority, id)
	if err != nil || d == nil {
		t.Fatal(d, err)
	}
	var redacted format.RedactResult
	if err = f.authority.HTTP.JSON(t.Context(), "POST", "/v1/redactions", format.RedactRequest{Address: id}, &redacted); err != nil {
		t.Fatal(err)
	}
	d, err = snapshot.Current(t.Context(), f.authority, id)
	if err != nil || d != nil {
		t.Fatal("redaction did not override pinned text", d, err)
	}
	f.exec(t, "UPDATE credentials SET revoked_at=now(),revoke_reason='revoked' WHERE id=$1", f.credential)
	if _, err = snapshot.Current(t.Context(), f.authority, id); err == nil {
		t.Fatal("revoked authority bypassed")
	}
}

func TestDecisionFreshnessOpaqueHandlesAndConcurrentPublish(t *testing.T) {
	f, s := freshTable(t)
	id := freshAdd(t, f, "immutable")
	var wg sync.WaitGroup
	errs := make(chan error, 4)
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); _, err := s.Publish(t.Context(), 10); errs <- err }()
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		if err != nil {
			t.Fatal(err)
		}
	}
	snapshot, _, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer snapshot.Release()
	docs, err := snapshot.Pinned()
	if err != nil {
		t.Fatal(err)
	}
	typ := reflect.TypeOf(*docs[0])
	for i := 0; i < typ.NumField(); i++ {
		if typ.Field(i).IsExported() {
			t.Fatal("mutable handle field exported")
		}
	}
	docs[0] = nil
	if freshMap(t, snapshot)[id].Text() != "immutable" {
		t.Fatal("caller slice corrupted generation")
	}
}

func TestDecisionFreshnessTimestampMutationWithoutVersion(t *testing.T) {
	f, s := freshTable(t)
	id := freshAdd(t, f, "stablebody")
	if _, err := s.Publish(t.Context(), 10); err != nil {
		t.Fatal(err)
	}
	old, _, err := s.Capture(t.Context(), 0, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer old.Release()
	f.exec(t, "UPDATE freshness_fixture SET ts='2026-10-14T12:00:00Z' WHERE id=$1", id)
	current, stats, err := s.Capture(t.Context(), 1, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	defer current.Release()
	if freshMap(t, current)[id] == freshMap(t, old)[id] || stats.HydratedRows != 1 {
		t.Fatal("stale ordering metadata reused", stats)
	}
}
